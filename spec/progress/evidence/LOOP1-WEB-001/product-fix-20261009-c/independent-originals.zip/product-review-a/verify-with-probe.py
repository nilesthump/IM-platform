import sys,pathlib,importlib.util,subprocess,os
p=pathlib.Path(__file__).parent
root=pathlib.Path('H:/.codex/worktrees/w/IM-platform')
sys.path.insert(0,str(root/'tests/clients/web'))
import verify
node='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin'
os.environ['PATH']=node+os.pathsep+os.environ['PATH']
def runner(command,*,cwd,env=None):
 verify.run(command,cwd=cwd,env=env)
 if str(command[-1]).endswith('appearance.mjs'):
  verify.run([str(pathlib.Path(node)/'node.exe'),str(p/'negative-probe.mjs')],cwd=cwd,env=env)
verify.verify(root,runner=runner)
