import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import fs from 'node:fs/promises';
const {WebClient}=await import(pathToFileURL(process.env.WEB_BUILD_DIR+'/web/src/application/client.js'));
const {Http}=await import(pathToFileURL(process.env.WEB_BUILD_DIR+'/web/src/application/http.js'));
const id=n=>'10000000-0000-4000-8000-'+String(n).padStart(12,'0'), c=id(3),u=id(1),peer=id(2),sid=id(4);
const auth={session:{userId:u,sessionId:sid,clientType:'WEB',sessionEpoch:1,status:'ACTIVE'},tokens:{accessToken:'controlled-review-access',accessTokenExpiresInSeconds:3600,refreshTokenDelivery:'HTTP_ONLY_SECURE_COOKIE'},replacedExistingSession:false};
const json=(p,status=200)=>new Response(JSON.stringify(p),{status,headers:{'content-type':'application/json','cache-control':'no-store'}});
const frame=(type,r,p)=>JSON.stringify({protocolVersion:'1.0',type,requestId:r,payload:p});
const message=(seq)=>({conversationId:c,requestId:id(100+seq),messageId:id(200+seq),senderId:peer,seq,createdAt:'2026-10-09T09:00:00Z',content:{kind:'TEXT',text:'sequence '+seq}});
const tick=()=>new Promise(r=>setTimeout(r,0));
const observed=[];
async function setup(handler,timeout=10000){
 const sockets=[];
 const api=async(url,options)=>{
  if(url.endsWith('/auth/login'))return json(auth);
  if(url.endsWith('/users/me'))return json({user:{userId:u,username:'alice',displayName:'Alice'}});
  if(url.endsWith('/friends'))return json({friends:[{user:{userId:peer,username:'bob',displayName:'Bob'},friendshipId:id(6),directConversationId:c}]});
  return handler(url,options);
 };
 const factory=url=>{assert.equal(url,'wss://review.invalid/v1/ws');const s={sent:[],send(raw){this.sent.push(JSON.parse(raw));},close(){this.onclose?.();}};sockets.push(s);return s;};
 const client=new WebClient('https://review.invalid',api,factory,timeout);
 await client.login('alice','controlled-review-password');await tick();
 const socket=sockets.at(-1);socket.onopen();const bind=socket.sent.at(-1);
 socket.onmessage({data:frame('auth.ack',bind.requestId,{status:'bound',userId:u,sessionId:sid,clientType:'WEB',sessionEpoch:1})});client.open(c);await tick();
 return {client,socket};
}
// Canonical 204 is not a JSON response. The server has already revoked successfully.
{
 const {client}=await setup(async url=>{assert.equal(url,'https://review.invalid/v1/auth/logout');return new Response(null,{status:204});});
 try {await client.logout();observed.push({case:'canonical-logout-204',notice:client.view().notice,session:client.view().session,expectedNotice:'已退出登录。',pass:client.view().notice==='已退出登录。'});}finally{client.dispose();}
}
// Timeout changes attempt state; a later correlated durable ACK still confirms it.
{
 const {client,socket}=await setup(async()=>{throw Error('No initial history request expected');},20);
 try {const rid=client.send('late durable acknowledgment');await new Promise(r=>setTimeout(r,35));assert.equal(client.repository.snapshot(c)[0].state,'FAILED');socket.onmessage({data:frame('message.ack',rid,{status:'committed',conversationId:c,messageId:id(800),seq:101,createdAt:'2026-10-09T09:00:00Z'})});const row=client.repository.snapshot(c)[0];observed.push({case:'late-durable-ack-after-timeout',state:row.state,requestId:rid,expectedState:'SENT',pass:row.state==='SENT'});}finally{client.dispose();}
}
// First live sequence101 starts page window. In-flight pull after101 holds a
// terminal response; a later realtime99 expands window and exposes missing100.
{
 const pulls=[];let resolvePage;
 const {client,socket}=await setup(async(url,options)=>{
  assert.equal(url,'https://review.invalid/v1/sync/conversation');const request=JSON.parse(options.body);pulls.push(request);
  if(pulls.length===1)return new Promise(r=>resolvePage=()=>r(json({syncVersion:'1.0',type:'sync.conversation.page',requestId:request.requestId,conversationId:c,messages:[],hasMore:false})));
  return json({syncVersion:'1.0',type:'sync.conversation.page',requestId:request.requestId,conversationId:c,messages:[message(100),message(101)].filter(m=>m.seq>request.afterSeq),hasMore:false});
 });
 try {
  const m101=message(101);const {requestId:r101,...p101}=m101;socket.onmessage({data:frame('message.created',r101,p101)});await tick();assert.equal(pulls.length,1);assert.equal(pulls[0].afterSeq,101);
  const m99=message(99);const {requestId:r99,...p99}=m99;socket.onmessage({data:frame('message.created',r99,p99)});assert.equal(client.repository.after(c),99n);
  resolvePage();await tick();await tick();await new Promise(r=>setTimeout(r,15));
  const seqs=client.repository.snapshot(c).map(m=>String(m.seq));observed.push({case:'late-realtime-crosses-terminal-sync',pullAfterSeq:pulls.map(p=>p.afterSeq),sequences:seqs,after:String(client.repository.after(c)),sync:client.view().sync,expectedSequences:['99','100','101'],pass:seqs.includes('100')&&client.repository.after(c)===101n});
 }finally{client.dispose();}
}
await fs.writeFile(new URL('./negative-observations.json',import.meta.url),JSON.stringify({observed},null,2)+'\n');
console.log(JSON.stringify({observed},null,2));
assert.ok(observed.every(v=>v.pass),'Independent required contract/convergence assertions failed; immutable observed failures retained');
