import audit,json
for job in [113859577525,113859300166,113859336690,113859562116,113859577448,113859562305,113859815406]:
 data=audit.run(str(job)+'-raw-log',[audit.GH,'api','--allow-escape-sequences',f'repos/nilesthump/IM-platform/actions/jobs/{job}/logs'])
 text=data.decode('utf8',errors='replace')
 if job==113859577525: print(text[-17000:])
 else:
  import re
  for line in text.splitlines():
   if any(x in line for x in ['HEAD is now','git log -1','BASE_SHA:','HEAD_SHA:','"jobs":','"web":','"desktop":','Ran ','OK','PASS','FAIL','PREREQUISITE','FULL_WEB','npm ci','behavior','regression','checkout_status','go=','web=','architecture=']):print(job,line[:500])
