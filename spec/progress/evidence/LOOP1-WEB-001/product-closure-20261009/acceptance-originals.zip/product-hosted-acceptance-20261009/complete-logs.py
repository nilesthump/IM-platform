import audit,re,json
for job in [113859300166,113859336690]:
 text=(audit.OUT/(str(job)+'-raw-log.log')).read_text();lines=[re.sub(r'^\d{4}-\d\d-\d\dT\S+\s','',l) for l in text.splitlines()];start=max(i for i,l in enumerate(lines) if '"jobs": {' in l);print('ACTUAL_FLAGS',job,'\n'.join(lines[start:start+16]));print('CTX',[l for l in lines if re.match(r'\s+(BASE_SHA|HEAD_SHA):',l)])
for job in [113862879566,113859577608,113859577421,113859562246,113859562463]:
 data=audit.run(str(job)+'-raw-log',[audit.GH,'api','--allow-escape-sequences',f'repos/nilesthump/IM-platform/actions/jobs/{job}/logs']);text=data.decode('utf8',errors='replace')
 for line in text.splitlines():
  if any(s in line for s in ['every selected','##[error]','FAIL:','HEAD is now','Ran 14','PASS Web','PASS appearance','actual locked Web']):print(job,line[:400])
