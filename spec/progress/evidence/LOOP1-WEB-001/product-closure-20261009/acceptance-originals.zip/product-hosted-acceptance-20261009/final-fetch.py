import audit,json,time,re
for sha in ['615cb06c70581aa474281b2dd9be80e59be88ec8','450c7bfb7bdc13b8d9cda0a629086c36e7dc39c7']:
 d=json.loads(audit.run('commit-'+sha,[audit.GH,'api',f'repos/nilesthump/IM-platform/git/commits/{sha}']));print('TREE',sha,d['tree']['sha'])
for rid in [37942242079,37908711315]:
 d=json.loads(audit.run(str(rid)+'-final-run',[audit.GH,'api',f'repos/nilesthump/IM-platform/actions/runs/{rid}']));print('RUN',rid,d['head_sha'],d['status'],d['conclusion'])
 pages=json.loads(audit.run(str(rid)+'-final-jobs',[audit.GH,'api','--paginate','--slurp',f'repos/nilesthump/IM-platform/actions/runs/{rid}/jobs?filter=all&per_page=100']));print('JOBS',[(j['id'],j['name'],j['status'],j['conclusion']) for p in pages for j in p['jobs']])
audit.run('native-unchanged',['git','diff','--exit-code','d4bb8200e7f5410d101a27ad58f8abb5eaa80f8f','615cb06c70581aa474281b2dd9be80e59be88ec8','--','clients/desktop','clients/shared','tools/verify_client_sqlite.py','tools/verify_client_send.py','tools/verify_client_sync.py','tests/clients/sync/go_smoke.py','deploy/compose.yaml','backend/go'])
for job in [113859300166,113859336690]:
 text=(audit.OUT/(str(job)+'-raw-log.log')).read_text();lines=[re.sub(r'^\d{4}-\d\d-\d\dT\S+\s','',l) for l in text.splitlines()];start=next(i for i,l in enumerate(lines) if '"jobs": {' in l);print('FLAGS',job,'\n'.join(lines[start:start+16]))
