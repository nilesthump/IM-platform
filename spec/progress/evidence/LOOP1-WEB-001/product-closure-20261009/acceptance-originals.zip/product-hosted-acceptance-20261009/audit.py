import os,subprocess,pathlib,json,time,hashlib
ROOT=pathlib.Path('H:/.codex/worktrees/w/IM-platform')
OUT=pathlib.Path('C:/Users/21441/.codex/visualizations/2026/10/08/01a11a79-95c1-79e2-a26b-9bcf56508973/web-task/product-hosted-acceptance-20261009')
PY='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
GH='C:/Program Files/GitHub CLI/gh.exe'
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_TRACE') and k not in ('GIT_CURL_VERBOSE','GH_DEBUG')};env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
def run(label,argv):
 t=time.monotonic();p=subprocess.run(argv,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);raw=p.stdout+p.stderr;(OUT/(label+'.log')).write_bytes(raw);r={'argv':argv,'exit_code':p.returncode,'elapsed_ms':round((time.monotonic()-t)*1000),'sha256':hashlib.sha256(raw).hexdigest()};(OUT/(label+'.receipt.json')).write_text(json.dumps(r,indent=2),encoding='utf8');print(label,p.returncode,r['elapsed_ms']);return p.stdout
if __name__=='__main__':
 import sys
 mode=sys.argv[1]
 if mode=='baseline':
  for label,args in [('root',['git','rev-parse','--show-toplevel']),('status',['git','status','--porcelain=v1']),('head',['git','rev-parse','HEAD']),('diff',['git','diff','d4bb8200e7f5410d101a27ad58f8abb5eaa80f8f','615cb06c70581aa474281b2dd9be80e59be88ec8','--stat']),('recent',['git','log','-6','--oneline']),('architecture',[PY,'-Xutf8','-B','ci/check_architecture.py','--scope','all','--json']),('frozen',[PY,'-Xutf8','-B','tools/verify_frozen_architecture.py'])]:
   data=run(label,args);print(data.decode('utf8',errors='replace')[:2500])
 elif mode=='fetch':
  stamp=str(time.time_ns())
  data=run('pr-'+stamp,[GH,'api','repos/nilesthump/IM-platform/pulls/29']);pr=json.loads(data);print('PR',pr['head']['sha'],pr['merge_commit_sha'],pr['base']['sha'])
  for rid in [37942242079,37942252613]:
   r=json.loads(run(str(rid)+'-run-'+stamp,[GH,'api',f'repos/nilesthump/IM-platform/actions/runs/{rid}']));print('RUN',rid,r['head_sha'],r['event'],r['status'],r['conclusion'])
   pages=json.loads(run(str(rid)+'-jobs-'+stamp,[GH,'api','--paginate','--slurp',f'repos/nilesthump/IM-platform/actions/runs/{rid}/jobs?filter=all&per_page=100']));jobs=[j for page in pages for j in page['jobs']];print('JOBS',[(j['id'],j['name'],j['status'],j['conclusion']) for j in jobs])
   for j in jobs:
    if j['status']=='completed' and j['conclusion']!='skipped' and not (OUT/(str(j['id'])+'-log.log')).exists():run(str(j['id'])+'-log',[GH,'api',f"repos/nilesthump/IM-platform/actions/jobs/{j['id']}/logs"])
