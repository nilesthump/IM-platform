from pathlib import Path
import subprocess,sys,json,time,hashlib,os
p=Path(__file__).parent; repo=Path('H:/.codex/worktrees/w/IM-platform'); py=sys.executable
git='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
pwsh='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
os.environ['PYTHONUTF8']='1'
def run(name,args):
 t=time.monotonic();r=subprocess.run(args,cwd=repo,capture_output=True); (p/(name+'.stdout.log')).write_bytes(r.stdout);(p/(name+'.stderr.log')).write_bytes(r.stderr)
 receipt={'argv':args,'exit':r.returncode,'elapsed_ms':round((time.monotonic()-t)*1000,1),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()};(p/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8'); print(json.dumps(receipt));print(r.stdout.decode('utf8',errors='replace')[-3500:]); assert r.returncode==0
assert subprocess.check_output([git,'-C',str(repo),'rev-parse','--show-toplevel']).decode().strip()==repo.as_posix()
assert subprocess.check_output([git,'-C',str(repo),'rev-parse','HEAD']).decode().strip()=='615cb06c70581aa474281b2dd9be80e59be88ec8'
assert subprocess.check_output([git,'-C',str(repo),'status','--porcelain=v1'])==b''
if sys.argv[1]=='baseline':
 run('baseline-all',[py,'-Xutf8','-B','ci/check_architecture.py','--scope','all','--json']);run('baseline-frozen',[py,'-Xutf8','-B','tools/verify_frozen_architecture.py'])
elif sys.argv[1]=='acceptance':
 run('clean-acceptance',[pwsh,'-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode','Acceptance']);run('diff-check',[git,'diff','--check','d4bb8200e7f5410d101a27ad58f8abb5eaa80f8f','HEAD'])
