from pathlib import Path
import subprocess,sys,json
p=Path(__file__).parent;repo=Path('H:/.codex/worktrees/w/IM-platform');common=[sys.executable,'-Xutf8','-B',str(repo/'tools/research/recorder.py')]
def rec(name,args):
 r=subprocess.run(common+args+['--repo',str(repo),'--research-root',str(p/'research'),'--run-id','R-WEB-METADATA-REVIEW-20261009'],cwd=repo,capture_output=True);(p/(name+'.stdout.log')).write_bytes(r.stdout);(p/(name+'.stderr.log')).write_bytes(r.stderr);print(r.stdout.decode('utf8',errors='replace'));assert r.returncode==0
rec('gap-final',['record-event','--event-type','instrumentation_warning','--data-json',json.dumps({'facts':'Direct-tool reads/private helper writes/messages are explicitly incomplete trace gaps. Missing audit-bindings.json read corrected by actual audit.json discovery. Two private audit wrappers failed on old historical list/file index schema; immutable failed helpers and command events retained; new dict/list and entry/file parsing succeeds with hashes unchanged. Finish invoked outside completed run-command wrappers. Postfinish report/seal private authoring gap. No product failure or verification weakening.'})])
rec('review-finished',['record-event','--event-type','review_finished','--data-json',json.dumps({'result':'PASS','scope':'Seven-file approval metadata independent Review only','candidate':'615cb06c70581aa474281b2dd9be80e59be88ec8','hosted':'PENDING','main_sync':'PENDING','stage':'S2 OPEN','lease':'RELEASED after seal'})])
rec('finish',['finish-run','--result','PASS']);rec('validate',['validate-run'])
