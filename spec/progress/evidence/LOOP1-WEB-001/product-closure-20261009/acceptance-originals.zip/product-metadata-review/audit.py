from pathlib import Path
import sys,json,hashlib,subprocess,zipfile,struct,time
p=Path(__file__).parent; private=p.parent; repo=Path('H:/.codex/worktrees/w/IM-platform'); git='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
def g(*a):return subprocess.check_output([git,'--no-replace-objects','-C',str(repo),*a]).decode('utf8').strip()
def h(b):return hashlib.sha256(b).hexdigest()
head='615cb06c70581aa474281b2dd9be80e59be88ec8'; parent='75f5e6b4f0b678d6ddda2f6765b418fec78f2472'; base='d4bb8200e7f5410d101a27ad58f8abb5eaa80f8f'; source='52c9762e1e8a943a3b513aa428182c339c9787ca'; capture='bc989a51bd14a15788b170b8623dd3e922f2eaf2'
assert g('rev-parse','HEAD')==head and g('rev-parse','--show-toplevel')==repo.as_posix() and not g('status','--porcelain=v1')
assert g('branch','--show-current')=='task/LOOP1-WEB-001-product'
evidence=repo/'spec/progress/evidence/LOOP1-WEB-001'; approved=evidence/'product-approval-20261009'
changed=g('diff','--name-only','--no-renames',parent,head).splitlines();assert len(changed)==7
assert set(changed)=={'spec/progress/current.md','spec/tasks/review/LOOP1-WEB-001.md',*[f'spec/progress/evidence/LOOP1-WEB-001/product-approval-20261009/{n}' for n in ['independent-approval.json','independent-originals.zip','metadata-command-originals.zip','metadata-verification.json','original-bindings.json']]}
full=g('diff','--name-only','--no-renames',base,head).splitlines()
for rel in full:assert rel.startswith(('clients/web/src/','tests/clients/web/','spec/progress/evidence/LOOP1-WEB-001/')) or rel in ['clients/web/package.json','clients/web/package-lock.json','clients/web/tsconfig.json','spec/progress/current.md','spec/tasks/backlog/LOOP1-WEB-001.md','spec/tasks/review/LOOP1-WEB-001.md'],rel
trees={}
for rel in ['clients/web','clients/shared','tests/clients/web','spec/architecture','spec/domain','spec/invariants','spec/acceptance','spec/governance','contracts','tests/architecture','ci','.github','clients/desktop']:
 vals={r:g('rev-parse',f'{r}:{rel}') for r in [head,parent]};assert len(set(vals.values()))==1;trees[rel]=vals
for rel in ['clients/web','clients/shared','spec/architecture','spec/domain','spec/invariants','spec/acceptance','spec/governance','contracts','tests/architecture']:
 assert g('rev-parse',f'{head}:{rel}')==g('rev-parse',f'{source}:{rel}')
assert g('rev-parse',f'{head}:tests/clients/web')==g('rev-parse',f'{capture}:tests/clients/web')
assert not g('diff',base,head,'--','spec/architecture','contracts','clients/shared','clients/desktop','ci','.github','tests/architecture','tests/ci','backend')
archive_checks=[]
for directory in [approved,evidence/'product-fix-20261009-d']:
 index=json.loads((directory/'original-bindings.json').read_text(encoding='utf8')); z=zipfile.ZipFile(directory/'independent-originals.zip');entries=index['entries'] if isinstance(index,dict) else index; assert len(z.namelist())==len(entries)==len(set(z.namelist()))
 for e in entries:
  e=dict(e,entry=e.get('entry',e.get('file')));raw=z.read(e['entry']);assert h(raw)==e['sha256'] and len(raw)==e.get('bytes',len(raw)); original=private/e['entry']; assert original.is_file() and raw==original.read_bytes(),e['entry']
 archive_checks.append({'path':str(directory/'independent-originals.zip'),'entries':len(entries),'sha256':h((directory/'independent-originals.zip').read_bytes())})
assert archive_checks[0]['entries']==101
meta=json.loads((approved/'metadata-verification.json').read_text(encoding='utf8')); z=zipfile.ZipFile(approved/'metadata-command-originals.zip');assert len(z.namelist())==8
for i,r in enumerate(meta['results']):
 assert r['exit']==0
 for side in ['stdout','stderr']:assert h(z.read(f'{i}-{side}.log'))==r[f'{side}_sha256']
approval=json.loads((approved/'independent-approval.json').read_text(encoding='utf8')); assert approval['candidate']==parent and approval['base']==base and approval['product_source']==source and approval['harness_capture_source']==capture
for name,r in approval['independent_results'].items():
 assert h((private/name/'report.md').read_bytes())==r['report'] and h((private/name/'seal.json').read_bytes())==r['seal']
 assert 'PASS' in (private/name/'report.md').read_text(encoding='utf8') and r['actor']!='/root'
assert h((private/'product-review-b/report.md').read_bytes())=='7eb65ef20a54c39706a1e5b3743442adc159c5c18f30271244699ba009a5fe31'
assert h((private/'product-review-b/seal.json').read_bytes())=='fbfb27a2dda955c4a3207a2dfa4860d25eeae935c665c627b5ad2121a91a4d80'
screens=evidence/'product-fix-20261009-d/screens/chromium-e'; m=json.loads((screens/'manifest.json').read_text(encoding='utf8')); b=json.loads((evidence/'product-fix-20261009-d/build-provenance-latest.json').read_text(encoding='utf8'))
assert h((screens/'manifest.json').read_bytes())==approval['manifest_sha256'];assert h((screens/'protocol-proof.json').read_bytes())==approval['proof_sha256'];assert len(m['entries'])==52 and m['candidate_sha']==capture
for e in m['entries']:
 raw=(screens/e['file']).read_bytes(); assert h(raw)==e['sha256'] and raw[:8]==b'\x89PNG\r\n\x1a\n'; w,ht=struct.unpack('>II',raw[16:24]);assert w==e['viewport']['width'] and ht>=e['viewport']['height']
for rel,sha in b['source_files'].items():assert h((repo/'clients/web'/rel).read_bytes())==sha
for rel,sha in b['build_files'].items():assert h((Path(m['build_origin'])/rel).read_bytes())==sha
assert h((repo/'tests/clients/web/browser.mjs').read_bytes())==b['harness_sha256']
proof=json.loads((screens/'protocol-proof.json').read_text(encoding='utf8'));r=proof['reconnection'];assert r['before']['connectionId']==1 and r['replacement']['connectionId']==2 and r['replacement']['event']>r['before']['event']
for key in ['userId','sessionId','clientType','sessionEpoch']:assert r['before'][key]==r['replacement'][key]
assert r['header']=='在线' and r['old_sync_notice_present'] and not r['old_sync_notice_satisfies_header'] and r['held_new_pull_loading_then_completed']
for pull in r['post_bind_pulls']:assert pull['event']>r['replacement']['event'] and pull['observedBind']==2 and pull['activeConnections']==[2] and pull['body']['afterSeq']==106
assert [n['expected_seq'] for n in proof['narrow_send_identity']]==[107,108]
for n in proof['narrow_send_identity']:assert not n['new_message_initially_sent'] and n['same_article_sending_to_sent'] and n['rendered_expected_sequence']
assert proof['logout_status']==204 and not proof['pageerrors']
tasks=list((repo/'spec/tasks').glob('*/LOOP1-WEB-001.md'));assert len(tasks)==1 and tasks[0].parent.name=='review';task=tasks[0].read_text(encoding='utf8');assert '\nstatus: review\n' in task and 'REVIEWED_PENDING_HOSTED_ACCEPTANCE' in task
current=(repo/'spec/progress/current.md').read_text(encoding='utf8');assert 'Current Task: LOOP1-WEB-001' in current and 'Current Task State: review' in current and 'Gate Status: OPEN' in current and base in current and 'synchronization pending' in current and 'STOP before S2 Stage Gate' in current
assert g('rev-parse','HEAD')==head and not g('status','--porcelain=v1')
result={'result':'PASS','candidate':head,'parent':parent,'base':base,'source':source,'capture':capture,'delta_paths':changed,'fullrange_count':len(full),'fullrange_paths':full,'trees':trees,'archive_checks':archive_checks,'metadata_receipts_verified':4,'screens_verified':52,'source_files':len(b['source_files']),'build_files':len(b['build_files']),'independent_reports_bound':approval['independent_results'],'clean':True,'task_state':'review','hosted_acceptance':'PENDING','main_sync':'PENDING'}
(p/'audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps({k:result[k] for k in ['result','candidate','fullrange_count','archive_checks','screens_verified','source_files','build_files','clean']}))
