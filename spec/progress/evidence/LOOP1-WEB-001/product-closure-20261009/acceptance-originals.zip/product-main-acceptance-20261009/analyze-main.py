import sys,pathlib,json,re,hashlib
sys.path.insert(0,str(pathlib.Path(__file__).parent.parent/'product-hosted-acceptance-20261009'));import audit
audit.OUT=pathlib.Path(__file__).parent
rid=(audit.OUT/'run-id.txt').read_text();jf=sorted(audit.OUT.glob(rid+'-jobs-*.log'))[-1];jobs=[j for p in json.loads(jf.read_text(encoding='utf8')) for j in p['jobs']];review={}
for j in jobs:
 if j['conclusion']=='skipped':continue
 f=audit.OUT/(str(j['id'])+'-raw-log.log');text=f.read_text(encoding='utf-8-sig');assert 'a1b154d06c0a9d191ec8dca514fff3ab1b46ee25' in text;assert '##[error]' not in text
 unexpected=[s for s in j['steps'] if s['conclusion']!='success'];assert not unexpected,(j['name'],unexpected)
 lines=[re.sub(r'^\d{4}-\d\d-\d\dT\S+\s','',l) for l in text.splitlines()]
 review[j['name']]={'id':j['id'],'checkout':'a1b154d06c0a9d191ec8dca514fff3ab1b46ee25','conclusion':j['conclusion'],'started_at':j['started_at'],'completed_at':j['completed_at'],'log_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'semantic_lines':[l for l in lines if any(s in l for s in ['PASS:', 'PASS Web','PASS appearance','Ran ','"result": "PASS"','BASE_SHA:','HEAD_SHA:']) and len(l)<600]}
 if j['name']=='classify':
  start=max(i for i,l in enumerate(lines) if '"jobs": {' in l);flags=json.loads('\n'.join(lines[start:start+16]).strip().rstrip(','))['jobs'] if False else {m.group(1):m.group(2)=='true' for l in lines[start:start+16] if (m:=re.search(r'"(\w+)": (true|false)',l))};review['classifier_flags']=flags
  print('FLAGS',flags);print('CTX',[l for l in lines if re.match(r'\s+(BASE_SHA|HEAD_SHA):',l)])
 for l in review[j['name']]['semantic_lines'][-8:]:print(j['name'],l)
required={'classify','architecture','source_java','source_go','web','gate'};assert {j['name'] for j in jobs if j['conclusion']=='success'}==required
assert {k for k,v in review['classifier_flags'].items() if v}=={'web','architecture','source_go','source_java'}
for j in jobs:
 if j['conclusion']=='skipped':assert review['classifier_flags'][j['name']]==False
(audit.OUT/'actual-job-review.json').write_text(json.dumps(review,indent=2),encoding='utf8');print('PASS main semantics and required-job coverage')
