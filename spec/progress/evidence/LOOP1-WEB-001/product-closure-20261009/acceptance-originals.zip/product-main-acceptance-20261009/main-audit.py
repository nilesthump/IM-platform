import sys,pathlib,json,time,hashlib,re
sys.path.insert(0,str(pathlib.Path(__file__).parent.parent/'product-hosted-acceptance-20261009'));import audit
audit.OUT=pathlib.Path(__file__).parent
MAIN='a1b154d06c0a9d191ec8dca514fff3ab1b46ee25';CAND='615cb06c70581aa474281b2dd9be80e59be88ec8';BASE='d4bb8200e7f5410d101a27ad58f8abb5eaa80f8f'
if sys.argv[1]=='baseline':
 # Retained preceding independent audit read each authority file; verify actual-main bytes unchanged before relying on them.
 files=['spec/architecture/README.md','spec/architecture/baseline.md','spec/architecture/frozen-architecture.md','spec/governance/minimality.md','spec/governance/execution-boundaries.md','spec/governance/independent-review.md','spec/governance/technology-selection.md','spec/architecture/decisions/ADR-0005-client-technology-clarification.md','spec/architecture/decisions/ADR-0006-client-ui-architecture.md','spec/architecture/decisions/ADR-0007-client-mvp-task-planning.md','spec/architecture/decisions/ADR-0011-web-appearance-storage.md','spec/domain/messaging.md','spec/invariants/messaging.md','spec/domain/sync-plugin.md','spec/invariants/sync-plugin.md','spec/architecture/decisions/client-ui/architecture.md','spec/architecture/decisions/client-ui/design-direction.md','spec/acceptance/client-gui.md','.github/workflows/ci.yml','ci/classify.py','ci/check_gate.py','contracts/websocket/envelope.schema.json','contracts/websocket/sync-v1.schema.json']
 data=audit.run('authority-unchanged',['git','diff','--exit-code',CAND,MAIN,'--',*files]);assert not data
 (audit.OUT/'authority-bindings.json').write_text(json.dumps({f:hashlib.sha256((audit.ROOT/f).read_bytes()).hexdigest() for f in files},indent=2),encoding='utf8')
 for label,args in [('root',['git','rev-parse','--show-toplevel']),('status',['git','status','--porcelain=v1']),('head',['git','rev-parse','HEAD']),('branch',['git','branch','--show-current']),('diff',['git','diff',CAND,MAIN,'--']),('recent',['git','log','-4','--oneline']),('architecture',[audit.PY,'-Xutf8','-B','ci/check_architecture.py','--scope','all','--json']),('frozen',[audit.PY,'-Xutf8','-B','tools/verify_frozen_architecture.py'])]:
  out=audit.run(label,args);print(out.decode('utf8',errors='replace')[:350])
if sys.argv[1]=='fetch':
 stamp=str(time.time_ns())
 pr=json.loads(audit.run('pr-'+stamp,[audit.GH,'api','repos/nilesthump/IM-platform/pulls/29']));print('PR',pr['state'],pr['merged_at'],pr['merge_commit_sha'],pr['head']['sha'],pr['base']['sha'])
 trees=[]
 for sha in [CAND,MAIN]:
  d=json.loads(audit.run('commit-'+sha+'-'+stamp,[audit.GH,'api',f'repos/nilesthump/IM-platform/git/commits/{sha}']));trees.append(d['tree']['sha']);print('COMMIT',sha,'TREE',d['tree']['sha'],'PARENTS',[p['sha'] for p in d['parents']]);
  if sha==MAIN:assert [p['sha'] for p in d['parents']]==[BASE,CAND]
 assert len(set(trees))==1
 pages=json.loads(audit.run('runlist-'+stamp,[audit.GH,'api','--paginate','--slurp',f'repos/nilesthump/IM-platform/actions/runs?head_sha={MAIN}&event=push&per_page=100']));runs=[r for p in pages for r in p['workflow_runs']];print('RUNS',[(r['id'],r['name'],r['head_sha'],r['status'],r['conclusion'],r['run_attempt']) for r in runs]);required=[r for r in runs if r['name']=='Loop 1 CI'];assert len(required)==1
 rid=required[0]['id'];(audit.OUT/'run-id.txt').write_text(str(rid))
 pages=json.loads(audit.run(str(rid)+'-jobs-'+stamp,[audit.GH,'api','--paginate','--slurp',f'repos/nilesthump/IM-platform/actions/runs/{rid}/jobs?filter=all&per_page=100']));jobs=[j for p in pages for j in p['jobs']];print('JOBS',[(j['id'],j['name'],j['status'],j['conclusion']) for j in jobs])
 for j in jobs:
  label=str(j['id'])+'-raw-log'
  if j['status']=='completed' and j['conclusion']!='skipped' and not (audit.OUT/(label+'.log')).exists():
   data=audit.run(label,[audit.GH,'api','--allow-escape-sequences',f"repos/nilesthump/IM-platform/actions/jobs/{j['id']}/logs"])
   text=data.decode('utf8-sig',errors='replace') if False else data.decode('utf-8-sig',errors='replace')
   selected=[l for l in text.splitlines() if any(s in l for s in ['PASS Web','PASS appearance','PASS: every selected','FAIL:','##[error]','Ran ','HEAD is now']) and len(l)<450];print(j['name'],'\n'.join(selected[-8:]))
