# Independent actual-main hosted acceptance: PASS

Task LOOP1-WEB-001. Exact actual-main a1b154d06c0a9d191ec8dca514fff3ab1b46ee25; candidate615cb06c70581aa474281b2dd9be80e59be88ec8; prior accepted/synchronized main d4bb8200e7f5410d101a27ad58f8abb5eaa80f8f; branch task/LOOP1-WEB-001-product assigned H:/.codex/worktrees/w/IM-platform. Auditor /root/web_product_hosted_acceptance is the same independent hosted auditor, neither implementer/fixer nor local code/metadata Reviewer; new actual-main run, fresh_context=false. This PASS is actual-main hosted acceptance only, not main workspace synchronization, Task done or S2 Stage Gate PASS.

## Recovery, authority and clean method

Mandatory agent-context/current/exact unique review Task read in actual assigned checkout; Task remains review, S1 accepted/S2 OPEN. Prior independent authority/client/domain/invariants/contracts/UI/minimality/execution/technology/checklist reads retained in this continuous auditor context. Readonly authority comparison615..a1 exit0 and whole Git diff615..a1 empty demonstrate every referenced current authority/input/source byte remains identical. authority-bindings.json seals resolver/manifest/canonical/ADRs/governance/domain/invariants/UI/contracts/workflow hashes. Canonical2ba864fc2805900117f62c3c88795c52364ecc7450da17975e26d35ebf2cc432 and historical PDF provenance validated by minimum frozen verifierexit0/94ms; architecture all --json exit0/516ms. Initial/final Git root exactly assigned, porcelain empty, HEADA1; diff/recent inspected. Exact argv/exits/elapsed/raw hashes are retained in receipt files/command-index.json and Recorder wrappers. No write to repository or H:/IM-platform main performed.

## Protected merge and tree binding

Read-only PR29 API confirms stateclosed, merged_at2026-10-09T14:35:04Z, merge_commit_sha a1, head615/base d4. Independent git-commit API confirms actual-main exactly two ordered parents[d4bb8200e7f5410d101a27ad58f8abb5eaa80f8f,615cb06c70581aa474281b2dd9be80e59be88ec8]. Candidate and main entire tree identical07ebea7ab3c70c1e923beb8528529b565065a0ad. No inference that commit IDs are identical. Final git/ref/heads/main API resolves actuala1. Parent coordinator records ordinary protected merge --match-head-commit615 without admin/bypass; this auditor performed no merge or remote mutation. Product52/harnessbc/local approvals remain bound through exact identical accepted candidate tree, not replaced by hosted acceptance.

## Actual-main own hosted run and required jobs

New own run37945266468 Loop1CI push event, exacthead a1, attempt1 completedSUCCESS. Discovered through paginated head_sha/event-filter API, not inherited candidate result. All actual jobs retrieved using paginated filterall/per_page100. Final actual classifier output after negative-control fixture stdout: BASE_SHA d4; HEAD_SHA a1; web/architecture/source_go/source_java true; other10 flags false. Workflow hashf972042f51af0f28b09f01567391c3be812d1ec84571d09102c0ae5ae1c8fb72 maps this selection to6 actual required jobs. All selected job checkouts independently inspected actuala1 from raw checkout log SHA and all selected steps actualSUCCESS; no missing/failed/cancelled/timedout/anomalous skipped requirement.

| Required job | Actual job ID | Conclusion |
| --- | --- | --- |
| classify | 113869787813 | SUCCESS |
| source_java | 113870003827 | SUCCESS |
| architecture | 113870003878 | SUCCESS |
| web | 113870003941 | SUCCESS |
| source_go | 113870003975 | SUCCESS |
| gate | 113870270007 | SUCCESS |

Seven false-condition inactive entries normally skipped: go113870005579/deploy113870005708/compatibility113870005830/java113870005906/mobile113870006307/shared113870006522/desktop113870006731. Matrix is inactive for Desktop false. They are legitimate workflow conditions, not missing required14 jobs; first branch push all14 selection is not applied to selective actualmain diff. No suite/browser fallback or unexpected failed/skipped selected step observed. Aggregate113870270007 raw log explicit PASS every selected CI job succeeded.

## Real product verification

classify113869787813 clean RecoveryAcceptance PASS unique review, actual CI34 controlsOK. architecture113870003878 actual frozen semantic suite56OK, governance/client source guardPASS and architecture positive/negative suite56OK. HostedLinux real symlink controls ran without historical localWindows permissions skips; no local skip is counted as hosted success. source_java/source_go actual source ownership/dependency checksPASS exactmain; imported runtime graph checked through accepted checker plus prior independent implementation Review.

web113870003941 actual14 negative controlsOK. Skeleton text is isolated negative-control fixture evidence and is followed by real product verification: locked npmci, npm build/TypeScript actual compiler, actual clients source guardPASS, node behaviorPASS exact auth/contracts/noinitialbackfill/memory/retry/SENT/gap/rollback/refresh/logout/stale isolation; explicit regressionsPASS lateACK both terminal crossing directions/pagination rollback/missinggap retry/legal logout204; actual appearancePASS strictbounded values/restart/theme independence/unavailable storage/unrelated key preservation. Final actual locked Web build/behavior/appearance/source verificationPASS. Every selected step completedSUCCESS; no product skeleton-only fallback. Actual-job-review.json and raw logs/receipts preserve precise checkouts, times, line evidence and hashes.

## Prior candidate history and limits

Candidate push37942242079 attempt1FAIL Linux113859577525/aggregate113862879566 preserved; cause beyond Compose up -d --build generic error remains unknown. Candidate attempt2 effective14SUCCESS comprised12 reused successes with identical raw bytes/timestamps plus actual rerun Linux113865709476 and gate113867390977; PR37942252613 selected6SUCCESS/7properinactive. Independent candidate report f006f6fc2b87013aefba20eec64f6217055f6e035b147c2301cb06df91a941ed/seal f843ec4b539646be33173be8ee1050e543b8a5c36dc79fe895d33e0cc52a78ec retained immutable in prior sibling. Those results did not establish this actualmain PASS; new run37945266468 did. Retry success does not prove transient cause. Original visual/semantic/metareview approvals remain separate; no new screenshot claims.

New private RecorderR-WEB-PRODUCT-MAIN-20261009 review/prospective_resume registered exact delegated prompt. Initial direct startup reads before Recorder and private script creation/direct instrumentation gaps explicitly disclosed; no assertion of complete trace. Recorder wrappers/real command receipts retained, all wrappers returned before finish/validate outside wrappers. No new test/check failure occurred in this actualmain audit; initial tool pending approval yielded normally before real execution, not a fabricated failure. Prior run mistakes/failures remain immutable. Recorder structural validation is distinct from product/task/Stage acceptance.

## Handoff and ownership

Actual-main hosted acceptance PASS bounded exacta1/run37945266468. Root may perform authorized preservation-aware synchronization to H:/IM-platform afterward; this auditor neither reads unknown main files nor writes/synchronizes main. Current Task remainsreview until synchronization/closure process, S2 OPEN. Last known good synchronized main remainsd4 until separate verified sync. Auditor owns private outputs only; no repository writes. Readonly actual-main audit lease RELEASED after seal. Do not evaluate S2StageGate/EdgeQA/helper regression/nexttask.
