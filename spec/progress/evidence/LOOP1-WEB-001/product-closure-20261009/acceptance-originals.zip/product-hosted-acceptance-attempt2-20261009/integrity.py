import sys,pathlib,json,hashlib,re
sys.path.insert(0,str(pathlib.Path(__file__).parent.parent/'product-hosted-acceptance-20261009'));import audit
audit.OUT=pathlib.Path(__file__).parent
pr=json.loads(audit.run('pr-current',[audit.GH,'api','repos/nilesthump/IM-platform/pulls/29']));print('PR',pr['state'],pr['head']['sha'],pr['base']['sha'],pr['merge_commit_sha']);assert pr['head']['sha']=='615cb06c70581aa474281b2dd9be80e59be88ec8'
trees=[]
for sha in [pr['head']['sha'],pr['merge_commit_sha']]:
 d=json.loads(audit.run('commit-'+sha,[audit.GH,'api',f'repos/nilesthump/IM-platform/git/commits/{sha}']));trees.append(d['tree']['sha']);print('TREE',sha,d['tree']['sha'])
assert len(set(trees))==1
bindings={}
for rel in ['.github/workflows/ci.yml','ci/classify.py','ci/check_gate.py','spec/architecture/frozen-architecture.md','spec/architecture/baseline.md','tests/clients/web/verify.py','contracts/websocket/envelope.schema.json','contracts/websocket/sync-v1.schema.json']:
 bindings[rel]=hashlib.sha256((audit.ROOT/rel).read_bytes()).hexdigest()
(audit.OUT/'authority-workflow-bindings.json').write_text(json.dumps(bindings,indent=2),encoding='utf8');print('BINDINGS',bindings)
