import sys,pathlib,json,re
sys.path.insert(0,str(pathlib.Path(__file__).parent.parent/'product-hosted-acceptance-20261009'));import audit
audit.OUT=pathlib.Path(__file__).parent
for job in [113865709476,113867390977]:
 text=(audit.OUT/(str(job)+'-raw-log.log')).read_text(encoding='utf-8-sig');selected=[l for l in text.splitlines() if any(s in l for s in ['PASS:', 'HEAD is now','##[error]','FAIL:','Starting bounded'])];print(job,'\n'.join(selected))
 assert '##[error]' not in text
 if job==113865709476:assert 'actual Desktop SQLx orchestration -> trusted TLS/Gateway/Core/PG' in text
 if job==113867390977:assert 'PASS: every selected CI job succeeded' in text


