import sys,pathlib,json,time,re
sys.path.insert(0,str(pathlib.Path(__file__).parent.parent/'product-hosted-acceptance-20261009'))
import audit
audit.OUT=pathlib.Path(__file__).parent
if sys.argv[1]=='baseline':
 for label,args in [('root',['git','rev-parse','--show-toplevel']),('status',['git','status','--porcelain=v1']),('head',['git','rev-parse','HEAD']),('branch',['git','branch','--show-current']),('architecture',[audit.PY,'-Xutf8','-B','ci/check_architecture.py','--scope','all','--json']),('frozen',[audit.PY,'-Xutf8','-B','tools/verify_frozen_architecture.py'])]:
  out=audit.run(label,args);print(out.decode('utf8',errors='replace')[:150])
if sys.argv[1]=='fetch':
 stamp=str(time.time_ns())
 for rid,attempt in [(37942242079,1),(37942242079,2),(37942252613,1)]:
  d=json.loads(audit.run(f'{rid}-a{attempt}-run-{stamp}',[audit.GH,'api',f'repos/nilesthump/IM-platform/actions/runs/{rid}/attempts/{attempt}']));print('RUN',rid,attempt,d['head_sha'],d['run_attempt'],d['status'],d['conclusion'])
  pages=json.loads(audit.run(f'{rid}-a{attempt}-jobs-{stamp}',[audit.GH,'api','--paginate','--slurp',f'repos/nilesthump/IM-platform/actions/runs/{rid}/attempts/{attempt}/jobs?per_page=100']));jobs=[j for p in pages for j in p['jobs']];print('JOBS',rid,attempt,[(j['id'],j['name'],j['status'],j['conclusion']) for j in jobs])
  for j in jobs:
   label=str(j['id'])+'-raw-log'
   if j['status']=='completed' and j['conclusion']!='skipped' and not (audit.OUT/(label+'.log')).exists():
    data=audit.run(label,[audit.GH,'api','--allow-escape-sequences',f"repos/nilesthump/IM-platform/actions/jobs/{j['id']}/logs"])
    if j['conclusion']=='failure':print(data.decode('utf8',errors='replace')[-4500:])
