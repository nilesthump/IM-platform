import sys,pathlib,json,hashlib,re
sys.path.insert(0,str(pathlib.Path(__file__).parent.parent/'product-hosted-acceptance-20261009'));import audit
audit.OUT=pathlib.Path(__file__).parent
status=audit.run('final-status',['git','status','--porcelain=v1']);head=audit.run('final-head',['git','rev-parse','HEAD']);assert not status and head.decode().strip()=='615cb06c70581aa474281b2dd9be80e59be88ec8'
def jobs(rid,a):
 f=sorted(audit.OUT.glob(f'{rid}-a{a}-jobs-*.log'))[-1];return [j for p in json.loads(f.read_text()) for j in p['jobs']]
a2=jobs(37942242079,2);assert len(a2)==14 and all(j['conclusion']=='success' for j in a2)
pr=jobs(37942252613,1);assert len(pr)==13 and sum(j['conclusion']=='success' for j in pr)==6 and sum(j['conclusion']=='skipped' for j in pr)==7
lineage=json.loads((audit.OUT/'attempt-lineage.json').read_text());assert sum(x['reused'] for x in lineage)==12 and all(x.get('raw_bytes_equal',True) for x in lineage)
rows='\n'.join(f"| {x['name']} | {x['attempt1_id']} | {x['attempt2_id']} | {'reused successful execution; identical raw bytes' if x['reused'] else 'actually rerun'} |" for x in lineage)
report='''# Independent candidate hosted acceptance: PASS after attempt2

Task LOOP1-WEB-001; candidate615cb06c70581aa474281b2dd9be80e59be88ec8; branch task/LOOP1-WEB-001-product; range d4bb8200e7f5410d101a27ad58f8abb5eaa80f8f..615cb06c70581aa474281b2dd9be80e59be88ec8; PR29 nilesthump/IM-platform. Bounded candidate hosted acceptance only: Task remains review, main integration/actual-main acceptance/safe synchronization pending, S2 OPEN. No Stage Gate PASS or Task done.

## Independence, clean state and authority

Auditor /root/web_product_hosted_acceptance is the independent auditor from attempt1, neither implementer/fixer nor product/metadata local Reviewer. New delegated retry, exact visible delegated prompt registration and new private Recorder run; fresh_context=false truthfully. Initial/final porcelain empty; assigned Git root exactly H:/.codex/worktrees/w/IM-platform; HEAD615 and current branch verified. Startup authority/current/task reads retained from immediately preceding attempt1 audit; candidate unchanged, exact unique review state reaffirmed. Canonical manifest/current hash2ba864fc2805900117f62c3c88795c52364ecc7450da17975e26d35ebf2cc432; frozen/ADRs/client technology/source/contract/domain/invariants/UI/minimality/acceptance obligations already independently read. New minimum architecture --scope all --json exit0/813ms and frozen exit0/94ms. Actual bytes bound authority-workflow-bindings.json. Exact argv, command exit/time/raw hash in receipts/command-index.json and Recorder blobs.

## Final required jobs and every attempt

Push run37942242079 exacthead615 attempt1 remains completedFAIL; Linux113859577525 and aggregate113862879566 failed. Immutable first FAIL reportSHA5997870fa0479016a40118292e0d02b25afe2b9e1eb8ed22dfdb1b05adfe5290 and sealSHA008200c1bf54e82049a5fc505d2785177251c93b8dee91108882d1f26671f268 remain in sibling product-hosted-acceptance-20261009. Original attempt1 actual run/jobs/logs independently retrieved in this folder as well. Failure at compose up -d --build; generic captured/discarded exception precluded identifying root cause. Retry success does not prove an external transient cause.

Root explicitly authorized and performed one normal --failed rerun at unchangedhead615, no source/CI mutation. Push attempt2 final completedSUCCESS;14 required actual job entries allSUCCESS. Attempt-specific paginated API/jobs inspected rather than headline.12 successful executions are carried from attempt1: GitHub assigned new alias IDs in attempt2 metadata, but original start/end times and byte-identical raw logs prove reuse. Only LinuxDesktop and aggregate actually reran. No claim of all14 rerunning.

| Job | Attempt1 original ID | Attempt2 ID | Execution provenance |
| --- | --- | --- | --- |
'''+rows+'''

Actual classifier final JSON (after negative-control test fixture stdout) has BASE_SHA allzero and HEAD_SHA615, all14 flags true. Candidate workflow maps them to architecture/source_go/source_java/go/java/web/Desktop2OS/mobile/shared/compatibility/deploy plus unconditional classify/gate,14 actual required jobs. old_client/plugin/migration are delegated compatibility obligations, not standalone missing job names. Actual aggregate log allselectedSUCCESS. No missing/failed/cancelled/timed-out/anomalously skipped required job remains. Linux-only/Windows-only Desktop steps are mutually exclusive by runner.os; both actual platform jobs passed, opposite platform steps normally skipped.

PR run37942252613 attempt1 final completedSUCCESS exacthead615: actual final classifier base d4/head615 flags web/architecture/source_go/source_java true and other10 false. Six actual required jobsSUCCESS classify113859336690/web113859562116/architecture113859562305/source_go113859562463/source_java113859562246/gate113859815406. Seven unselected entries skipped under exact false job conditions java/go/shared/mobile/deploy/desktop/compatibility. No synthetic conclusion from PR summary alone.

## Actual runtime, controls and checkout provenance

New Linux113865709476 checkout exact615, actual native prerequisites and SQLx/send/controlled Sync completedSUCCESS;14:29:30.3538812Z explicit PASS actual Desktop SQLx orchestration -> trusted TLS/Gateway/Core/PG;208metadata205durableMessages,continuous pages/terminal/restart/new206th/read-only; owned Compose cleanupPASS. New aggregate113867390977 explicit14:29:44.8982899Z PASS every selected CI job succeeded. No actual failed step or suite fallback.

Inherited WindowsDesktop actual approved npmci/build/auth/cargo lockedlib/native Tauri Windows bundle assembly jobSUCCESS; inherited Mobile real Android emulator/KVM/SDK SQLite/send/Sync/GUI stepsSUCCESS. Go actual DB/NATS/build/vet/race/contract and deploy real TLS roles/shared Sync/public Sync/E2E and Java smokeSUCCESS; shared actual TS+contract fixtures/compatibility migrations/client source full Web verificationSUCCESS. All corresponding raw logs retained and inspected against actual workflow, not substituted historical results. semantic-log-review.json preserves concise selected evidence; raw logs authoritative.

Both Web job logs execute14 negative controlsOK then actual locked npmci/build/TypeScript compilation, behavior and explicit lateACK/both terminal crossing/pagination rollback/missing-gap retry/legal logout204 regressionsPASS, appearance bounded validation/restart/independence/unavailable-storage/unrelated-keyPASS, actual clients source guardPASS. Skeleton-only text occurs inside isolated negative test fixtures, not final product fallback. No initial history backfill/business persistence or unapproved deps/runtime accepted. Existing local screenshots/Architect and semantic implementation Review are distinct acceptance obligations already sealed by parent; hosted tests do not substitute them.

Architecture actual frozen semantic tests56OK, governance/client source guardPASS and checker controls56OK; classify clean Recovery Acceptance and CI34OK. HostedLinux symlink tests actually run; localWindows prior4skips do not replace them. source_go/source_java actual ownership checksSUCCESS.

PR architecture/source/gate checkouts synthetic merge450c7bfb7bdc13b8d9cda0a629086c36e7dc39c7, while classify/Web exact615. Independently repeated read-only git-commit API shows candidate615 and synthetic450 both wholeTREE07ebea7ab3c70c1e923beb8528529b565065a0ad. Different commit identities are not conflated. Current PR open/head615/base d4 verified; no actual main integration yet.

## Research and limitations

New Recorder R-WEB-PRODUCT-HOSTED-ATTEMPT2-20261009 review/prospective. Registered exact delegated prompt retained; original first failure/startup gaps remain historical and are not represented as prospective retry events. File creation/direct tool inspection remain tool-to-file capture gaps; underlying subprocess receipts supply exact argv/exits/time/hash and wrapper Recorder output. Initial direct log read failed defaultGBK, then wrapped inspection failed unknown encoding spelling and an inaccurate expected excerpt; failures remain immutable Recorder outputs plus original private scripts. Correct explicitUTF-8 and exact observed runtime excerpt inspection exit0; no acceptance/test/source behavior weakened. These are auditor inspection errors, not hosted job failures. All wrapped commands returned before finish/validate outside wrappers. Recorder validation does not establish Task/StagePASS.

## Handoff

Candidate hosted acceptance PASS after independently audited attempt2 effective14SUCCESS plus PR6SUCCESS/7properinactive; original failedattempt1 retained. Root may continue authorized protected merge, new actual-main hosted audit and safe synchronization; no self-declared completion or bypass. No auditor source/state/remote changes/rerun/merge/comments/main writes. Last known good synchronized main d4bb8200e7f5410d101a27ad58f8abb5eaa80f8f; source unchanged clean615. Sole private evidence owner auditor. Read-only candidate audit lease RELEASED after seal; stop before S2 StageGate/EdgeQA/helper regression.
'''
(audit.OUT/'report.md').write_text(report,encoding='utf8')
(audit.OUT/'command-index.json').write_text(json.dumps({f.name:json.loads(f.read_text()) for f in audit.OUT.glob('*.receipt.json')},indent=2),encoding='utf8');print('report_sha256',hashlib.sha256((audit.OUT/'report.md').read_bytes()).hexdigest())
