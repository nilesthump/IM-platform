import sys,pathlib,json,re,hashlib
sys.path.insert(0,str(pathlib.Path(__file__).parent.parent/'product-hosted-acceptance-20261009'));import audit
audit.OUT=pathlib.Path(__file__).parent
def jobs(rid,a):
 f=sorted(audit.OUT.glob(f'{rid}-a{a}-jobs-*.log'))[-1];return [j for p in json.loads(f.read_text()) for j in p['jobs']]
old={j['name']:j for j in jobs(37942242079,1)};new=jobs(37942242079,2);mapping=[]
for j in new:
 o=old.get(j['name']);rec={'name':j['name'],'attempt1_id':o['id'] if o else None,'attempt2_id':j['id'],'status':j['status'],'conclusion':j['conclusion'],'started_at':j['started_at'],'completed_at':j['completed_at'],'reused':bool(o and j['started_at']==o['started_at'] and o['conclusion']=='success')}
 if rec['reused']:
  a=audit.OUT/(str(o['id'])+'-raw-log.log');b=audit.OUT/(str(j['id'])+'-raw-log.log');rec['raw_bytes_equal']=a.read_bytes()==b.read_bytes()
 mapping.append(rec)
 if j['name']=='desktop (ubuntu-latest)':print('LINUX STEPS',[(s['name'],s['status'],s['conclusion']) for s in j['steps']])
(audit.OUT/'attempt-lineage.json').write_text(json.dumps(mapping,indent=2),encoding='utf8');print('LINEAGE',mapping)
summary={}
for j in jobs(37942242079,1)+jobs(37942252613,1):
 f=audit.OUT/(str(j['id'])+'-raw-log.log')
 if not f.exists():continue
 text=f.read_text(errors='replace');matches=[]
 for line in text.splitlines():
  if any(s in line for s in ['PASS:', 'PASS Web','PASS appearance','Ran ','OK','FAIL:','##[error]','HEAD is now']) and len(line)<700:matches.append(line)
 summary[str(j['id'])]={'job':j['name'],'conclusion':j['conclusion'],'matches':matches}
(audit.OUT/'semantic-log-review.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
for k,v in summary.items():print('LOG',k,v['job'],'\n'.join(v['matches'][-6:]))
