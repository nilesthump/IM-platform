import json,subprocess,hashlib
from pathlib import Path
out=Path('C:/Users/21441/.codex/visualizations/2026/10/08/01a11a79-95c1-79e2-a26b-9bcf56508973/web-task/product-architect-e')
root=Path('H:/.codex/worktrees/w/IM-platform')
py='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
base=[py,'-Xutf8','-B','tools/research/recorder.py']
rr=str(out/'research');run='R-WEB-ARCHITECT-E-20261009'
def call(args):
 p=subprocess.run(base+args,cwd=root,capture_output=True,text=True,encoding='utf8')
 print(p.stdout,end='');print(p.stderr,end='')
 assert p.returncode==0
 return p
warning={'result':'OBSERVED','message':'Incomplete trace: direct mandatory startup/source reads, original image views and private authoring/tool orchestration were not command recorded. First 52 original views preceded minimum baseline and are preliminary only; after mandatory reads and clean git/status/diff/recent, recorded all/frozen completed before formal detail-original re-view of all52. First baseline recorder wrapper exit2 GBK encoding failure left command_started without command_finished; failed stream unchanged. UTF8 retry wrappers completed. Read-only guessed missing paths and JSONL PowerShell conversion failed; later actual paths/line-wise reads succeeded. Default helper setup failure retried escalation; one unexecuted auto-review timeout retried once successfully. Post-finish report/seal authoring remains explicit private output gap. FixD original finish-inside-wrapper append anomaly and supplementary run disclosed, no stream edited. No complete prospective trace claim.'}
call(['record-event','--research-root',rr,'--run-id',run,'--event-type','instrumentation_warning','--data-json',json.dumps(warning)])
call(['record-event','--research-root',rr,'--run-id',run,'--event-type','review_finished','--data-json',json.dumps({'result':'PASS','scope':'Independent visual approval only exact75/source52/capturebc989/latest52 manifest4bb4/proof1319. All52 formally original-viewed after baseline, source/build/harness/Logo/tree/hash bindings independently PASS. Real header ONLINE excludes stale Sync status; same-session newbind/current-window HTTPpull and unique Cold107/Warm108 state pairs supported. No Task/hosted/main/Stage acceptance.'})])
call(['finish-run','--research-root',rr,'--run-id',run,'--result','PASS'])
p=call(['validate-run','--research-root',rr,'--run-id',run])
(out/'recorder-validation.txt').write_text(p.stdout+p.stderr,encoding='utf8')

