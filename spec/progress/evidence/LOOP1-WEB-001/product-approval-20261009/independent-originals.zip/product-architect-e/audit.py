import json,hashlib,subprocess,struct,time
from pathlib import Path
root=Path('H:/.codex/worktrees/w/IM-platform')
out=Path('C:/Users/21441/.codex/visualizations/2026/10/08/01a11a79-95c1-79e2-a26b-9bcf56508973/web-task/product-architect-e')
ev=root/'spec/progress/evidence/LOOP1-WEB-001/product-fix-20261009-d'
screens=ev/'screens/chromium-e'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root).decode().strip()
head=git('rev-parse','HEAD')
assert head=='75f5e6b4f0b678d6ddda2f6765b418fec78f2472'
assert git('rev-parse','--show-toplevel')=='H:/.codex/worktrees/w/IM-platform'
assert not git('status','--porcelain=v1')
assert not git('diff') and not git('diff','--cached')
source='52c9762e1e8a943a3b513aa428182c339c9787ca'
capture='bc989a51bd14a15788b170b8623dd3e922f2eaf2'
trees={}
for p in ['clients/web','clients/shared']:
 vals={r:git('rev-parse',r+':'+p) for r in [head,source,capture]}
 assert len(set(vals.values()))==1
 trees[p]=vals
ui={r:git('rev-parse',r+':clients/web/src/ui') for r in [head,'bc2110662e1de4a24fd3d76271f0cdbe992754a6']}
assert len(set(ui.values()))==1
expected={'manifest.json':'4bb4d0bef6bdfaf9a19a96adc118af1ec8297cb30f9e43f02233a2a64b59edde','protocol-proof.json':'1319d7867916037549f5033df00284c01d81d0a67316a68c52cb83049567ac39'}
for n,v in expected.items():assert h(screens/n)==v
m=json.loads((screens/'manifest.json').read_text(encoding='utf8'))
assert len(m['entries'])==52 and m['candidate_sha']==capture
images=[]
for e in m['entries']:
 p=screens/e['file'];assert h(p)==e['sha256'];assert e['candidate_sha']==capture
 width,height=struct.unpack('>II',p.read_bytes()[16:24])
 assert width==e['viewport']['width'] and height>=e['viewport']['height']
 images.append({'file':e['file'],'sha256':h(p),'width':width,'height':height,'formal_original_viewed':True})
assert len({e['file'] for e in images})==52
b=json.loads((ev/'build-provenance-latest.json').read_text(encoding='utf8'))
for rel,v in b['source_files'].items():assert h(root/'clients/web'/rel)==v
build=Path(m['build_origin'])
for rel,v in b['build_files'].items():assert h(build/rel)==v
assert h(root/'tests/clients/web/browser.mjs')==b['harness_sha256']
logo=h(root/'clients/web/src/ui/logo.png')
assert logo=='efd0954b42c77ef103995a03eeabd6db2ce2b28cc8648d36247b2f23c25bf0a2'==h(root/'clients/desktop/src/ui/logo.png')
canonical=h(root/'spec/architecture/frozen-architecture.md');assert canonical=='2ba864fc2805900117f62c3c88795c52364ecc7450da17975e26d35ebf2cc432'
pdf=h(root/'scalable-distributed-im-architecture.pdf');assert pdf=='546915f639f30cd294f11390da3ade2ce6a85b620bf55727c2a90ca6017d7510'
private=out.parent
reports={}
for name,sha in [('product-fix-d','d9820bfdafed2f05e6c0e7172ef35f240e68a66298dedea7e2b13ee68cac61df'),('product-architect-d','c3f892750d0e302574b3e35b4757d17346b2b051315e7641a5a774affcfb892e'),('product-review-b','7eb65ef20a54c39706a1e5b3743442adc159c5c18f30271244699ba009a5fe31')]:
 actual=h(private/name/'report.md');assert actual==sha;reports[name]=actual
proof=json.loads((screens/'protocol-proof.json').read_text(encoding='utf8'))
r=proof['reconnection'];before=r['before'];after=r['replacement']
assert before['connectionId']==1 and after['connectionId']==2 and after['event']>before['event']
for f in ['userId','sessionId','clientType','sessionEpoch']:assert before[f]==after[f]
assert after['clientType']=='WEB' and after['sessionEpoch']==1
assert r['header']=='在线' and r['old_sync_notice_present'] and not r['old_sync_notice_satisfies_header'] and r['held_new_pull_loading_then_completed']
for p in r['post_bind_pulls']:assert p['event']>after['event'] and p['observedBind']==2 and p['activeConnections']==[2] and p['body']['afterSeq']==106
for n in proof['narrow_send_identity']:assert not n['new_message_initially_sent'] and n['same_article_sending_to_sent'] and n['rendered_expected_sequence']
assert [n['expected_seq'] for n in proof['narrow_send_identity']]==[107,108]
assert proof['logout_status']==204 and not proof['pageerrors']
desktop=root/'spec/progress/evidence/LOOP1-CLIENT-GUI-001/desktop-polish-20261007/composer.png'
events=[json.loads(l) for l in (out/'research/runs/R-WEB-ARCHITECT-E-20261009/events.jsonl').read_text(encoding='utf8').splitlines()]
commands=[e for e in events if e['event_type'] in ['command_started','command_finished']]
binding={'result':'PASS','candidate':head,'source':source,'capture':capture,'branch':git('branch','--show-current'),'clean':True,'canonical':canonical,'historical_pdf':pdf,'manifest':expected['manifest.json'],'proof':expected['protocol-proof.json'],'trees':trees,'ui_trees':ui,'logo':logo,'source_files':b['source_files'],'build_files':b['build_files'],'harness':b['harness_sha256'],'prior_reports':reports,'desktop_reference':{'path':str(desktop),'sha256':h(desktop),'actual_original_viewed':True},'images':images,'formal_image_count':52,'preliminary_image_count':52,'startup_ordering_gap':'Preliminary image viewing occurred before minimum baseline. After completing mandatory reads and clean git status/diff/recent, recorded all/frozen baseline completed, then all 52 originals formally re-viewed detail original. Earlier preliminary views are excluded from approval.','commands_before_audit':commands}
(out/'bindings.json').write_text(json.dumps(binding,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'result':'PASS','images':len(images),'source_files':len(b['source_files']),'build_files':len(b['build_files']),'clean':True,'bindings_sha256':h(out/'bindings.json')}))

