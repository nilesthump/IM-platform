import subprocess,sys,json,time,hashlib,pathlib
root=pathlib.Path('H:/.codex/worktrees/w/IM-platform'); out=pathlib.Path(__file__).parent
py=sys.executable; recorder=root/'tools/research/recorder.py'
commands={
'architecture-utf8':[py,'-Xutf8','-B','ci/check_architecture.py','--scope','all','--json'],
'frozen':[py,'-Xutf8','-B','tools/verify_frozen_architecture.py'],
'web':[py,'-Xutf8','-B','tests/clients/web/verify.py'],
'selector-negative-corrected':['C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe',str(out/'selector-negative.mjs')],
'web14':[py,'-Xutf8','-B','-m','unittest','discover','-s','tests/clients/web'],
'recovery':['C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe','-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode','Acceptance'],
'diff':['git','diff','--check','d4bb8200e7f5410d101a27ad58f8abb5eaa80f8f','HEAD'],
'audit-corrected':[py,'-Xutf8','-B',str(out/'audit.py')]
}
name=sys.argv[1]; argv=[py,'-Xutf8','-B',str(recorder),'run-command','--repo',str(root),'--research-root',str(out/'research'),'--run-id','R-WEB-REVIEW-C','--',*commands[name]]
t=time.monotonic(); result=subprocess.run(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE); elapsed=round((time.monotonic()-t)*1000)
(out/(name+'.stdout.log')).write_bytes(result.stdout);(out/(name+'.stderr.log')).write_bytes(result.stderr)
receipt={'name':name,'argv':commands[name],'exit_code':result.returncode,'elapsed_ms':elapsed,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()}
(out/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print(result.stdout.decode('utf8',errors='replace')[-3500:]);print(result.stderr.decode('utf8',errors='replace')[-3500:]);sys.exit(result.returncode)




