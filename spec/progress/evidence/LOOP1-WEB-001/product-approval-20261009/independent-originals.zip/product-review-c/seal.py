import pathlib,json,hashlib,subprocess
p=pathlib.Path(__file__).parent;r=pathlib.Path('H:/.codex/worktrees/w/IM-platform')
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=r)==b''
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip();assert head=='75f5e6b4f0b678d6ddda2f6765b418fec78f2472'
def h(name):return hashlib.sha256((p/name).read_bytes()).hexdigest()
seal={'reviewer':'/root/web_product_review_c','decision':'PASS','scope':'independent implementation delta/authority/minimality only','reviewed_sha':head,'prior_semantic_review':'19049ae116c9e45b19acfaa5d2b56d62052b96c7','product_source':'52c9762e1e8a943a3b513aa428182c339c9787ca','clean':True,'branch':'task/LOOP1-WEB-001-product','lease':'RELEASED','report_sha256':h('report.md'),'audit_sha256':h('audit.json'),'receipts_sha256':h('command-receipts.json'),'recorder_events_sha256':h('research/runs/R-WEB-REVIEW-C/events.jsonl'),'recorder_finished':True,'recorder_validated':True,'recorder_original_encoding_gap':'original command_started without command_finished; immutable disclosed; subsequent UTF8 run succeeds','separate_architect_hosted_main_sync_required':True}
(p/'seal.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal));print('seal_sha256',h('seal.json'))
