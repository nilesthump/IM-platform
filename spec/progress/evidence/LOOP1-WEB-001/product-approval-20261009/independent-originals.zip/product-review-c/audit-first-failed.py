import pathlib,subprocess,json,hashlib,zipfile
root=pathlib.Path('H:/.codex/worktrees/w/IM-platform');out=pathlib.Path(__file__).parent;parent=out.parent
head='75f5e6b4f0b678d6ddda2f6765b418fec78f2472'; prior='19049ae116c9e45b19acfaa5d2b56d62052b96c7'; source='52c9762e1e8a943a3b513aa428182c339c9787ca'; base='d4bb8200e7f5410d101a27ad58f8abb5eaa80f8f'; harness='bc989a51bd14a15788b170b8623dd3e922f2eaf2'
def g(*a):return subprocess.check_output(['git','--no-replace-objects',*a],cwd=root).decode().strip()
def h(b):return hashlib.sha256(b).hexdigest()
def file(p):return (root/p).read_bytes()
assert g('rev-parse','HEAD')==head
assert g('rev-parse','--show-toplevel')=='H:/.codex/worktrees/w/IM-platform'
assert g('status','--porcelain=v1')==''
assert g('branch','--show-current')=='task/LOOP1-WEB-001-product'
trees={}
for path in ['clients/web','clients/shared','spec/architecture','spec/domain','spec/invariants','spec/acceptance','spec/governance','contracts','tests/architecture']:
 values={sha:g('rev-parse',sha+':'+path) for sha in [head,prior,source]};assert len(set(values.values()))==1,(path,values);trees[path]=values
assert g('diff','--name-only',base,head,'--','clients/shared','contracts','backend')==''
extra=['spec/architecture/frozen-architecture.md','spec/architecture/baseline.md','spec/architecture/decisions/ADR-0011-web-appearance-storage.md','ci/check_architecture.py','tests/architecture/test_client_technology.py','.github/workflows/ci.yml','tests/ci/test_s0_boundary.py']
assert g('diff','--name-only',base,head,'--',*extra)==''
delta=g('diff','--name-only',prior,head).splitlines();full=g('diff','--name-only',base,head).splitlines()
def allowed(p):return p.startswith(('clients/web/src/','tests/clients/web/','spec/progress/evidence/LOOP1-WEB-001/')) or p in ['clients/web/package.json','clients/web/package-lock.json','clients/web/tsconfig.json','spec/tasks/review/LOOP1-WEB-001.md','spec/tasks/active/LOOP1-WEB-001.md','spec/progress/current.md']
assert all(allowed(p) for p in full),[p for p in full if not allowed(p)]
assert all(p.startswith('spec/progress/evidence/LOOP1-WEB-001/product-fix-20261009-d/') or p in ['tests/clients/web/browser.mjs','tests/clients/web/fixture.mjs','spec/tasks/review/LOOP1-WEB-001.md','spec/progress/current.md'] for p in delta)
assert g('diff','--name-only','9d7b032','HEAD','--','spec/progress/evidence/LOOP1-WEB-001/fix-20261009-a')==''
ev='spec/progress/evidence/LOOP1-WEB-001/product-fix-20261009-d/';screen=ev+'screens/chromium-e/'
manifest=json.loads(file(screen+'manifest.json'));proof=json.loads(file(screen+'protocol-proof.json'));prov=json.loads(file(ev+'build-provenance-latest.json'))
assert h(file(screen+'manifest.json'))=='4bb4d0bef6bdfaf9a19a96adc118af1ec8297cb30f9e43f02233a2a64b59edde'
assert h(file(screen+'protocol-proof.json'))=='1319d7867916037549f5033df00284c01d81d0a67316a68c52cb83049567ac39'
assert manifest['candidate_sha']==harness and len(manifest['entries'])==52
for entry in manifest['entries']:
 assert entry['candidate_sha']==harness and h(file(screen+entry['file']))==entry['sha256']
 assert file(screen+entry['file']).startswith(b'\x89PNG\r\n\x1a\n')
for name,digest in prov['source_files'].items():assert h(file('clients/web/'+name))==digest
assert h(file('tests/clients/web/browser.mjs'))==prov['harness_sha256']
build=pathlib.Path(manifest['build_origin']);assert build.exists(),str(build)
for name,digest in prov['build_files'].items():assert h((build/name).read_bytes())==digest,name
assert manifest['build_index_sha256']==prov['build_files']['index.html']
logos=[file('clients/web/src/ui/logo.png'),file('clients/desktop/src/ui/logo.png'),(build/'logo.png').read_bytes()];assert len(set(logos))==1
r=proof['reconnection'];b=r['before'];n=r['replacement'];assert b['connectionId']!=n['connectionId'] and n['event']>b['event']
for key in ['userId','sessionId','clientType','sessionEpoch']:assert b[key]==n[key]
assert n['clientType']=='WEB' and n['sessionEpoch']==1 and r['current_window_afterSeq']==106
assert r['header']=='在线' and r['held_new_pull_loading_then_completed'] and r['old_sync_notice_present'] and not r['old_sync_notice_satisfies_header']
for p in r['post_bind_pulls']:assert p['event']>n['event'] and p['observedBind']==n['connectionId'] and n['connectionId'] in p['activeConnections'] and p['body']['afterSeq']==106 and p['body']['type']=='sync.conversation.request'
assert proof['sends'][1]==proof['sends'][2] and proof['sends'][0]!=proof['sends'][1]
assert proof['logout_status']==204 and proof['pageerrors']==[]
assert [x['expected_seq'] for x in proof['narrow_send_identity']]==[107,108]
assert proof['narrow_send_identity'][1]['old_sent_count']>=1
originals=json.loads(file(ev+'original-bindings.json'));z=zipfile.ZipFile(root/(ev+'independent-originals.zip'))
for item in originals:
 assert h(z.read(item['file']))==item['sha256'];assert h((parent/item['file']).read_bytes())==item['sha256']
for name,expected in [('product-review-b/report.md','7eb65ef20a54c39706a1e5b3743442adc159c5c18f30271244699ba009a5fe31'),('product-review-b/seal.json','fbfb27a2dda955c4a3207a2dfa4860d25eeae935c665c627b5ad2121a91a4d80'),('product-fix-d/report.md','d9820bfdafed2f05e6c0e7172ef35f240e68a66298dedea7e2b13ee68cac61df'),('product-fix-d/seal.json','2335f172af36a9147dc3bfcb2ef86b48dadbf6813d91bfe8bdfc138f888f645e')]:assert h((parent/name).read_bytes())==expected
queues=list((root/'spec/tasks').glob('*/LOOP1-WEB-001.md'));assert len(queues)==1 and queues[0].parent.name=='review'
summary={'head':head,'prior_semantic_review':prior,'product_source':source,'capture_harness':harness,'branch':g('branch','--show-current'),'clean':True,'trees':trees,'full_changed_count':len(full),'delta_changed_count':len(delta),'delta_paths':delta,'all52_source_build_png_archive_hashes_verified':True,'logo_sha256':h(logos[0]),'reconnect_proof':r,'originals_count':len(originals),'visual_approval':False}
(out/'audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps({k:v for k,v in summary.items() if k not in ['trees','delta_paths','reconnect_proof']}))
