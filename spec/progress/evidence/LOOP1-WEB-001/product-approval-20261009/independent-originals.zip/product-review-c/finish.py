import pathlib,subprocess,sys,json
out=pathlib.Path(__file__).parent;root=pathlib.Path('H:/.codex/worktrees/w/IM-platform');rec=root/'tools/research/recorder.py'
def call(name,args):
 p=subprocess.run([sys.executable,'-Xutf8','-B',str(rec),*args,'--repo',str(root),'--research-root',str(out/'research'),'--run-id','R-WEB-REVIEW-C'],cwd=root,capture_output=True)
 (out/(name+'.stdout.log')).write_bytes(p.stdout);(out/(name+'.stderr.log')).write_bytes(p.stderr);assert p.returncode==0,(name,p.stderr.decode());print(name,p.stdout.decode().strip())
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=root)==b''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()=='75f5e6b4f0b678d6ddda2f6765b418fec78f2472'
events=out/'research/runs/R-WEB-REVIEW-C/events.jsonl'; rows=[json.loads(x) for x in events.read_text().splitlines()]
started={x['data']['command_id']:x for x in rows if x['event_type']=='command_started'};finished={x['data']['command_id']:x for x in rows if x['event_type']=='command_finished'};pending=set(started)-set(finished)
assert len(pending)==1
call('review-event',['record-event','--event-type','review_finished','--data-json',json.dumps({'result':'PASS','candidate':'75f5e6b4f0b678d6ddda2f6765b418fec78f2472','scope':'independent implementation delta/authority/minimality','independent_actor':'/root/web_product_review_c','instrumentation_gaps':'Prebaseline reads preliminary only; formal postbaseline review completed. Direct private authoring/read/communications gaps. First Recorder parent GBK wrapper exit2 left immutable command_started without command_finished; fresh UTF8 success. Private audit backlog-deletion omission and selector Windows URL typo failed then corrected. Private finish helper permission review timed out before execution; verified file absent/run running; retry authorized. No complete original command trace claim.','architect_approval':False,'task_gate_ci_acceptance':False})])
call('finish',['finish-run','--result','PASS']);call('validate',['validate-run'])
(out/'command-receipts.json').write_text(json.dumps([{'start':s,'finish':finished.get(i)} for i,s in started.items()],indent=2)+'\n',encoding='utf8');print('Original encoding-failure missing finish:',list(pending))
