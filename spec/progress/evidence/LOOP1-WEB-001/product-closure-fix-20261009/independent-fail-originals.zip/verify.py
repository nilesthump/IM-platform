from pathlib import Path
import subprocess,json,time,hashlib,os
p=Path(__file__).parent;r=Path('H:/.codex/worktrees/w/IM-platform');py='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';pw='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe';g='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
env=os.environ.copy();env['PATH']=str(Path(g).parent)+os.pathsep+str(Path(py).parent)+os.pathsep+env['PATH']
commands={'architecture-tests':[py,'-Xutf8','-B','-m','unittest','discover','-s','tests/architecture'],'clean-acceptance':[pw,'-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode','Acceptance'],'diff':[g,'diff','--check','a1b154d06c0a9d191ec8dca514fff3ab1b46ee25','2ebbf46a860ae702eedb57825c6f1cd844e90080']}
receipts=[]
for n,cmd in commands.items():
 t=time.perf_counter();s=subprocess.run(cmd,cwd=r,env=env,capture_output=True);ms=(time.perf_counter()-t)*1000
 for stream in ('stdout','stderr'):(p/(n+'.'+stream+'.log')).write_bytes(getattr(s,stream))
 o={'name':n,'argv':cmd,'exit_code':s.returncode,'elapsed_ms':ms,'stdout_sha256':hashlib.sha256(s.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(s.stderr).hexdigest()};receipts.append(o);print(json.dumps(o));print((s.stdout+s.stderr).decode('utf-8',errors='replace')[-1500:])
(p/'commands.json').write_text(json.dumps(receipts,indent=2));assert all(x['exit_code']==0 for x in receipts)
