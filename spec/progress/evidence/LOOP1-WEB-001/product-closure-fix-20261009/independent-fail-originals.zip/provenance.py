from pathlib import Path
import json,zipfile,hashlib,re,subprocess
r=Path('H:/.codex/worktrees/w/IM-platform');p=Path(__file__).parent;private=p.parent;z=zipfile.ZipFile(r/'spec/progress/evidence/LOOP1-WEB-001/product-closure-20261009/acceptance-originals.zip');names=z.namelist();h=lambda b:hashlib.sha256(b).hexdigest()
for n in names:
 orig=private/(n.removeprefix('coordinator/') if n.startswith('coordinator/') else n)
 assert orig.is_file(),n
 assert orig.read_bytes()==z.read(n),n
print('448 originals compared byteexact to independent original locations')
count=0
for folder in ['product-metadata-review','product-hosted-acceptance-20261009','product-hosted-acceptance-attempt2-20261009','product-main-acceptance-20261009']:
 seal=json.loads(z.read(folder+'/seal.json'));assert h(z.read(folder+'/report.md'))==seal['report_sha256'];print('SEAL',folder,seal['result'],seal['report_sha256'])
 for n,sha in seal.get('files',{}).items():
  assert h(z.read(folder+'/'+n))==sha,(folder,n);count+=1
print('all seal-bound originals matched',count)
for folder in ['product-hosted-acceptance-attempt2-20261009','product-main-acceptance-20261009']:
 for leaf in ['attempt-lineage.json','actual-job-review.json']:
  n=folder+'/'+leaf
  if n in names:
   data=json.loads(z.read(n));print('SEMANTIC',n,json.dumps(data,ensure_ascii=False)[:5500])
 for n in names:
  if n.startswith(folder+'/') and ('-jobs-' in n or '-run-' in n) and n.endswith('.log'):
   data=json.loads(z.read(n))
   if 'jobs' in data:
    jobs=data['jobs'];print('JOBS',n,len(jobs),[(j['name'],j['id'],j['conclusion']) for j in jobs])
   elif 'head_sha' in data:print('RUN',n,data.get('head_sha'),data.get('run_attempt'),data.get('conclusion'))
print('MERGE ARGV',json.loads(z.read('coordinator/product-protected-merge.receipt.json')))
print('MAIN HEAD',subprocess.check_output(['C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe','-C','H:/IM-platform','rev-parse','HEAD']).decode().strip())
for a in ['spec/progress/evidence/LOOP1-WEB-001/product-approval-20261009/independent-originals.zip','spec/progress/evidence/LOOP1-WEB-001/product-fix-20261009-d/independent-originals.zip']:
 path=r/a
 if path.exists():
  prior=zipfile.ZipFile(path)
  for n in prior.namelist():
   if n.endswith('report.md'):print('PRIOR APPROVAL',n,prior.read(n).decode('utf-8-sig')[:1800])
(p/'provenance-result.json').write_text(json.dumps({'private_originals_byteequal':448,'sealed_originals_verified':count,'main_head':'a1b154d06c0a9d191ec8dca514fff3ab1b46ee25','finding':'current Next Exact Action remains unconditional closure rerun after integration'},indent=2))
