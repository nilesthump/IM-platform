from pathlib import Path
import json,zipfile,hashlib,re
r=Path('H:/.codex/worktrees/w/IM-platform');p=Path(__file__).parent;z=zipfile.ZipFile(r/'spec/progress/evidence/LOOP1-WEB-001/product-closure-20261009/acceptance-originals.zip');ns=z.namelist();h=lambda x:hashlib.sha256(x).hexdigest()
def jobs(n):
 d=json.loads(z.read(n));return d['jobs'] if isinstance(d,dict) else [j for page in d for j in page['jobs']]
f='product-hosted-acceptance-attempt2-20261009/';stamp='1791556231046785300'
a1=jobs(f+'37942242079-a1-jobs-'+stamp+'.log');a2=jobs(f+'37942242079-a2-jobs-'+stamp+'.log');pr=jobs(f+'37942252613-a1-jobs-'+stamp+'.log')
assert len(a1)==len(a2)==14;assert sum(x['conclusion']=='failure' for x in a1)==2;assert all(x['conclusion']=='success' for x in a2)
old={x['name']:x for x in a1}; reused=0
for j in a2:
 o=old[j['name']]
 same=z.read(f+str(o['id'])+'-raw-log.log')==z.read(f+str(j['id'])+'-raw-log.log')
 if same:
  reused+=1;assert j['started_at']==o['started_at'] and j['completed_at']==o['completed_at']
 else:assert j['name'] in ['desktop (ubuntu-latest)','gate']
assert reused==12
assert len(pr)==13 and sum(x['conclusion']=='success' for x in pr)==6 and sum(x['conclusion']=='skipped' for x in pr)==7
fm='product-main-acceptance-20261009/';jm=jobs(fm+'37945266468-jobs-1791556692516092100.log');assert len(jm)==13 and sum(x['conclusion']=='success' for x in jm)==6 and sum(x['conclusion']=='skipped' for x in jm)==7
review=json.loads(z.read(fm+'actual-job-review.json'))
for j in jm:
 if j['conclusion']=='success':
  n=fm+str(j['id'])+'-raw-log.log';data=z.read(n);assert h(data)==review[j['name']]['log_sha256'];assert b'a1b154d06c0a9d191ec8dca514fff3ab1b46ee25' in data
  for line in review[j['name']]['semantic_lines']:assert line in data.decode('utf-8')
print('Original hosted job counts and raw logs PASS: attempt1 failures2; attempt2 successes14/reused12/real reruns2; PR6success7properinactive; actualmain6success7properinactive')
# Prior independent archives are retained unchanged by this administrative delta.
for dir in ['product-approval-20261009','product-fix-20261009-d']:
 d=r/'spec/progress/evidence/LOOP1-WEB-001'/dir;b=json.loads((d/'original-bindings.json').read_text()); print('PRIOR BINDING',dir,type(b).__name__)
 zz=zipfile.ZipFile(d/'independent-originals.zip')
 for n in zz.namelist():
  if n.endswith('seal.json'):
   seal=json.loads(zz.read(n));report=n.removesuffix('seal.json')+'report.md'
   if report in zz.namelist():assert h(zz.read(report))==(seal['report_sha256'] if 'report_sha256' in seal else seal['files']['report.md']);print('Prior independent sealed report',report,seal.get('result'))
print('CURRENT LINE NUMBERS')
for i,l in enumerate((r/'spec/progress/current.md').read_text().splitlines(),1):
 if 'Next Exact Action' in l or 'Complete only' in l or 'closure metadata' in l or 'separately bind' in l:print(i,l)
(p/'hosted-verification.json').write_text(json.dumps({'attempt1_failures':2,'attempt2_successes':14,'reused_bytes_times_verified':12,'actual_reruns':2,'pr_required_success':6,'pr_inactive':7,'actualmain_required_success':6,'actualmain_inactive':7},indent=2))


