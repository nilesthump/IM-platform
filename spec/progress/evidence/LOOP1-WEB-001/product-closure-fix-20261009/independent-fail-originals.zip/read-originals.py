from pathlib import Path
import zipfile,json,hashlib
r=Path('H:/.codex/worktrees/w/IM-platform');z=zipfile.ZipFile(r/'spec/progress/evidence/LOOP1-WEB-001/product-closure-20261009/acceptance-originals.zip');p=Path(__file__).parent
for folder in ['product-metadata-review','product-hosted-acceptance-20261009','product-hosted-acceptance-attempt2-20261009','product-main-acceptance-20261009']:
 for f in ['report.md','seal.json']:
  n=folder+'/'+f;print('\nORIGINAL '+n+'\n'+z.read(n).decode('utf-8-sig'))
print('\nINTEGRATION\n'+z.read('coordinator/product-protected-integration-binding.json').decode())
print('\nSYNC\n'+z.read('coordinator/product-main-sync-receipt.json').decode())
print('\nJSON INVENTORY')
for n in z.namelist():
 if n.endswith('.json') and '/research/' not in n:print(n)
