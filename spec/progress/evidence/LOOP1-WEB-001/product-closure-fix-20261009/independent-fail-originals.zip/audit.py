from pathlib import Path
import json,zipfile,hashlib,subprocess,time
r=Path('H:/.codex/worktrees/w/IM-platform');p=Path(__file__).parent;g='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
a='a1b154d06c0a9d191ec8dca514fff3ab1b46ee25'; c='2ebbf46a860ae702eedb57825c6f1cd844e90080'
def git(*x):
 s=subprocess.run([g,'-C',str(r),*x],capture_output=True);assert s.returncode==0;return s.stdout.decode().strip()
assert git('rev-parse','HEAD')==c and git('status','--porcelain=v1')==''
assert git('rev-parse',c+'^')==a
paths=git('diff','--name-status','--find-renames',a,c);print('SCOPE\n'+paths)
assert git('diff','--name-only',a,c,'--','clients','tests','contracts','spec/architecture','ci','.github','backend','tools','research')==''
assert git('show','-s','--format=%P',a)=='d4bb8200e7f5410d101a27ad58f8abb5eaa80f8f 615cb06c70581aa474281b2dd9be80e59be88ec8'
assert git('rev-parse',a+'^{tree}')==git('rev-parse','615cb06c70581aa474281b2dd9be80e59be88ec8^{tree}')
e=r/'spec/progress/evidence/LOOP1-WEB-001/product-closure-20261009'; b=json.loads((e/'original-bindings.json').read_text());z=zipfile.ZipFile(e/'acceptance-originals.zip')
assert hashlib.sha256((e/'acceptance-originals.zip').read_bytes()).hexdigest()==b['archive_sha256'];assert set(z.namelist())==set(b['entries']);assert len(z.namelist())==len(set(z.namelist()))==448
crcr=0
for n,v in b['entries'].items():
 data=z.read(n);assert len(data)==v['size'] and hashlib.sha256(data).hexdigest()==v['sha256'],n
 if b'\r\r\n' in data:crcr+=1
print('ARCHIVE PASS448; raw CRCRLF entries',crcr)
for n in z.namelist():
 if n.endswith(('report.md','seal.json')) or 'sync-receipt' in n or 'integration-binding' in n:print('ORIGINAL',n)
(p/'audit-result.json').write_text(json.dumps({'candidate':c,'parent':a,'scope':paths,'archive_entries':448,'raw_crcrlf_entries':crcr,'source_authority_unchanged':True,'main_candidate_trees_equal':True},indent=2))
print('CHECKPOINT\n'+(r/'spec/progress/checkpoints/2026-10-09-loop1-web-001-product-accepted.md').read_text())
print('SUMMARY\n'+(e/'summary.md').read_text())
