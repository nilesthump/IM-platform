import pathlib,hashlib,json,subprocess
repo=pathlib.Path('H:/.codex/worktrees/w/IM-platform'); private=pathlib.Path('C:/Users/21441/.codex/visualizations/2026/10/08/01a11a79-95c1-79e2-a26b-9bcf56508973/web-task/product-architect-d')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=repo,text=True).strip()
e=repo/'spec/progress/evidence/LOOP1-WEB-001/product-fix-20261009-c'; s=e/'screens/chromium-d'; m=json.loads((s/'manifest.json').read_text()); b=json.loads((e/'build-provenance-latest.json').read_text()); failures=[]
for x in m['entries']:
 if h(s/x['file'])!=x['sha256']:failures.append(x['file'])
for name,digest in b['source_files'].items():
 if h(repo/'clients/web'/name)!=digest:failures.append('source:'+name)
for name,digest in b['build_files'].items():
 if h(pathlib.Path(m['build_origin'])/name)!=digest:failures.append('build:'+name)
assert not failures,failures
assert h(repo/'tests/clients/web/browser.mjs')==b['harness_sha256']
assert h(repo/'clients/desktop/src/ui/logo.png')==h(repo/'clients/web/src/ui/logo.png')
assert git('rev-parse','HEAD')=='19049ae116c9e45b19acfaa5d2b56d62052b96c7'
assert not git('status','--porcelain')
assert git('rev-parse','HEAD:clients/web')==git('rev-parse',m['candidate_sha']+':clients/web')
assert git('rev-parse','HEAD:clients/shared')==git('rev-parse',m['candidate_sha']+':clients/shared')
assert git('rev-parse','HEAD:clients/web/src/ui')==git('rev-parse','bc2110662e1de4a24fd3d76271f0cdbe992754a6:clients/web/src/ui')
result={'candidate':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'capture_source':m['candidate_sha'],'manifest_sha256':h(s/'manifest.json'),'count':len(m['entries']),'png_checks':'PASS','source_build_harness_checks':'PASS','logo_sha256':h(repo/'clients/web/src/ui/logo.png'),'clean':True,'product_tree_equal':True,'ui_bc211_equal':True,'originals':m['entries'],'harness_sha256':h(repo/'tests/clients/web/browser.mjs'),'protocol_proof_sha256':h(s/'protocol-proof.json'),'build_provenance_sha256':h(e/'build-provenance-latest.json')}
(private/'binding.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='originals'}))
