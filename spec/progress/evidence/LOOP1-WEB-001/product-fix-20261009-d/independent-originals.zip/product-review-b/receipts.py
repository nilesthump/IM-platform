import json,pathlib,hashlib
p=pathlib.Path(__file__).parent
entries=[json.loads(s) for s in (p/'research/runs/R-WEB-REVIEW-B/events.jsonl').read_text().splitlines()]
for x in entries:
 if x['event_type'] in ['command_started','command_finished']:print(json.dumps(x))
