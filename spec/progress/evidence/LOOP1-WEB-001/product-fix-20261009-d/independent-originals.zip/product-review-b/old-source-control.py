import pathlib,subprocess,sys,os,json
root=pathlib.Path('H:/.codex/worktrees/w/IM-platform');p=pathlib.Path(__file__).parent
sys.path.insert(0,str(root/'tests/clients/web'));import verify
node='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin';os.environ['PATH']=node+os.pathsep+os.environ['PATH']
def runner(command,*,cwd,env=None):
 if command[-1]=='build':
  stage=pathlib.Path(command[2]);file=stage/'src/application/client.ts'
  file.write_bytes(subprocess.check_output(['git','-C',str(root),'show','4fae9419d4a01f4b9d774722499ceeba812b8d89:clients/web/src/application/client.ts']))
 if str(command[-1]).endswith('behavior.mjs'):
  result=subprocess.run([str(pathlib.Path(node)/'node.exe'),str(root/'tests/clients/web/regressions.mjs')],cwd=cwd,env=env,capture_output=True)
  (p/'old-source-regression.log').write_bytes(result.stdout+result.stderr)
  assert result.returncode!=0,'Regression did not detect old source'
  assert b"'FAILED'" in result.stderr and b"'SENT'" in result.stderr,result.stderr
  print('EXPECTED_REJECTION: fresh locked build with original failing client source is rejected by current regression late ACK FAILED vs SENT')
  raise StopIteration()
 verify.run(command,cwd=cwd,env=env)
try:verify.verify(root,runner=runner)
except StopIteration:pass
