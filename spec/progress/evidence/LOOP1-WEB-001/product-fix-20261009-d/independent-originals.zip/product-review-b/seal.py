import json,pathlib,hashlib
p=pathlib.Path(__file__).parent
stream=p/'research/runs/R-WEB-REVIEW-B/events.jsonl'
events=[json.loads(s) for s in stream.read_text().splitlines()]
starts={e['data']['command_id']:e for e in events if e['event_type']=='command_started'}
receipts=[dict(start=starts[e['data']['command_id']],finish=e) for e in events if e['event_type']=='command_finished']
(p/'command-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
hash=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
seal={'reviewer':'/root/web_product_review_b','decision':'PASS','scope':'independent implementation/authority/minimality only','reviewed_sha':'19049ae116c9e45b19acfaa5d2b56d62052b96c7','clean':True,'branch':'task/LOOP1-WEB-001-product','lease':'RELEASED','report_sha256':hash(p/'report.md'),'receipts_sha256':hash(p/'command-receipts.json'),'recorder_events_sha256':hash(stream),'recorder_finished':True,'recorder_validated':True,'separate_architect_hosted_main_sync_required':True}
(p/'seal.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal,indent=2));print('seal_sha256',hash(p/'seal.json'))
