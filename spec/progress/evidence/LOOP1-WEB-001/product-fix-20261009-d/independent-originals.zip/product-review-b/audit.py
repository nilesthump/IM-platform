import pathlib,subprocess,json,hashlib,re
root=pathlib.Path('H:/.codex/worktrees/w/IM-platform'); p=pathlib.Path(__file__).parent
base='d4bb8200e7f5410d101a27ad58f8abb5eaa80f8f'; head='19049ae116c9e45b19acfaa5d2b56d62052b96c7'; source='52c9762e1e8a943a3b513aa428182c339c9787ca'
def git(*args):return subprocess.check_output(['git','-C',str(root),*args]).decode().strip()
assert git('rev-parse','HEAD')==head and not git('status','--porcelain=v1')
assert pathlib.Path(git('rev-parse','--show-toplevel')).as_posix()==root.as_posix()
assert git('rev-parse','HEAD:clients/web')==git('rev-parse',source+':clients/web')
assert git('rev-parse','HEAD:clients/shared')==git('rev-parse',base+':clients/shared')
paths=git('diff','--name-only','--no-renames',base,head).splitlines()
allowed=lambda n:n.startswith(('clients/web/src/','tests/clients/web/','spec/progress/evidence/LOOP1-WEB-001/')) or n in ['clients/web/package.json','clients/web/package-lock.json','clients/web/tsconfig.json','spec/progress/current.md','spec/tasks/active/LOOP1-WEB-001.md','spec/tasks/review/LOOP1-WEB-001.md','spec/tasks/backlog/LOOP1-WEB-001.md'] or n.startswith('spec/progress/checkpoints/') and 'loop1-web-001' in n
assert all(allowed(n) for n in paths), [n for n in paths if not allowed(n)]
mfile=root/'spec/progress/evidence/LOOP1-WEB-001/product-fix-20261009-c/screens/chromium-d/manifest.json'
hash=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert hash(mfile)=='c99c82e222caec2279b24005f98487599d8b15fdd4f186f73d0f48dc32e04b40'
m=json.loads(mfile.read_text());assert len(m['entries'])==52 and m['candidate_sha']==source
for e in m['entries']:assert hash(mfile.parent/e['file'])==e['sha256'] and e['candidate_sha']==source
assert git('rev-parse','HEAD:clients/web/src/ui')==git('rev-parse','bc2110662e1de4a24fd3d76271f0cdbe992754a6:clients/web/src/ui')
for name in ['product-review-a/report.md','product-fix-c/report.md']:
 f=p.parent/name;print(name,hash(f))
result={'head':head,'branch':git('branch','--show-current'),'base':base,'clean':True,'product_source_sha':source,'product_tree_equal':True,'shared_tree_unchanged':True,'ui_tree_equal_original':True,'ordinary_allowed_scope':True,'changed_paths':len(paths),'screens':52,'manifest_sha256':hash(mfile)}
(p/'scope-bindings.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
