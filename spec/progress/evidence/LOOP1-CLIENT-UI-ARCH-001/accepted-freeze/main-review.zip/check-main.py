from pathlib import Path
import hashlib,json,subprocess,re
root=Path.cwd(); out=root/'.git-ui-main-review-research'; base='9c0eba89219b3fab73fe9258a7cfc59831c499dc'; candidate='33cc754e6394d84f77540a814837deba42ad6e5f'; main='4f18d222c75bb03166b2b5ead84b9999150a300c'
def git(*a): return subprocess.check_output(['git',*a],text=True).strip()
assert git('rev-parse','--show-toplevel').lower()==str(root).replace('\\','/').lower()
assert git('rev-parse','HEAD')==main
assert git('show','-s','--format=%P','HEAD').split()==[base,candidate]
assert git('rev-parse','HEAD^{tree}')==git('rev-parse',candidate+'^{tree}')
assert git('status','--porcelain')==''
paths=git('diff','--name-only',base+'..HEAD').splitlines()
assert all(p=='AGENTS.md' or p.startswith('spec/') for p in paths)
assert git('diff',base+'..HEAD','--','contracts','backend','clients','plugins','shared','ci','tests','tools','research','.github','scalable-distributed-im-architecture.pdf')==''
t=(root/'spec/architecture/frozen-architecture.md').read_text(encoding='utf-8')
for sec in ['2.3','3','6.1','6.5','8.2','10','11']:
 m=re.search(r'^#{2,3} '+re.escape(sec)+r'\.?\s.*$',t,re.M)
 if m:
  end=re.search(r'^## ',t[m.end():],re.M)
  print('AUTHORITY SECTION',sec,t[m.start():m.end()+end.start() if end else len(t)])
for f in ['spec/progress/evidence/LOOP1-CLIENT-UI-ARCH-001/human-request.txt','spec/progress/evidence/LOOP1-CLIENT-UI-ARCH-001/human-supplement.txt','contracts/http/auth-user-friend.openapi.json']:
 v=(root/f).read_text(encoding='utf-8'); print('INPUT',f,v if 'human-' in f else json.dumps(list(json.loads(v)['paths'])))
for area in ['contracts/websocket','contracts/plugin-api']:
 for f in (root/area).rglob('*.json'):
  json.loads(f.read_text(encoding='utf-8')); print('CONTRACT',f.relative_to(root))
host=Path('H:/.codex/worktrees/client-ui-architecture/IM-platform/.git-ui-architecture-research/hosted/main-4f18d22-run37098121554.json')
j=json.loads(host.read_text(encoding='utf-8')); assert j['headSha']==main and j['status']=='completed' and j['conclusion']=='success'
required={'classify','architecture','source_go','source_java','gate'}; inactive={'go','java','web','desktop','mobile','shared','compatibility','deploy'}
assert {x['name'] for x in j['jobs']}==required|inactive
for x in j['jobs']:
 assert x['status']=='completed'
 if x['name'] in required: assert x['conclusion']=='success' and x['steps'] and all(z['status']=='completed' and z['conclusion']=='success' for z in x['steps'])
 else: assert x['conclusion']=='skipped' and not x['steps']
print('HOSTED_VERIFIED',j['headSha'],[(x['name'],x['conclusion']) for x in j['jobs']])
print('CI_CLASSIFIER',Path('ci/classify_paths.py').read_text(encoding='utf-8') if Path('ci/classify_paths.py').exists() else git('ls-files','ci'))
events=[json.loads(x) for x in (out/'runs/R-UI-MAIN-REVIEW-20261003/events.jsonl').read_text(encoding='utf-8').splitlines()]
print('RECORDER_EVENTS',json.dumps(events[-5:],ensure_ascii=False))
report={'result':'PASS','reviewer':'/root/ui_arch_main_review','independence':'Fresh actual-main reviewer; did not implement, fix, or review candidate. No candidate/product/task/current mutation.','actual_main':main,'candidate':candidate,'base':base,'parents':git('show','-s','--format=%P','HEAD').split(),'tree':git('rev-parse','HEAD^{tree}'),'candidate_tree_equal':True,'assigned_worktree':str(root),'clean_status':True,'product_contract_checker_ci_pdf_changes':False,'hosted_run':37098121554,'hosted_url':j['url'],'hosted_raw_file':str(host),'hosted_sha256':hashlib.sha256(host.read_bytes()).hexdigest(),'required_jobs':sorted(required),'correct_inactive_jobs':sorted(inactive),'findings':[],'remaining':'Coordinator protected original-main synchronization and truthful task/progress/acceptance evidence; S1 PASS/S2 OPEN. No Task done claim.','failures_exposed':['Before Recorder python resolved Python2 and failed help; UTF-8/GB18030 inspection failed because files are valid UTF-8, corrected Python3 output.','Recorder section extraction command failed quoting SyntaxError; correction uses this script.'],'capture_mode':'prospective_resume','pre_recorder_trace_complete':False,'recorded_commands_and_results':events}
(out/'main-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'main-review.md').write_text('''# 实际主分支独立验收：PASS

审查者 /root/ui_arch_main_review 为全新独立上下文，未实现、修复或候选审查。本次只写自己工作树中的自忽略 Recorder/报告。精确受管理工作树根经核验；初始、Recovery Acceptance 与最终 Git status 均为0。

实际 main 4f18d222c75bb03166b2b5ead84b9999150a300c 的两个父提交为已接受 base 9c0eba89219b3fab73fe9258a7cfc59831c499dc 和中文候选 33cc754e6394d84f77540a814837deba42ad6e5f；树 d2e2fb9c7449fde2b0ab92b2d86a1a68e4a623b2 与候选完全一致，无合并偏离。限定文档/AGENTS 变更；产品、公共契约、backend、clients、plugins、shared、checker、CI、PDF 无变更。

中文 ADR-0006 与三份文档覆盖批准的 Desktop 独立视觉实现、共享语义、React 内置状态、Mobile ViewModel/StateFlow/Navigation、主题 Token、截图及 Architect 验收。S2 插件代码执行禁令不抹除 S4 经审查沙箱 Render Bundle；ACK/游标/SQLite 原子性及 contracts 唯一公共权威保留。没有选定额外路由/UI/状态库或提前实现 GUI/AI/插件。规范 §6.5 与机器依赖策略有明确 Human 来源。v1.1、ADR0005、旧 FAIL/豁免、PR7/PR8 与历史 PDF 保留。无最小性或边界阻塞发现。

本地检查：source all PASS/零违规；frozen verifier --base-commit 9c0eba8 PASS，canonical a234bc06/PDF546915 正确；完整 BASE..HEAD diff --check PASS；干净提交 Recovery Acceptance PASS/24 task specs/status0。具体 argv、退出码、时长和原始输出哈希见 main-review.json 与 Recorder events。候选树一致且 Review2 已验证53 architecture tests，本次没有重复不变产品运行期验证。

独立读取原始托管提供方 JSON：run37098121554 exact main4f18d22，13项任务，classify/architecture/source_go/source_java/gate全部SUCCESS且每一步SUCCESS；另8项仅按文档变更正确inactive/skipped。未用旧22CI替代中文候选或实际main验收。Review2精确33候选报告已读取作为前置来源；本结论仍基于实际main独立核对。

失败如实保留：启动前 Python2 调用及误选GB18030读取失败；已改用明确Python3/UTF-8。Recorder内一次章节读取引号SyntaxError，随后本脚本修正。Recorder为prospective_resume，启动前只读轨迹不完整，不能声称完整prospective。

PASS 接受精确实际main的本地独立Review和对应hosted验收。原H:/IM-platform受保护同步尚须Coordinator完成，之后才能完成任务/写入生效记录；本Reviewer未改原仓、任务或current.md，未声明done或S2 Gate PASS。S1 PASS/S2 OPEN。
''',encoding='utf-8')
print('REPORT_PASS',str(out/'main-review.json'))