from pathlib import Path
import json,gzip,zipfile,hashlib,subprocess
base='9c0eba89219b3fab73fe9258a7cfc59831c499dc'
old='22e82db'
root=Path('spec/progress/evidence/LOOP1-CLIENT-UI-ARCH-001')
h=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((root/'chinese-revision/raw-archive-manifest.json').read_text())
checked=[]
for e in manifest:
 p=root/e['archive_path']; b=p.read_bytes(); assert h(b)==e['compressed_sha256'],str(p)
 if p.suffix=='.gz':
  raw=gzip.decompress(b); assert h(raw)==e['raw_sha256']
  prior=subprocess.check_output(['git','show',old+':'+str(root/e['raw_path']).replace('\\','/')]); assert raw==prior,str(p)
  if 'normalized_sha256' in e: assert h((root/e['raw_path']).read_bytes())==e['normalized_sha256']
 else:
  with zipfile.ZipFile(p) as z:
   for f in e['files']:
    content=z.read(f['path']); assert h(content)==f['sha256']
    source=Path(e['source'])/f['path']; assert source.read_bytes()==content,str(source)
 checked.append(e['archive_path'])
for e in json.loads((root/'chinese-revision/fix-recorder-manifest.json').read_text()):
 print('FIXMANIFEST',type(e).__name__);break
paths=subprocess.check_output(['git','diff','--name-only',base+'..HEAD'],text=True).splitlines()
assert not any(p.startswith(('clients/','shared/','backend/','contracts/','ci/','tools/','tests/')) or p.endswith('.pdf') for p in paths)
assert subprocess.check_output(['git','status','--porcelain=v1'])==b''
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='33cc754e6394d84f77540a814837deba42ad6e5f'
assert len(list(Path('spec/tasks').glob('*/LOOP1-CLIENT-UI-ARCH-001.md')))==1
print(json.dumps({'result':'PASS','archive_count':len(checked),'archives':checked,'all_raw_bytes_equal_old_commit':True,'review1_original_files_equal_archive':True,'product_contract_tools_ci_pdf_diff_zero':True,'status_entries':0},indent=2))
