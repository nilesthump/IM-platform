from pathlib import Path
import subprocess,gzip,hashlib,json,zipfile
root=Path.cwd();out=root/'spec/progress/evidence/LOOP1-CLIENT-UI-ARCH-001/mvp-planning/whitespace-fix';prefix=out.parent
sha=lambda b:hashlib.sha256(b).hexdigest();lf=lambda b:b.replace(b'\r\r\n',b'\n').replace(b'\r\n',b'\n')
manifest=json.loads((out/'preservation-manifest.json').read_text(encoding='utf-8'))
for name in ('checks.json','pr-body.md','recorder-relocation.json'):
 p=prefix/name;rel=p.relative_to(root).as_posix();checkout=p.read_bytes();blob=subprocess.check_output(['git','show','HEAD:'+rel]);new=lf(checkout);entry={'path':rel,'reason':'LF reading copy only; original results/commands/durations and relocation facts unchanged. Exact original bytes gzip-preserved.','normalized_lf_sha256':sha(new),'sources':[]}
 for kind,data in [('candidate_git_blob',blob),('candidate_checkout',checkout)]:
  target=out/'preserved-original'/(name+'.'+kind+'.gz');target.write_bytes(gzip.compress(data,mtime=0));entry['sources'].append({'kind':kind,'candidate':'6e9f7327c6cf301a3841bcc49244b70974e82a06','original_sha256':sha(data),'bytes':len(data),'archive':target.relative_to(root).as_posix(),'gzip_sha256':sha(target.read_bytes())})
 p.write_bytes(new);manifest['normalized_files'].append(entry)
manifest['note']=manifest['note'].replace('Old checks.json is unchanged;','Old checks.json is a disclosed LF reading copy of preserved original bytes; its result/argv/duration values are unchanged;')
first=out/'rechecks-attempt1.zip';entries=[]
with zipfile.ZipFile(first,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted((out/'rechecks').glob('*')):
  data=p.read_bytes();z.writestr(p.name,data);entries.append({'path':p.name,'sha256':sha(data)})
manifest['first_recheck_archive']={'path':first.relative_to(root).as_posix(),'sha256':sha(first.read_bytes()),'entries':entries,'result':'FAIL: further CRLF text in checks.json, pr-body.md, recorder-relocation.json; all behavioral checks PASS.'}
(out/'preservation-manifest.json').write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())
for p in (out/'repair.md',root/'spec/progress/current.md',root/'spec/tasks/review/LOOP1-CLIENT-UI-ARCH-001.md'):
 data=p.read_bytes().replace(b'Old checks.json remains unchanged.',b'Old checks.json is an LF reading copy with all result/argv/duration values unchanged; its original bytes are gzip-preserved.').replace(b'original checks.json/history/Recorder remain unchanged.',b'original checks.json bytes are gzip-preserved; its LF reading copy retains all result values; history/Recorder remain unchanged.')
 data+=b'\nFirst repair verification found additional CRLF in checks.json, pr-body.md and recorder-relocation.json. Exact originals were preserved before LF-only normalization; first FAIL attempt is retained in whitespace-fix/rechecks-attempt1.zip. No old result/command/duration/relocation fact changed.\n';p.write_bytes(data)
p=prefix/'run_checks.py';data=p.read_bytes().replace(b"output_prefix=prefix+'whitespace-fix/rechecks/'",b"output_prefix=prefix+'whitespace-fix/rechecks-attempt2/'");p.write_bytes(data)
# Update recorded normalized hash for the checker after the explicit output destination change.
for e in manifest['normalized_files']:
 if e['path']==p.relative_to(root).as_posix():e['normalized_lf_sha256']=sha(p.read_bytes())
(out/'preservation-manifest.json').write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())
print('Preserved three additional original files and first FAIL; LF-only reading copies completed.')