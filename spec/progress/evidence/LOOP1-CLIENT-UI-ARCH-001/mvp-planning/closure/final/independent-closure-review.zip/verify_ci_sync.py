import json,hashlib,gzip,subprocess
from pathlib import Path
meta=Path('H:/IM-platform/.git/worktrees/IM-platform4'); root=meta/'mvp-closure-review'; main=Path('H:/IM-platform')
h=lambda b:hashlib.sha256(b).hexdigest(); required={'classify','source_go','source_java','architecture','gate'}
providers=[]
for rid in ('37105616559','37105628066'):
 p=meta/'mvp-provider-evidence'/(rid+'-completed.json'); d=json.loads(p.read_text()); assert d['headSha']=='6824564f060715768f0a94d046469f29aee3f61b' and d['conclusion']=='success'
 active=[j for j in d['jobs'] if j['conclusion']=='success']; inactive=[j for j in d['jobs'] if j['conclusion']=='skipped']
 assert {j['name'] for j in active}==required and len(d['jobs'])==13 and len(inactive)==8
 assert {j['name'] for j in inactive}=={'go','java','web','desktop','mobile','shared','compatibility','deploy'}
 assert all(s['conclusion']=='success' for j in active for s in j['steps']); assert all(not j['steps'] for j in inactive)
 providers.append(dict(run=rid,head=d['headSha'],sha256=h(p.read_bytes()),selected=sorted(required),inactive=8))
pre=json.loads((meta/'main-sync-preflight.json').read_text()); protected=json.loads((meta/'mvp-main-sync-protection/private-manifest.json').read_text()); receipt=json.loads((meta/'mvp-main-sync-receipt.json').read_text()); entries=pre['entries']; n=0
for path,value in entries.items():
 if path in protected: continue
 p=main/path
 if value['sha256'] is not None: assert p.is_file() and h(p.read_bytes())==value['sha256'], 'private unrelated content changed'
 else: assert not p.exists(), 'private deleted path reappeared'
 n+=1
assert n==781
for path,value in protected.items():
 if value.get('absent'): continue
 assert h(gzip.decompress(Path(value['gzip']).read_bytes()))==value['sha256']
assert receipt==json.loads(Path('spec/progress/evidence/LOOP1-CLIENT-UI-ARCH-001/mvp-planning/closure/synchronization.json').read_text())
assert subprocess.check_output(['git','-C',str(main),'rev-parse','HEAD']).decode().strip()==receipt['synchronized_main']
assert subprocess.check_output(['git','-C',str(main),'branch','--show-current']).decode().strip()==receipt['main_repository_local_branch_preserved']
assert subprocess.check_output(['git','rev-parse','b60f116^{tree}']).strip()==subprocess.check_output(['git','rev-parse','7466ce7^{tree}']).strip()
assert not subprocess.check_output(['git','-c','core.excludesFile=.git/info/exclude','status','--porcelain=v1']).strip()
result=dict(result='PASS',exact_candidate_providers=providers,unrelated_hashes_unchanged=n,owned_prior_metadata_preserved=len(protected),private_paths_or_contents_exported=False,actual_main=receipt['synchronized_main'],clean_candidate=True)
(root/'ci-and-sync-verification.json').write_text(json.dumps(result,indent=2),encoding='utf8'); print(json.dumps(result,indent=2))