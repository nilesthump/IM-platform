from pathlib import Path
import subprocess,gzip,hashlib,json,zipfile
root=Path.cwd(); meta=Path('H:/IM-platform/.git/worktrees/IM-platform4/mvp-fix-research'); prefix=Path('spec/progress/evidence/LOOP1-CLIENT-UI-ARCH-001/mvp-planning'); out=root/prefix/'whitespace-fix'; out.mkdir(parents=True,exist_ok=True); saved=out/'preserved-original';saved.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def lf(b): return b.replace(b'\r\r\n',b'\n').replace(b'\r\n',b'\n')
def write(p,s):p.write_bytes(s.encode('utf-8'))
entries=[]
paths=list((root/prefix).glob('*.txt'))+[root/prefix/'run_checks.py',root/prefix/'verify_planning.py']+[root/'spec/tasks/backlog'/ (i+'.md') for i in ('LOOP1-CLIENT-GUI-001','LOOP1-CLIENT-SEND-001','LOOP1-SYNC-001','LOOP1-WEB-001')]
for p in paths:
 rel=p.relative_to(root).as_posix();blob=subprocess.check_output(['git','show','HEAD:'+rel]); checkout=p.read_bytes(); normalized=lf(checkout)
 if '/backlog/' in rel: normalized=b'\n'.join(line.rstrip(b' \t') for line in normalized.split(b'\n'))
 if p.name=='verify_planning.py':
  # Whitespace cleanup removes the trailing space formerly included in this mutation literal.
  normalized=normalized.replace(b"done). ','')",b"done).','')")
 if p.name=='run_checks.py':
  normalized=normalized.replace(b"prefix='spec/progress/evidence/LOOP1-CLIENT-UI-ARCH-001/mvp-planning/'",b"prefix='spec/progress/evidence/LOOP1-CLIENT-UI-ARCH-001/mvp-planning/'\noutput_prefix=prefix+'whitespace-fix/rechecks/'\n(root/output_prefix).mkdir(parents=True,exist_ok=True)")
  normalized=normalized.replace(b"['git','diff','--check'],",b"['git','diff','--check','59dcf34e4538d2f35ccafde8104e860f8cf5cd7a'],")
  normalized=normalized.replace(b'root/prefix/',b'root/output_prefix/').replace(b"'output':prefix+",b"'output':output_prefix+")
  normalized=normalized.replace(b"encoding='utf-8')",b"encoding='utf-8',newline='\\n')")
 if normalized==checkout:continue
 record={'path':rel,'reason':'Explicit LF reading copy of preserved originals; normalize CRCRLF/CRLF without adding paragraphs; trim backlog trailing spaces. Checker updates cover fixed-base range and retain valid negative controls.','normalized_lf_sha256':sha(normalized),'sources':[]}
 for kind,data in [('candidate_git_blob',blob),('candidate_checkout',checkout)]:
  target=saved/(p.name+'.'+kind+'.gz');target.write_bytes(gzip.compress(data,mtime=0))
  record['sources'].append({'kind':kind,'candidate':'6e9f7327c6cf301a3841bcc49244b70974e82a06','original_sha256':sha(data),'bytes':len(data),'crlf_count':data.count(b'\r\n'),'crcrlf_count':data.count(b'\r\r\n'),'archive':target.relative_to(root).as_posix(),'gzip_sha256':sha(target.read_bytes())})
 p.write_bytes(normalized);entries.append(record)
review=Path('H:/IM-platform/.git/worktrees/IM-platform4/mvp-independent-review');z=out/'independent-failed-review.zip';archive_entries=[]
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as package:
 for p in sorted(review.rglob('*')):
  if p.is_file():
   data=p.read_bytes();rel=p.relative_to(review).as_posix();package.writestr(rel,data);archive_entries.append({'path':rel,'original_sha256':sha(data),'bytes':len(data)})
write(out/'preservation-manifest.json',json.dumps({'candidate':'6e9f7327c6cf301a3841bcc49244b70974e82a06','base':'59dcf34e4538d2f35ccafde8104e860f8cf5cd7a','note':'Original Human approval and log bytes are preserved in gzip. human-request.txt and check logs are explicitly LF reading copies; bytes changed, semantics retained. Old checks.json is unchanged; its diff PASS applies only to working diff. Prior Git history and Recorder are not edited.','normalized_files':entries,'failed_review_archive':{'path':z.relative_to(root).as_posix(),'zip_sha256':sha(z.read_bytes()),'source':str(review),'entries':archive_entries}},ensure_ascii=False,indent=2)+'\n')
ci=Path('H:/IM-platform/.git/worktrees/IM-platform4/mvp-provider-evidence'); records=[]
for p in sorted(ci.glob('*.json')):
 d=out/'prior-ci'/p.name;d.parent.mkdir(exist_ok=True);data=p.read_bytes();d.write_bytes(data);records.append({'source':str(p),'path':d.relative_to(root).as_posix(),'sha256':sha(data)})
write(out/'prior-ci-manifest.json',json.dumps({'note':'Prior candidate CI does not override its independent Review FAIL and does not accept the new repaired SHA. Provider bytes copied unchanged.','entries':records},indent=2)+'\n')
write(out/'repair.md','# Fresh whitespace repair (pending independent acceptance)\n\nFresh fixer /root/mvp_whitespace_fix repairs independent review FAIL on 6e9f7327c6cf301a3841bcc49244b70974e82a06. Full BASE..HEAD diff failed exit2; old working-diff PASS was limited. Failed review and Recorder remain unchanged in independent-failed-review.zip; preservation-manifest.json hashes every original blob/checkout archive and LF copy, including Human approval. Old checks.json remains unchanged.\n\nOnly LF normalization and backlog trailing whitespace are repaired. run_checks.py now checks fixed-base complete working range, emits separate rechecks with explicit LF, and preserves old results. Planning missing-dependency mutation no longer depends on a trailing space. Frozen hash16e9c7b4, v1.1, PDF546915, contracts/source/ADRs unchanged. Task remains review; S1 PASS/S2 OPEN. New fresh independent Review, exact-head hosted CI, protected integration and actual-main synchronization remain required before SEND.\n\nRecorder R-MVP-FIX-20261003 is prospective_resume: startup reads and baseline before run are explicitly incomplete pre-Recorder activity. Recorder valid does not mean task acceptance.\n')
for rel in ('spec/tasks/review/LOOP1-CLIENT-UI-ARCH-001.md','spec/progress/current.md'):
 p=root/rel;data=lf(p.read_bytes());data+=b'\n## Fresh whitespace fix / independent review FAIL\n\nIndependent Review of 6e9f7327c6cf301a3841bcc49244b70974e82a06 failed full BASE..HEAD diff --check (exit2); earlier diff PASS covered working diff only. Fresh fixer /root/mvp_whitespace_fix owns scoped repair writes in assigned worktree on task/LOOP1-CLIENT-MVP-PLAN-20261003. Original approval/log Git blob and checkout bytes, failed review and Recorder are preserved with hashes under mvp-planning/whitespace-fix/. LF copies explicitly change bytes; original checks.json/history/Recorder remain unchanged. Fixed-base full-range verification replaces limited working-diff check; separate rechecks preserve old results. Task stays review, S1 PASS/S2 OPEN. Next: clean fix commit -> NEW fresh independent Review -> exact-head hosted CI -> protected integration/actual-main synchronization; no SEND before acceptance. Last accepted main remains 59dcf34e4538d2f35ccafde8104e860f8cf5cd7a.\n';p.write_bytes(data)
print(json.dumps({'preserved_and_repaired':len(entries),'failed_review_archive_files':len(archive_entries),'prior_ci_files':len(records)}))