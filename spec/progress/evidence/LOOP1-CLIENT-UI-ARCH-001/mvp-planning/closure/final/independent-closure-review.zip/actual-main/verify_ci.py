import json,hashlib
from pathlib import Path
p=Path('H:/IM-platform/.git/worktrees/IM-platform4/mvp-provider-evidence/37106104177-completed.json'); r=Path('H:/IM-platform/.git/worktrees/IM-platform4/mvp-closure-review/actual-main'); d=json.loads(p.read_text()); required={'classify','architecture','source_go','source_java','gate'}
assert d['headSha']=='10b77b22386234c98409ca41b3622ad6d25f3884' and d['conclusion']=='success'
a=[j for j in d['jobs'] if j['conclusion']=='success']; n=[j for j in d['jobs'] if j['conclusion']=='skipped']; assert len(d['jobs'])==13 and {j['name'] for j in a}==required
assert len(n)==8 and {j['name'] for j in n}=={'go','java','web','desktop','mobile','shared','compatibility','deploy'}; assert all(not j['steps'] for j in n); assert all(s['conclusion']=='success' for j in a for s in j['steps'])
x=dict(result='PASS',run='37106104177',head=d['headSha'],provider_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),selected=sorted(required),every_executed_step='SUCCESS',correct_inactive=8)
(r/'ci-verification.json').write_text(json.dumps(x,indent=2),encoding='utf8'); print(json.dumps(x,indent=2))