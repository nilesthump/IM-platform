from pathlib import Path
import json,gzip,zipfile,hashlib,subprocess,time
root=Path.cwd();out=root/'spec/progress/evidence/LOOP1-CLIENT-UI-ARCH-001/mvp-planning/whitespace-fix';manifest=json.loads((out/'preservation-manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for e in manifest['normalized_files']:
 assert sha((root/e['path']).read_bytes())==e['normalized_lf_sha256'],e['path']
 for s in e['sources']:
  data=(root/s['archive']).read_bytes();assert sha(data)==s['gzip_sha256'];assert sha(gzip.decompress(data))==s['original_sha256']
f=manifest['failed_review_archive'];assert sha((root/f['path']).read_bytes())==f['zip_sha256']
with zipfile.ZipFile(root/f['path']) as z:
 for e in f['entries']:assert sha(z.read(e['path']))==e['original_sha256']
text='\nLocal repair verification (not independent acceptance): frozen --base-commit PASS 0.188s; source all PASS 0.515s; 53 architecture tests PASS 6.032s; planning with3 negative controls PASS 0.171s; fixed-base full working diff PASS0.047s; Recovery Development PASS6.719s. Exact argv/exit/duration: whitespace-fix/rechecks-attempt2/checks.json. All original/archive/normalized hashes verified. Pending clean fix commit, complete staged and committed range checks, clean Recovery Acceptance, then NEW fresh independent Review/exact-head CI and main synchronization. No sync or completion claimed.\n'
for p in [out/'repair.md',root/'spec/progress/current.md',root/'spec/tasks/review/LOOP1-CLIENT-UI-ARCH-001.md']:p.write_bytes(p.read_bytes()+text.encode())
print('PASS archive originals, normalized copies and failed Review ZIP hashes; local verification handoff updated.')