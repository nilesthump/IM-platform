import json,hashlib,subprocess
from pathlib import Path
r=Path('H:/IM-platform/.git/worktrees/IM-platform4/mvp-closure-review/actual-main'); g=lambda *a:subprocess.check_output(['git','-c','core.excludesFile=.git/info/exclude',*a]).decode().strip()
head='10b77b22386234c98409ca41b3622ad6d25f3884'; candidate='6824564f060715768f0a94d046469f29aee3f61b'; parent='b60f116a14f9265031bff255db500f3414f2a357'
assert g('rev-parse','HEAD')==head and g('rev-parse','origin/main')==head
assert g('rev-parse','HEAD^1')==parent and g('rev-parse','HEAD^2')==candidate
assert g('rev-parse','HEAD^{tree}')==g('rev-parse',candidate+'^{tree}')
assert g('rev-parse','--show-toplevel')=='H:/.codex/worktrees/client-mvp-planning/IM-platform'
assert not g('status','--porcelain=v1') and not g('diff',candidate,head)
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert h('spec/architecture/frozen-architecture.md')=='16e9c7b488e00dd39c7c2b5da7286c22be6ac67c163f0e89733bbe00297d0a3c'
assert h('scalable-distributed-im-architecture.pdf')=='546915f639f30cd294f11390da3ade2ce6a85b620bf55727c2a90ca6017d7510'
assert len(list(Path('spec/tasks').glob('*/LOOP1-CLIENT-UI-ARCH-001.md')))==1
result=dict(result='PASS',actual_main=head,first_parent=parent,second_parent=candidate,tree=g('rev-parse','HEAD^{tree}'),clean=True,previous_candidate_review_remains_applicable=True,main_repository_sync='PENDING',gate='S2 OPEN')
(r/'main-assertions.json').write_text(json.dumps(result,indent=2),encoding='utf8'); print(json.dumps(result,indent=2))