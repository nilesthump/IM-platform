import os,sys,json,time,subprocess,hashlib,zipfile,re
from pathlib import Path
root=Path('H:/IM-platform/.git/worktrees/IM-platform4/mvp-closure-review/actual-main')
repo=Path.cwd(); py=sys.executable; run='R-MVP-CLOSURE-ACTUAL-MAIN-20261003'
os.environ['PATH']=str(Path(py).parent)+os.pathsep+os.environ['PATH']; os.environ['PYTHONDONTWRITEBYTECODE']='1'
commands=[['git','-c','core.excludesFile=.git/info/exclude','status','--porcelain=v1'],[py,'-X','utf8','-B','ci/check_architecture.py','--scope','all','--json'],[py,'-X','utf8','-B','tools/verify_frozen_architecture.py','--base-commit','59dcf34e4538d2f35ccafde8104e860f8cf5cd7a'],[py,'-X','utf8','-B','-m','unittest','discover','-s','tests/architecture'],[py,'-X','utf8','-B','spec/progress/evidence/LOOP1-CLIENT-UI-ARCH-001/mvp-planning/verify_planning.py'],['git','diff','--check','59dcf34e4538d2f35ccafde8104e860f8cf5cd7a','HEAD'],['pwsh','-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode','Acceptance']]
results=[]
for i,argv in enumerate(commands):
 t=time.perf_counter(); q=subprocess.run([py,'-X','utf8','tools/research/recorder.py','run-command','--research-root',str(root),'--run-id',run,'--']+argv,capture_output=True)
 elapsed=round(time.perf_counter()-t,3); (root/f'check-{i}.txt').write_bytes(q.stdout+q.stderr); results.append(dict(argv=argv,exit_code=q.returncode,elapsed_seconds=elapsed,raw_output=f'check-{i}.txt')); print(i,q.returncode,elapsed,flush=True)
(root/'checks.json').write_text(json.dumps(results,indent=2),encoding='utf8')
assert all(r['exit_code']==0 for r in results),results