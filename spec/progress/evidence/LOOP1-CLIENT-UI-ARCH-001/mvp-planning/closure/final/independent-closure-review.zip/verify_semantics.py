import json,hashlib,zipfile,gzip,subprocess,importlib.util
from pathlib import Path
root=Path('H:/IM-platform/.git/worktrees/IM-platform4/mvp-closure-review'); repo=Path.cwd(); ev=repo/'spec/progress/evidence/LOOP1-CLIENT-UI-ARCH-001/mvp-planning'; closure=ev/'closure'
h=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git','-c','core.excludesFile=.git/info/exclude',*a])
assert git('rev-parse','HEAD').decode().strip()=='6824564f060715768f0a94d046469f29aee3f61b'
assert not git('status','--porcelain=v1').strip()
assert not git('diff','b60f116','HEAD','--','clients','backend','contracts','deploy','ci','tools','tests','research','spec/architecture/frozen-architecture.md','scalable-distributed-im-architecture.pdf','spec/tasks/backlog')
count=0
for a in json.loads((closure/'archive-manifest.json').read_text()):
 p=closure/a['archive']; assert h(p.read_bytes())==a['sha256'],p
 with zipfile.ZipFile(p) as z:
  assert set(z.namelist())==set(a['members']),p
  for member,digest in a['members'].items(): assert h(z.read(member))==digest,member; count+=1
  target=root/'verified-archives'/p.stem
  for member in z.namelist():
   q=target/member; assert q.resolve().is_relative_to(target.resolve()); q.parent.mkdir(parents=True,exist_ok=True); q.write_bytes(z.read(member))
manifest=json.loads((ev/'whitespace-fix/preservation-manifest.json').read_text())
for f in manifest['normalized_files']:
 assert h((repo/f['path']).read_bytes())==f['normalized_lf_sha256'],f['path']
 for src in f['sources']:
  b=(repo/src['archive']).read_bytes(); assert h(b)==src['gzip_sha256']; raw=gzip.decompress(b); assert h(raw)==src['original_sha256']; assert len(raw)==src['bytes']
  if src['kind']=='candidate_git_blob': assert raw==git('show',src['candidate']+':'+f['path'])
old='6e9f7327c6cf301a3841bcc49244b70974e82a06'
assert git('diff','--name-only','b60f116','HEAD','--','spec/progress/evidence/LOOP1-CLIENT-UI-ARCH-001/mvp-planning/whitespace-fix').strip()==b''
required={'classify','source_go','architecture','source_java','gate'}
provider=[]
for rid,head in [('37104671763','7466ce7ab23eba20d5c4b8ad714804684acdc1a6'),('37104674713','7466ce7ab23eba20d5c4b8ad714804684acdc1a6'),('37105047668','b60f116a14f9265031bff255db500f3414f2a357')]:
 d=json.loads((closure/(rid+'.json')).read_text()); assert d['headSha']==head and d['conclusion']=='success'
 active=[j for j in d['jobs'] if j['conclusion']=='success']; print('PROVIDER',rid,[j['name'] for j in active])
 assert {j['name'] for j in active}==required
 assert len(d['jobs'])==13 and len(active)==5
 assert all(j['conclusion']=='skipped' for j in d['jobs'] if j not in active)
 assert all(s['conclusion']=='success' for j in active for s in j['steps'])
 provider.append(dict(run=rid,head=head,required=sorted(required),inactive=8))
modspec=importlib.util.spec_from_file_location('recorder',repo/'tools/research/recorder.py'); mod=importlib.util.module_from_spec(modspec); modspec.loader.exec_module(mod)
validations=[]
for p in (root/'verified-archives').rglob('runs/R-*/metadata.json'):
 m=json.loads(p.read_text()); assert m['status']=='finished',p; result=mod.validate_run(p.parent.parent.parent,p.parent.name); validations.append(result)
for p in (root/'verified-archives/independent-review2-and-actual-main').rglob('review.md'): print(p.relative_to(root),p.read_text('utf8'))
result=dict(result='PASS',archive_member_hashes=count,preservation_normalized_files=len(manifest['normalized_files']),provider=provider,recorders=validations,product_contract_canonical_task_dependencies_unchanged_from_accepted_parent=True)
(root/'semantic-checks.json').write_text(json.dumps(result,indent=2),encoding='utf8'); print(json.dumps(result,indent=2))