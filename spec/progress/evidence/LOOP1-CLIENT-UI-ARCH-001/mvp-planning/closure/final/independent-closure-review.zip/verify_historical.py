import json,hashlib,zipfile
from pathlib import Path
r=Path.cwd(); p=r/'spec/progress/evidence/LOOP1-CLIENT-UI-ARCH-001/mvp-planning/whitespace-fix/preservation-manifest.json'; d=json.loads(p.read_text()); h=lambda b:hashlib.sha256(b).hexdigest()
for key in ('failed_review_archive','first_recheck_archive'):
 a=d[key]; q=r/a['path']; assert h(q.read_bytes())==a.get('zip_sha256',a.get('sha256'))
 with zipfile.ZipFile(q) as z:
  assert set(z.namelist())=={e['path'] for e in a['entries']}
  for e in a['entries']:
   b=z.read(e['path']); assert h(b)==e.get('original_sha256',e.get('sha256')); assert 'bytes' not in e or len(b)==e['bytes']
print('PASS original failed independent Review archive and partial repair FAIL archive hash/member/size preservation')