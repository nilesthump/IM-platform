from pathlib import Path
import subprocess,json,gzip,hashlib,zipfile,re
r=Path('H:/.codex/worktrees/client-mvp-planning/IM-platform'); o=Path('H:/IM-platform/.git/worktrees/IM-platform4/mvp-independent-review2'); e=r/'spec/progress/evidence/LOOP1-CLIENT-UI-ARCH-001/mvp-planning'; sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((e/'whitespace-fix/preservation-manifest.json').read_text('utf8')); count=0
for f in m['normalized_files']:
 assert sha((r/f['path']).read_bytes().replace(b'\r\n',b'\n'))==f['normalized_lf_sha256'],f['path']
 for s in f['sources']:
  z=(r/s['archive']).read_bytes(); b=gzip.decompress(z)
  assert sha(z)==s['gzip_sha256'] and sha(b)==s['original_sha256'] and len(b)==s['bytes']
  blob=subprocess.check_output(['git','show',s['candidate']+':'+f['path']],cwd=r)
  if s['kind']=='candidate_git_blob': assert blob==b
  count+=1
for key in ('independent_failed_review','first_recheck_archive'):
 if key not in m: continue
 a=m[key];print(key,a.keys())
# General ZIP manifest verification
for k,v in m.items():
 if isinstance(v,dict) and 'entries' in v and ('path' in v or 'archive' in v):
  p=r/v.get('path',v.get('archive'))
  assert sha(p.read_bytes())==v.get('sha256',v.get('zip_sha256',v.get('archive_sha256')))
  with zipfile.ZipFile(p) as z:
   for ent in v['entries']:
    b=z.read(ent['path']);assert sha(b)==ent.get('original_sha256',ent.get('sha256'))
# Original JSON result facts and approval content are identical after LF normalization.
for f in m['normalized_files']:
 if f['path'].endswith(('checks.json','recorder-relocation.json','human-request.txt','pr-body.md','check-0.txt','check-1.txt','check-2.txt','check-3.txt','check-5.txt')):
  old=gzip.decompress((r/f['sources'][0]['archive']).read_bytes()).replace(b'\r\r\n',b'\n').replace(b'\r\n',b'\n')
  new=(r/f['path']).read_bytes().replace(b'\r\n',b'\n');assert old==new,f['path']
pm=json.loads((e/'whitespace-fix/prior-ci-manifest.json').read_text('utf8'))
for f in pm['entries']: assert sha((r/f['path']).read_bytes())==f['sha256']
# write scope and previous accepted immutable tree
changed=subprocess.check_output(['git','diff','--name-only','59dcf34e4538d2f35ccafde8104e860f8cf5cd7a..HEAD'],cwd=r,text=True).splitlines()
task=(r/'spec/tasks/review/LOOP1-CLIENT-UI-ARCH-001.md').read_text('utf8'); allowed=re.findall(r'^- `([^`]+)`',task.split('# Allowed Paths')[1].split('# Acceptance')[0],re.M)
import fnmatch
assert all(any(fnmatch.fnmatch(p,a) for a in allowed) for p in changed)
assert all(p.startswith('spec/') for p in changed)
# Exact hosted jobs and every required step, inactive jobs have no executable steps.
ci=[]
expected={'classify','architecture','source_go','source_java','gate'}
for rid in ('37104671763','37104674713'):
 p=o.parent/'mvp-provider-evidence'/f'{rid}-completed.json'; c=json.loads(p.read_text('utf8'))
 print(rid,[(j['name'],j['conclusion'],len(j['steps'])) for j in c['jobs']])
 assert c['headSha']=='7466ce7ab23eba20d5c4b8ad714804684acdc1a6' and c['conclusion']=='success' and c['status']=='completed'
 selected={j['name'] for j in c['jobs'] if j['conclusion']=='success'}
 assert selected==expected,(rid,selected)
 for j in c['jobs']:
  if j['name'] in expected: assert j['steps'] and all(s['conclusion']=='success' for s in j['steps'])
  else: assert j['conclusion']=='skipped' and not j['steps']
 ci.append(dict(run=rid,sha256=sha(p.read_bytes()),selected=sorted(selected),inactive=sorted(j['name'] for j in c['jobs'] if j['conclusion']=='skipped')))
assert subprocess.check_output(['git','-c','core.excludesFile=.git/info/exclude','status','--porcelain=v1'],cwd=r)==b''
result=dict(result='PASS',original_sources_verified=count,normalized_files_verified=len(m['normalized_files']),write_scope_files=len(changed),ci=ci)
(o/'semantic-checks.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result))

