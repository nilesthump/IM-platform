from pathlib import Path
import json
out=Path('H:/IM-platform/.git/worktrees/IM-platform4/mvp-independent-review2/actual-main')
checks=json.loads((out/'checks.json').read_text('utf8')); ci=json.loads((out/'ci-verification.json').read_text('utf8'))
rows='\n'.join('| `'+ ' '.join(c['argv'])+'` | '+str(c['exit'])+' | '+str(round(c['elapsed_seconds'],3))+' |' for c in checks)
report='''# Independent actual-main verification — PASS

Reviewer /root/mvp_independent_review2 remains independent of implementation, fresh fix, Coordinator and integration. This is read-only verification in the assigned clean worktree; only independent report/Recorder metadata was written. Previous finished candidate-review Recorder remains immutable.

Actual main / assigned HEAD / origin/main: `b60f116a14f9265031bff255db500f3414f2a357`.
First parent: `59dcf34e4538d2f35ccafde8104e860f8cf5cd7a`; second parent: reviewed candidate `7466ce7ab23eba20d5c4b8ad714804684acdc1a6`.
Main and candidate tree both `97c9b45dd31e2dc0ebcb9d976d48f803989aeb01`. Independent assertions confirm exact equality; no tree/source/contract change introduced by merge. Coordinator reports PR14 normal protected merge, no admin bypass.

Assigned Git root remains `H:/.codex/worktrees/client-mvp-planning/IM-platform`, branch task/LOOP1-CLIENT-MVP-PLAN-20261003; clean committed state asserted and Recovery Acceptance reports status_entries0/diff_lines0, unique CurrentTask UI-ARCH review, S1 PASS/S2 OPEN. Merge acceptance has not yet closed task administration.

Canonical SHA256 `16e9c7b488e00dd39c7c2b5da7286c22be6ac67c163f0e89733bbe00297d0a3c`; PDF `546915f639f30cd294f11390da3ade2ce6a85b620bf55727c2a90ca6017d7510`; v1.1 and historical hashes/evidence unchanged. Candidate semantic review remains applicable to exact same tree, including sole GUI ID, dependency equality and future UI acceptance boundaries. No new blocking finding.

| Exact argv | Exit | Wall seconds including Recorder |
| --- | --- | --- |
'''+rows+'''

Additional recorded assert_main.py commands independently assert actual head/parents/tree/hashes/clean status and provider exacthead/job/step results, exit0. Recorder stores exact duration_ms and raw-output hashes. Local source-all, 53 tests, planning3negative, full accepted-base..actual-main diffcheck and clean Recovery Acceptance all PASS.

Actual-main hosted run37105047668 is completed SUCCESS on exact `b60f116a14f9265031bff255db500f3414f2a357`. Five required classify/architecture/source_go/source_java/gate jobs and every executable step SUCCESS; eight correctly inactive go/java/web/desktop/mobile/shared/compatibility/deploy jobs skipped with zero steps. Independently checked against unchanged workflow and candidate same tree; no old candidate CI substitutes. Provider snapshot hash: `'''+ci['provider_sha256']+'''`; exact provider source path H:/IM-platform/.git/worktrees/IM-platform4/mvp-provider-evidence/37105047668-completed.json, summarized in ci-verification.json.

PASS is actual-main verification before H:/IM-platform synchronization. Synchronization remains PENDING and is explicitly not accepted here. Coordinator must preserve original repository unknown work, execute protected fast-forward synchronization, verify actual original-repository SHA/product tree and preservation evidence, then close current task/current/checkpoint through required independent acceptance. No SEND activation is authorized until that synchronization and accepted architecture closure complete; S2 Gate remains OPEN. No product/SEND work performed by this reviewer.

Research run R-MVP-ACTUAL-MAIN-20261003 is separate prospective review verification using registered visible Human prompt P-MVP-ACTUAL-MAIN-20261003. Candidate review report remains ../review.md. Recorder finish/validate results are separate research integrity evidence and do not prove synchronization or Stage Gate.
'''
(out/'review.md').write_text(report,encoding='utf8',newline='\n');print(str(out/'review.md'))
