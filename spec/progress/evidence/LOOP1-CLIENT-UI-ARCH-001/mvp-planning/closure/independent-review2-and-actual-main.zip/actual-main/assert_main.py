from pathlib import Path
import json,subprocess,hashlib,sys
r=Path('H:/.codex/worktrees/client-mvp-planning/IM-platform');o=Path('H:/IM-platform/.git/worktrees/IM-platform4/mvp-independent-review2/actual-main'); g=lambda *a:subprocess.check_output(['git','-c','core.excludesFile=.git/info/exclude',*a],cwd=r,text=True).strip()
sha='b60f116a14f9265031bff255db500f3414f2a357';candidate='7466ce7ab23eba20d5c4b8ad714804684acdc1a6'
assert g('rev-parse','HEAD')==sha and g('rev-parse','origin/main')==sha
assert g('rev-parse','HEAD^1')=='59dcf34e4538d2f35ccafde8104e860f8cf5cd7a' and g('rev-parse','HEAD^2')==candidate
assert g('rev-parse','HEAD^{tree}')==g('rev-parse',candidate+'^{tree}')
assert not g('status','--porcelain=v1')
for p,h in [('spec/architecture/frozen-architecture.md','16e9c7b488e00dd39c7c2b5da7286c22be6ac67c163f0e89733bbe00297d0a3c'),('scalable-distributed-im-architecture.pdf','546915f639f30cd294f11390da3ade2ce6a85b620bf55727c2a90ca6017d7510')]:assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h
assert all(c['exit']==0 for c in json.loads((o/'checks.json').read_text('utf8')))
print('PASS local actual-main identity/parents/candidate same tree, canonical/PDF hashes and clean committed recovery')
if len(sys.argv)>1:
 p=Path(sys.argv[1]);c=json.loads(p.read_text('utf8'));expected={'classify','architecture','source_go','source_java','gate'}
 assert c['headSha']==sha and c['conclusion']=='success' and c['status']=='completed'
 assert {j['name'] for j in c['jobs'] if j['conclusion']=='success'}==expected
 for j in c['jobs']:
  if j['name'] in expected:assert j['steps'] and all(s['conclusion']=='success' for s in j['steps'])
  else:assert j['conclusion']=='skipped' and not j['steps']
 assert len(c['jobs'])==13
 (o/'ci-verification.json').write_text(json.dumps(dict(result='PASS',head=sha,provider_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),run='37105047668',selected=sorted(expected),inactive=sorted(j['name'] for j in c['jobs'] if j['conclusion']=='skipped')),indent=2),encoding='utf8')
 print('PASS hosted actual-main 37105047668 exact SHA; 5 required jobs/every step SUCCESS; 8 correct inactive skips')
