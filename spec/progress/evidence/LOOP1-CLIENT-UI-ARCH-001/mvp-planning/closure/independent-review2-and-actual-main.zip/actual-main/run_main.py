from pathlib import Path
import subprocess,sys,json,os,time,gzip,hashlib,zipfile,re
root=Path('H:/.codex/worktrees/client-mvp-planning/IM-platform')
out=Path('H:/IM-platform/.git/worktrees/IM-platform4/mvp-independent-review2/actual-main')
py=sys.executable
rec=[py,'-X','utf8',str(root/'tools/research/recorder.py')]
common=['--research-root',str(out/'recorder'),'--run-id','R-MVP-ACTUAL-MAIN-20261003']
os.environ['PATH']=str(Path(py).parent)+os.pathsep+os.environ['PATH']
cmds=[['git','rev-parse','HEAD','HEAD^1','HEAD^2','HEAD^{tree}','7466ce7ab23eba20d5c4b8ad714804684acdc1a6^{tree}','origin/main'],[py,'-X','utf8','-B','ci/check_architecture.py','--scope','all','--json'],['git','-c','core.excludesFile=.git/info/exclude','status','--porcelain=v1'],[py,'-X','utf8','-B','tools/verify_frozen_architecture.py','--base-commit','59dcf34e4538d2f35ccafde8104e860f8cf5cd7a'],[py,'-X','utf8','-B','-m','unittest','discover','-s','tests/architecture'],[py,'-X','utf8','-B','spec/progress/evidence/LOOP1-CLIENT-UI-ARCH-001/mvp-planning/verify_planning.py'],['git','-c','core.excludesFile=.git/info/exclude','diff','--check','59dcf34e4538d2f35ccafde8104e860f8cf5cd7a..HEAD'],['pwsh','-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode','Acceptance']]
results=[]
for i,c in enumerate(cmds):
 t=time.monotonic();p=subprocess.run(rec+['run-command']+common+['--']+c,cwd=root,capture_output=True);dt=time.monotonic()-t
 (out/f'check-{i}.txt').write_bytes(p.stdout+p.stderr)
 results.append(dict(argv=c,exit=p.returncode,elapsed_seconds=dt,output=str(out/f'check-{i}.txt')))
 print(json.dumps(results[-1]),flush=True)
(out/'checks.json').write_text(json.dumps(results,indent=2),encoding='utf8')

