$ErrorActionPreference="Stop"
$ownedPid=[int](Get-Content -LiteralPath "H:/.codex/evidence/s2-sqlite-20261001/review3/emulator-pid.txt")
$p=Get-CimInstance Win32_Process -Filter "ProcessId=$ownedPid"
if(!$p -or $p.Name -ne "emulator.exe" -or $p.CommandLine -notmatch "IMStorageReview3Minimum34" -or $p.CommandLine -notmatch "-port 5580"){throw "Owned identity mismatch"}
$children=Get-CimInstance Win32_Process | Where-Object {$_.ParentProcessId -eq $ownedPid -and $_.Name -match "qemu" -and $_.CommandLine -match "IMStorageReview3Minimum34"}
& H:/Android/platform-tools/adb.exe -s emulator-5580 emu kill
Start-Sleep -Seconds 3
foreach($child in $children){$still=Get-CimInstance Win32_Process -Filter "ProcessId=$($child.ProcessId)";if($still -and $still.CommandLine -match "IMStorageReview3Minimum34"){Stop-Process -Id $child.ProcessId}}
$still=Get-CimInstance Win32_Process -Filter "ProcessId=$ownedPid"
if($still -and $still.CommandLine -match "IMStorageReview3Minimum34"){Stop-Process -Id $ownedPid}
Write-Output "Owned API34 emulator stopped; no user Pixel/shared ADB process touched."
