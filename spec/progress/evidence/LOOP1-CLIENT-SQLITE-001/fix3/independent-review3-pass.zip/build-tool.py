from pathlib import Path
import os,subprocess,sys,shutil
repo=Path("H:/isv3-sqlite"); owned=Path("H:/.codex/evidence/s2-sqlite-20261001/implementation")
env=os.environ.copy()
kind=sys.argv[1]
if kind == "mobile":
 env["JAVA_HOME"]="H:/.jdks/jdk17"; env["ANDROID_HOME"]="H:/Android"; env["ANDROID_SDK_ROOT"]="H:/Android"; env["GRADLE_USER_HOME"]="H:/gradle"
 gradle="H:/gradle/wrapper/dists/gradle-8.9-bin/78qddjpeqn5v6yec3xb8kv9ca/gradle-8.9/bin/gradle.bat"
 env["IM_CLIENT_GRADLE"]=gradle;env["IM_CLIENT_ADB"]="H:/Android/platform-tools/adb.exe"
 raise SystemExit(subprocess.call([sys.executable,"-B",str(repo/"tools/verify_client_sqlite.py"),"--scope","mobile","--serial","emulator-5580"],env=env,cwd=repo))
if kind in ("cargo","desktop"):
 env["RUSTUP_HOME"]="H:/.codex/toolchains/client-sqlite/rustup"; env["CARGO_HOME"]="H:/.codex/toolchains/client-sqlite/cargo"
 vc="C:/Program Files/Microsoft Visual Studio/2022/Community/VC/Auxiliary/Build/vcvars64.bat"
 result=subprocess.run('cmd /d /c call "'+vc.replace("/",chr(92))+'" >nul && set',capture_output=True,env=env)
 if result.returncode: raise SystemExit("MSVC environment failed: "+result.stderr.decode("utf-8","replace"))
 for line in result.stdout.decode("utf-8","replace").splitlines():
  if "=" in line:
   k,v=line.split("=",1)
   if k and not k.startswith("="): env[k]=v
 env["Path"]=str(Path(env["CARGO_HOME"])/"bin")+";"+env.get("Path",env.get("PATH",""))
 env["CARGO_TARGET_DIR"]="H:/.codex/evidence/s2-sqlite-20261001/review/target"
 env["RUSTUP_TOOLCHAIN"]="stable"
 env["CARGO_BUILD_JOBS"]="1"
 if kind=="desktop": raise SystemExit(subprocess.call([sys.executable,"-B",str(repo/"tools/verify_client_sqlite.py"),"--scope","desktop"],env=env,cwd=repo))
 exe=str(Path(env["CARGO_HOME"])/"bin/cargo.exe")
 raise SystemExit(subprocess.call([exe,*sys.argv[2:],"--manifest-path",str(repo/"clients/desktop/src-tauri/Cargo.toml")],env=env))
raise SystemExit("Unknown build tool")
