from pathlib import Path
import subprocess,json,hashlib,zipfile,gzip,re
p=Path('H:/ica');o=Path('H:/.codex/evidence/s2-sqlite-20261001/review2');base='a28752967ddd471cd281aece7ea9b343521356e8';head='6dc957c1a2f936d55a191e06a8003ff1af218c6f'
def git(*a):return subprocess.check_output(['git',*a],cwd=p,text=True).strip()
assert git('rev-parse','HEAD')==head
assert not git('status','--porcelain=v1')
paths=git('diff','--name-only',base,head).splitlines();print('\n'.join(paths))
old=set(git('ls-tree','-r','--name-only',base).splitlines()); changed_old=sorted(set(paths)&old)
print('CHANGED_BASELINE',json.dumps(changed_old))
assert not any(x.startswith(('contracts/','spec/architecture/','services/','deploy/','clients/web/')) for x in paths)
assert not any(re.search(r'(^|/)(adbkey|adbkey.pub|userdata.*|.*\.jks|.*\.keystore|\.env.*)$',x) for x in paths)
a=[]
for x in paths:
 f=p/x
 if not f.is_file():continue
 b=f.read_bytes();assert b'-----BEGIN PRIVATE KEY-----' not in b and b'-----BEGIN RSA PRIVATE KEY-----' not in b
 if x.endswith('.zip'):
  with zipfile.ZipFile(f) as z:
   for n in z.namelist():
    assert '..' not in Path(n).parts and not Path(n).is_absolute();assert not re.search(r'(^|/)(adbkey|adbkey.pub|userdata.*|.*\.jks|.*\.keystore|\.env.*)$',n)
    v=z.read(n);assert b'-----BEGIN PRIVATE KEY-----' not in v and b'-----BEGIN RSA PRIVATE KEY-----' not in v
  a.append(dict(path=x,members=len(z.namelist())))
e=p/'spec/progress/evidence/LOOP1-CLIENT-SQLITE-001/fix1';m=json.loads((e/'failed-review-archive-manifest.json').read_text());assert hashlib.sha256((e/'independent-failed-review.zip').read_bytes()).hexdigest()==m['archive_sha256']
with zipfile.ZipFile(e/'independent-failed-review.zip') as z:
 for i in m['files']:assert hashlib.sha256(z.read(i['path'])).hexdigest()==i['sha256']
for i in json.loads((e/'historical-persisted-blob-manifest.json').read_text()):assert hashlib.sha256(gzip.decompress((e.parent/i['path']).read_bytes())).hexdigest()==i['persisted_blob_sha256']
print('Egress safety audit PASS',len(paths),'changed paths',a)
(o/'egress-audit.json').write_text(json.dumps(dict(head=head,base=base,paths=paths,archives=a,failed_review_members=len(m['files']),old_gzip_count=22,status_entries=0,private_keys_found=False),indent=2)+'\n')
