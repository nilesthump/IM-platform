from pathlib import Path
import subprocess,os,sys,json,hashlib
p=Path('H:/.codex/evidence/s2-sqlite-20261001');own=p/'review2';env=os.environ.copy();env.update(JAVA_HOME='H:/.jdks/jdk17',ANDROID_HOME='H:/Android',ANDROID_SDK_ROOT='H:/Android',GRADLE_USER_HOME='H:/gradle',ANDROID_AVD_HOME=str(own/'avd-home'),ANDROID_USER_HOME=str(own/'android-user'))
for key in ('ANDROID_AVD_HOME','ANDROID_USER_HOME'):Path(env[key]).mkdir(exist_ok=True)
s=(p/'fix1/start-emulator.py').read_text().replace('s2-sqlite-20261001/fix1','s2-sqlite-20261001/review2').replace('IMStorageFixMinimum34','IMStorageReview2Minimum34').replace('5584','5586').replace('5585','5587');(own/'start-emulator.py').write_text(s)
s=(p/'fix1/tool.py').read_text();s=s[:s.index('if kind=="desktop":')];s=s.replace('s2-sqlite-20261001/fix1','s2-sqlite-20261001/review2').replace('repo=Path("H:/ica")','repo=Path("H:/isv2-sqlite")').replace('emulator-5584','emulator-5586');(own/'android-tool.py').write_text(s)
s=(p/'fix1/stop-emulator.ps1').read_text().replace('s2-sqlite-20261001/fix1','s2-sqlite-20261001/review2').replace('IMStorageFixMinimum34','IMStorageReview2Minimum34').replace('5584','5586');(own/'stop-emulator.ps1').write_text(s)
print('Independent helpers prepared, emulator not started yet')
