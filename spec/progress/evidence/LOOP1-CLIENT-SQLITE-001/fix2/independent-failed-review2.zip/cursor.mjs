import {Repository} from 'file:///H:/isv2-sqlite/clients/shared/protocol-sdk/dist/storage/repository.js';
import {spawnSync} from 'node:child_process'; import {mkdtempSync} from 'node:fs'; import {tmpdir} from 'node:os'; import {join} from 'node:path';
const root=mkdtempSync(join(tmpdir(),'im-review2-cursor-')); const probe='H:/.codex/evidence/s2-sqlite-20261001/review/target/debug/storage_probe.exe';
const hex=s=>Buffer.from(s,'utf8').toString('hex'); const bind=s=>s===null?'~':hex(s);
const call=s=>{const r=spawnSync(probe,[root,'10000000-0000-4000-8000-000000000090'],{input:s,encoding:'utf8'});if(r.status!==0)throw Error(r.stderr);return r.stdout.trimEnd();};
const db={async transaction(steps){call(steps.map(([s,b,e])=>['T',e??'-',hex(s),...b.map(bind)].join('\t')).join('\n')+'\n');},async query(s,b){const o=call(['Q',hex(s),...b.map(bind)].join('\t')+'\n');return o?o.split(/\r?\n/).map(l=>l.split('\t').map(v=>v==='~'?null:Buffer.from(v,'hex').toString('utf8'))):[];}};
const repo=new Repository(db);await repo.initialize(); const cursor='\u{1f600}'.repeat(256);let error=null;
try{await repo.userPage({syncVersion:'1.0',type:'sync.user.page',requestId:'40000000-0000-4000-8000-000000000090',events:[],nextCursor:cursor,hasMore:false},'0');}catch(e){error=e.message;}
console.log(JSON.stringify({legalCodepoints:[...cursor].length,utf16Units:cursor.length,error,durableCursor:await repo.cursor(),engine:'actual SQLx SQLite'}));
if(error!=='Invalid user page')throw Error('Expected independent reproducer changed');
