from pathlib import Path
import os,subprocess,time,socket,sys
own=Path("H:/.codex/evidence/s2-sqlite-20261001/review2")
env=os.environ.copy();env.update(JAVA_HOME="H:/.jdks/jdk17",ANDROID_HOME="H:/Android",ANDROID_SDK_ROOT="H:/Android",ANDROID_AVD_HOME=str(own/"avd-home"),ANDROID_USER_HOME=str(own/"android-user"))
name="IMStorageReview2Minimum34"; avd=own/"avd-home"/(name+".avd")
if avd.exists(): raise SystemExit("Fresh owned AVD already exists; stop and inspect, no overwrite")
for port in (5586,5587):
 s=socket.socket()
 try:s.bind(("127.0.0.1",port))
 except OSError:raise SystemExit("Owned port occupied, no existing emulator touched")
 finally:s.close()
r=subprocess.run(["H:/Android/cmdline-tools/latest/bin/avdmanager.bat","create","avd","-n",name,"-k","system-images;android-34;google_apis;x86_64","-p",str(avd)],input="no\n",text=True,env=env)
if r.returncode:raise SystemExit(r.returncode)
log=(own/"emulator.log").open("wb")
p=subprocess.Popen(["H:/Android/emulator/emulator.exe","-avd",name,"-port","5586","-no-window","-memory","2048","-wipe-data","-no-audio","-no-boot-anim","-no-snapshot","-gpu","swiftshader_indirect"],env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
(own/"emulator-pid.txt").write_text(str(p.pid));print("Only owned AVD started",name,"emulator-5586",p.pid,flush=True)
adb="H:/Android/platform-tools/adb.exe"
for i in range(120):
 if p.poll() is not None:raise SystemExit("Owned emulator exited")
 try:
  def shell(*args):return subprocess.run([adb,"-s","emulator-5586","shell",*args],env=env,capture_output=True,text=True,timeout=10).stdout.strip()
  boot=shell("getprop","sys.boot_completed");ce=shell("getprop","sys.user.0.ce_available")
  if boot=="1" and ce=="true":
   print("Actual stable runtime boot=",boot,"CE=",ce,"API=",shell("getprop","ro.build.version.sdk"),flush=True);raise SystemExit(0)
 except subprocess.TimeoutExpired:pass
 time.sleep(3)
raise SystemExit("Real minimum emulator readiness timeout; no false PASS")

