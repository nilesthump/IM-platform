from pathlib import Path
import json,hashlib,re
p=Path('H:/.codex/evidence/s2-sqlite-20261001/review2')
(p/'recorder-summary.md').write_text('Independent Review result FAIL; R-SQLITE-REVIEW2-20261002 finished/validated32events, manifest aa75d183d2c98f4465327e9418cacb9a8caacb5704533edc2c5c6a3238da3696. Finished event stream remains immutable. Report helper initially failed ledger duplicate secret_redaction_applied dict key; raw failure retained then fixed helper and ledger succeeded. No product mutation; no source fix/selfacceptance. All own runtime/build capability released. Public archive explicitly excludes android-user/avd-home/emulator logs and all caches/private keys.\n',encoding='utf-8',newline='\n')
files=[]
for f in p.rglob('*'):
 if not f.is_file():continue
 r=f.relative_to(p)
 if r.parts[0] in {'android-user','avd-home','target'} or r.name in {'public-byte-manifest.json','emulator.log','emulator-pid.txt'}:continue
 b=f.read_bytes();assert not re.search(rb'(?m)^-----BEGIN (?:RSA )?PRIVATE KEY-----\r?\n',b)
 files.append(dict(path=r.as_posix(),size=len(b),sha256=hashlib.sha256(b).hexdigest()))
b=(json.dumps(files,indent=2)+'\n').encode();(p/'public-byte-manifest.json').write_bytes(b)
print(json.dumps(dict(public_files=len(files),manifest_sha256=hashlib.sha256(b).hexdigest(),recorder_result='FAIL',validation='PASS',writer_released=True)))
