from pathlib import Path
import sys,subprocess,json,time
repo=Path("H:/isv2-sqlite");own=Path("H:/.codex/evidence/s2-sqlite-20261001/review2")
pwsh="C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe"
commands=[
[pwsh,"-NoProfile","-File","tools/verify-loop1-ctrl-002.ps1","-Mode","Acceptance"],
[sys.executable,"-B","ci/check_architecture.py","--scope","all","--json"],
[pwsh,"-NoProfile","-File","tools/verify-frozen-architecture.ps1"],
[sys.executable,"-B","-m","unittest","discover","-s","tests/architecture","-v"],
[sys.executable,"-B","-m","unittest","discover","-s","tests/ci","-v"],
[sys.executable,"-B","contracts/websocket/verify.py"],
[sys.executable,"-B","contracts/plugin-api/verify.py"],
["git","-c","core.whitespace=cr-at-eol","diff","--check"],
["git","status","--porcelain=v1"]]
result=[]
for index,cmd in enumerate(commands):
 t=time.monotonic();r=subprocess.run(cmd,cwd=repo,capture_output=True);elapsed=round(time.monotonic()-t,3)
 (own/("clean-check-"+str(index)+".stdout")).write_bytes(r.stdout);(own/("clean-check-"+str(index)+".stderr")).write_bytes(r.stderr)
 result.append(dict(argv=cmd,cwd=str(repo),exit_code=r.returncode,elapsed_seconds=elapsed,stdout_path="clean-check-"+str(index)+".stdout",stderr_path="clean-check-"+str(index)+".stderr"))
 print(index,cmd,"exit",r.returncode,"seconds",elapsed,flush=True)
 if r.returncode:print(r.stdout.decode("utf-8","replace")[-4000:],r.stderr.decode("utf-8","replace")[-4000:],flush=True)
(own/"clean-checks.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8",newline="\n")
if any(r["exit_code"] for r in result):raise SystemExit(1)
print("Actual clean committed local checks PASS (Windows symlink skips explicitly retained).")

