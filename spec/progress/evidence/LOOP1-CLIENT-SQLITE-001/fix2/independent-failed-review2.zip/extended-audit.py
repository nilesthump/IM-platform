from pathlib import Path
import subprocess,json,hashlib,zipfile,gzip,sys
p=Path('H:/ica');o=Path('H:/.codex/evidence/s2-sqlite-20261001/review2');e=p/'spec/progress/evidence/LOOP1-CLIENT-SQLITE-001'
m=json.loads((e/'dependency-archive-manifest.json').read_text())
with zipfile.ZipFile(e/'accepted-architecture-dependency.zip') as z:
 assert set(z.namelist())=={i['path'] for i in m}
 for i in m:assert hashlib.sha256(z.read(i['path'])).hexdigest()==i['sha256']
assert (p/'contracts/fixtures/sync-plugin/golden.json').read_bytes()==(p/'clients/mobile/app/src/androidTest/assets/golden.json').read_bytes()
assert (p/'tests/clients/sqlite/v1.sql').read_bytes()==(p/'clients/mobile/app/src/androidTest/assets/v1.sql').read_bytes()
for i in json.loads((e/'fix1/historical-persisted-blob-manifest.json').read_text()):
 b=(e/i['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==i['compressed_sha256'];assert hashlib.sha256(gzip.decompress(b)).hexdigest()==i['persisted_blob_sha256']
assert len(list((p/'spec/tasks').glob('*/LOOP1-CLIENT-SQLITE-001.md')))==1
assert hashlib.sha256((p/'scalable-distributed-im-architecture.pdf').read_bytes()).hexdigest()=='546915f639f30cd294f11390da3ade2ce6a85b620bf55727c2a90ca6017d7510'
assert subprocess.check_output(['git','diff','ee82e9ff459558907998d5e68e7097386e2b7f14','6dc957c1a2f936d55a191e06a8003ff1af218c6f','--','clients/desktop/src-tauri'],cwd=p)==b''
b=Path('H:/.codex/evidence/s2-sqlite-20261001/review/target/debug/storage_probe.exe').read_bytes()
(o/'extended-audit.json').write_text(json.dumps(dict(dependency_members=len(m),historical_gzip_blobs=22,android_golden_byte_identical=True,android_v1_byte_identical=True,pdf_hash_verified=True,current_task_unique=True,native_sources_and_lock_unchanged_from_prior_independent_ee82=True,review2_rebuilt_probe_sha256=hashlib.sha256(b).hexdigest()),indent=2)+'\n')
print('Extended byte identity/authority/native cache correspondence audit PASS')
base=[sys.executable,'-B','tools/research/recorder.py','record-event','--repo','H:/ica','--research-root',str(o/'research'),'--run-id','R-SQLITE-REVIEW2-20261002']
for kind,data in [('instrumentation_warning',{'summary':'Initial required read/help/setup, later passive source/governance/config/history/help/log reads and primary-source browser checks used direct tools; helper creation outside run-command. Trace is prospective_resume incomplete, never complete. Candidate remains read-only. Missing old helper and two rg nonexistent assumed paths were read-only errors, no evidence rewriting.'}),('finding_created',{'priority':'P2','summary':'Canonical Cursor maxLength256 allows256 supplementary codepoints; both TS/Kotlin use UTF16 nextCursor.length. Real independent SQLx reproducer rejects256-codepoint512-unit valid page with Invalid user page, durable cursor0. Current Go decimal is implementation, no contract narrowing. Fresh Fix and fresh Review required.'})]:subprocess.run(base+['--event-type',kind,'--data-json',json.dumps(data)],cwd=p,check=True)
