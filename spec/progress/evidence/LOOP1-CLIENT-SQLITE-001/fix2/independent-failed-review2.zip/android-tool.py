from pathlib import Path
import os,subprocess,sys,json,hashlib,zipfile,gzip
own=Path("H:/.codex/evidence/s2-sqlite-20261001/review2"); repo=Path("H:/isv2-sqlite")
env=os.environ.copy();env.update(JAVA_HOME="H:/.jdks/jdk17",ANDROID_HOME="H:/Android",ANDROID_SDK_ROOT="H:/Android",GRADLE_USER_HOME="H:/gradle",ANDROID_AVD_HOME=str(own/"avd-home"),ANDROID_USER_HOME=str(own/"android-user"))
for key in ("ANDROID_AVD_HOME","ANDROID_USER_HOME"): Path(env[key]).mkdir(exist_ok=True)
kind=sys.argv[1]
if kind=="sdk": raise SystemExit(subprocess.call(["H:/Android/cmdline-tools/latest/bin/sdkmanager.bat","--sdk_root=H:/Android","system-images;android-34;google_apis;x86_64"],env=env))
if kind=="android":
 env["IM_CLIENT_GRADLE"]="H:/gradle/wrapper/dists/gradle-8.9-bin/78qddjpeqn5v6yec3xb8kv9ca/gradle-8.9/bin/gradle.bat";env["IM_CLIENT_ADB"]="H:/Android/platform-tools/adb.exe"
 raise SystemExit(subprocess.call([sys.executable,"-B",str(repo/"tools/verify_client_sqlite.py"),"--scope","mobile","--serial","emulator-5586"],env=env,cwd=repo))
