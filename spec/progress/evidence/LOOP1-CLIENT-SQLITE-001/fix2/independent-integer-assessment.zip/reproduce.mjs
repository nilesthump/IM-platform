import {Repository} from 'file:///H:/isv2-sqlite/clients/shared/protocol-sdk/dist/storage/repository.js';
import {spawnSync} from 'node:child_process'; import {mkdirSync} from 'node:fs';
const root='H:/.codex/evidence/s2-sqlite-20261001/seq-assessment/dummy-db';mkdirSync(root,{recursive:true});
const probe='H:/.codex/evidence/s2-sqlite-20261001/review/target/debug/storage_probe.exe';
const hex=s=>Buffer.from(s,'utf8').toString('hex');const bind=s=>s===null?'~':hex(s);
const call=s=>{const r=spawnSync(probe,[root,'10000000-0000-4000-8000-000000000099'],{input:s,encoding:'utf8'});if(r.status!==0)throw Error(r.stderr);return r.stdout.trimEnd();};
const db={async transaction(ss){call(ss.map(([s,b,e])=>['T',e??'-',hex(s),...b.map(bind)].join('\t')).join('\n')+'\n');},async query(s,b){const o=call(['Q',hex(s),...b.map(bind)].join('\t')+'\n');return o?o.split(/\r?\n/).map(l=>l.split('\t').map(v=>v==='~'?null:Buffer.from(v,'hex').toString('utf8'))):[];}};
const repo=new Repository(db);await repo.initialize();
const c='30000000-0000-4000-8000-000000000099';
const m={conversationId:c,requestId:'40000000-0000-4000-8000-000000000099',senderId:'10000000-0000-4000-8000-000000000099',content:{kind:'TEXT',text:'exact dummy'},messageId:'50000000-0000-4000-8000-000000000099',seq:2**53,createdAt:'2026-10-01T00:00:00Z'};
let syncError;try{await repo.syncMessages([m]);}catch(e){syncError=e.message;}
let revisionError;try{await repo.userPage({syncVersion:'1.0',type:'sync.user.page',requestId:m.requestId,events:[{eventId:m.messageId,cursor:'1',kind:'friend.changed',subjectId:m.senderId,revision:2**53}],nextCursor:'1',hasMore:false},'0');}catch(e){revisionError=e.message;}
await db.transaction([['INSERT INTO conversations(conversation_id,contiguous_seq) VALUES(?,?)',[c,'9007199254740993'],1]]);
const raw=await db.query('SELECT CAST(contiguous_seq AS TEXT) FROM conversations WHERE conversation_id=?',[c]);
const converted=await repo.contiguous(c);
const result={engine:'actual released SQLx SQLite probe; reused artifact',syncInputExactlyRepresentable:String(m.seq),syncError,revisionError,rawContiguous:raw[0][0],repositoryContiguous:String(converted),precisionLost:raw[0][0]!==String(converted)};
console.log(JSON.stringify(result));
if(syncError!=='Invalid sequence'||revisionError!=='Invalid sequence'||!result.precisionLost)throw Error('Finding not reproduced');
console.log(JSON.stringify({signed64Native:await db.query("SELECT CAST(CAST(? AS INTEGER) AS TEXT),typeof(CAST(? AS INTEGER)),typeof(CAST(? AS INTEGER)+1),CAST(CAST(? AS INTEGER)+1 AS TEXT)",Array(4).fill('9223372036854775807'))}));