# Bounded current-storage assessment: CONFIRMED_CURRENT_SCOPE_FINDING
Actor /root/s2_sqlite_seq_assessment is fresh, read-only and did not implement/fix any candidate. This is a local responsibility assessment, not acceptance of Fix2/Review3, Task or S2 Gate.

Immutable assessed HEAD: 6dc957c1a2f936d55a191e06a8003ff1af218c6f, released H:/isv2-sqlite; status empty, Task uniquely review. No candidate/original/source/contracts/evidence-history edits or publishing. All writes confined to this external assessment directory / Recorder and dummy account DB.

Authority:
- Canonical SHA aa2398020beeda5f7f9456aac346da57bd8b75212192123c943c35dfdc80f84c; historical PDF SHA546915f639f30cd294f11390da3ade2ce6a85b620bf55727c2a90ca6017d7510 independently recomputed correctly.
- frozen-architecture.md:451/453/454 TS Repository/models/transaction intents and equivalent Kotlin semantics under canonical contracts; 567-573 true atomic materialized storage; 591 contiguous cannot skip gap; 361-368 conversation sequence identity. No JS-safe numeric cap discovered in canonical/approved ADRs/referenced domain/invariant/acceptance inputs.
- contracts/websocket/sync-v1.schema.json:13 PositiveSeq type integer minimum1 without maximum; :16 user revision, :19 message seq reference it.
- contracts/websocket/envelope.schema.json:62 Committed.seq and :72 realtime.seq integer minimum1 without maximum.
- contracts/database/migrations/0001_initial.up.sql:31 next_seq bigint; :127 durable message seq bigint positive. PostgreSQL bigint is signed64, [-9223372036854775808,9223372036854775807], official https://www.postgresql.org/docs/16/datatype-numeric.html . SQLite INTEGER signed64 exact, official https://www.sqlite.org/datatype3.html and https://www.sqlite.org/floatingpoint.html . This establishes concrete currently legal server sequences beyond JSsafe range, NOT support for arbitrary unbounded schema integers. Revision has no public maximum; this finding proves the same concrete positive signed64 subset is wrongly rejected, without inventing a new revision contract cap.
- Task Acceptance expressly requires existing-history preservation, exact identities, contiguous advancement and equivalent models. Supporting this concrete existing numeric domain is current storage work, not future networking/parser work.

Affected old source:
models.ts:8/13 seq:number, :18 revision:number; repository.ts:8-10 Number.isSafeInteger rejection, :49/:55/:60 materialization, :89 ACK, :110 revision all use seq(); :124-126 contiguous Number(string) loss. Kotlin Long and SQLite INTEGER can represent demonstrated values.

Actual reproduced command (Recorder command timestamps/durations/raw hashes retained):
node H:/.codex/evidence/s2-sqlite-20261001/seq-assessment/reproduce.mjs
Exit0 /0.585s.
- Exact numeric2^53=9007199254740992 sync input -> Invalid sequence.
- Same exact revision -> Invalid sequence.
- Actual SQLx query of owned dummy SQLite INTEGER contiguous gives9007199254740993; Repository getter gives9007199254740992: precisionLost=true.
- Native signed64 MAX returned9223372036854775807/type integer; MAX+1 arithmetic returned real9.22337203685478e+18. Thus prefix successor must stop at MAX, not allow arithmetic overflow.
The large contiguous row was seeded through real generic transaction adapter to model retained history; it does not pretend to create all lower messages or prove a future network decoder.
No actual post-fix2 tests performed. Additional minimal present tests should cover exact2^53+1 write/reopen, seeded prefix2^53→+1 gap closure, same seq representation through ACK/realtime/Sync/revision, MAX exact storage/getter and stop-at-MAX, out-of-storage-range input rejection with no materialized/cursor changes.

Artifact correspondence / limits:
Used real storage_probe.exe at H:/.codex/evidence/s2-sqlite-20261001/review/target/debug/storage_probe.exe, SHA at observation[full SHA retained in Recorder output]. Reuse, NOT new independent compilation. review2/build-tool.py explicitly builds H:/isv2-sqlite with this target. Released review2 command-ledger entry C-fb0acb7a-aaec-4aad-b4c8-d7c58ce6cc4f desktop exit0 duration52188ms. Native source/Cargo.lock/Cargo.toml ee82..6dc diff empty; exact file hashes recorded. dist/storage/repository.js same offending safe-integer check inspected. Shared target may later be used by Fix2; no claim of exclusive immutable artifact ownership or independent artifact build in this assessment. Actual native transaction/query path, no mock/Python SQLite replacement.

Minimal proposed correction:
Use built-in bigint (or explicitly exact decimal string) at local TS sequence/revision model and getter boundary, retain string SQLx binds and existing Rust generic adapter. Preserve supported safe-number callers only if necessary without silently accepting already-rounded unsafe numbers; exact bigint/string path handles2^53+1. Validate physical positive signed64 storage range without reverse-authoring a public wire maximum. Stop SQL prefix successor at signed64MAX in both implementations. Do not merely replace isSafeInteger with isInteger, change wire schemas, add a serialization/network library or implement network fetching/parser. Current task allowed storage paths are sufficient; no Frozen expansion or invented JS-safe contract cap warranted.

Observed verification limitations retained:
System child powershell lacked Get-FileHash, recorded minimal baseline exit1; Python hashes correct.
First bulk command Recorder output encoding failed GBK exit1, repaired by explicit PYTHONIOENCODING=utf-8, output faithfully retained.
Actual bundled pwsh Acceptance baseline exit1: current_active_clients sees1150 ignored node_modules/build artifacts in build-bearing old checkout. No deletion/guard changes/PASS rewrite. This assessment is not full clean-source Review3; root's fresh Review3 must independently validate actual final candidate.
Initial mandatory reads / setup help before Recorder explicitly prospective_resume incomplete. Web primary-source lookup outside command recorder is disclosed here. Research validation is not product acceptance.
Historical Groovy FAIL/WAIVED_BY_HUMAN remains unrelated and unchanged.
Human stop scope preserved: SQLite PR/merge/safe original sync/progress then STOP, no SEND/SYNC/WEB activation.
