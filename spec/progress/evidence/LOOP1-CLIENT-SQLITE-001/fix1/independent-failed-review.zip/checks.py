import subprocess,sys,time,json
from pathlib import Path
r=Path("H:/isv-sqlite");o=Path("H:/.codex/evidence/s2-sqlite-20261001/review");py=sys.executable
cmds=[["pwsh","-NoProfile","-File","tools/verify-frozen-architecture.ps1"],[py,"-B","ci/check_architecture.py","--scope","all","--json"],[py,"-B","-m","unittest","discover","-s","tests/architecture","-v"],[py,"-B","-m","unittest","discover","-s","tests/ci","-v"],[py,"-B","contracts/websocket/verify.py"],[py,"-B","contracts/plugin-api/verify.py"]]
results=[]
for i,cmd in enumerate(cmds):
 t=time.monotonic();v=subprocess.run(cmd,cwd=r,capture_output=True);elapsed=time.monotonic()-t;(o/f"check-{i}.stdout").write_bytes(v.stdout);(o/f"check-{i}.stderr").write_bytes(v.stderr);entry=dict(argv=cmd,exit=v.returncode,elapsed_s=elapsed,stdout=f"check-{i}.stdout",stderr=f"check-{i}.stderr");results.append(entry);print(json.dumps(entry),flush=True);print(v.stdout.decode("utf-8","replace")[-500:] if i!=1 else "source output saved",flush=True);print(v.stderr.decode("utf-8","replace")[-500:],flush=True)
(o/"checks.json").write_text(json.dumps(results,indent=2),encoding="utf-8")
raise SystemExit(any(x["exit"] for x in results))
