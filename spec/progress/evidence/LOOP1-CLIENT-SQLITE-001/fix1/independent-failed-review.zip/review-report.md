# Independent SQLite Review — FAIL

Reviewer: fresh /root/s2_sqlite_review; neither implemented nor fixed this candidate. No repository source, task, queue or original H:/IM-platform file was modified.
Candidate: ee82e9ff459558907998d5e68e7097386e2b7f14.
Full range: a28752967ddd471cd281aece7ea9b343521356e8..ee82e9ff459558907998d5e68e7097386e2b7f14.
Branch: task/LOOP1-CLIENT-SQLITE-001-ts-kotlin.
Independent clean detached checkout: H:/isv-sqlite; fresh absence checked before creation, Acceptance status_entries=0/diff_lines=0. Final source status/diff also clean.

## Findings requiring a new Fix Agent and new Review

1. P1 — Declared Android minimum cannot execute the SQLite statements.
clients/mobile/app/build.gradle.kts:11 declares minSdk=26. Repository.kt:50 uses targeted UPSERT requiring SQLite3.24; Repository.kt:81 uses targetless ON CONFLICT DO UPDATE requiring3.35. Android API26 ships3.18, API30 ships3.28, API31..33 ship3.32, API34 ships3.39/3.42. API26 localSend fails syntax; even raising to30 does not support materialize. Current API37 runtime/hosted API35 cannot establish minimum26 compatibility. Resolve all actual SQL requirements with the simplest approved SDK implementation or honestly bind declared minimum to the actual supported/tested environment; do not add a SQLite library or change public protocol compatibility. Verify real minimum environment including migration, all entrypoints and atomicity.
Primary sources: https://developer.android.com/reference/android/database/sqlite/package-summary and https://www.sqlite.org/lang_upsert.html .

2. P2 — Both implementations reject legal supplementary-plane text.
clients/shared/protocol-sdk/src/storage/repository.ts:5 and clients/mobile/app/src/main/kotlin/im/platform/client/storage/Repository.kt:35 compare UTF16 String.length to4096. Canonical envelope/schema TextContent and Sync Message specify JSON Schema maxLength4096 characters. 4096 U+1F600 characters have8192 UTF16 units and are valid contract text. Independently built real SQLx database reproduced Invalid text/durableRows0 in review/unicode.mjs; Kotlin uses the same incorrect count (source observation, no extra Android Unicode probe claimed). Count Unicode codepoints consistently and add actual two-platform4096/4097 boundary coverage without changing contracts.
Primary semantics: https://json-schema.org/draft/2020-12/json-schema-validation#section-6.3.1 .

## Independent checks

- Clean Recovery Acceptance PASS23 Task specs, unique current review, status0/diff0.
- Frozen canonical aa2398020beeda5f7f9456aac346da57bd8b75212192123c943c35dfdc80f84c and PDF546915f639f30cd294f11390da3ade2ce6a85b620bf55727c2a90ca6017d7510 match; frozen integrity/53 controls PASS.
- All-source architecture guard zero violations; architecture53 tests PASS.
- CI31 tests PASS with4 Windows symlink privilege skips. These require actual selected Linux hosted checks, not local all-tests-executed claim.
- WSS8positive/10negative/18schema/26behavior mutations PASS; Sync/Plugin79 outcome artifacts/16 mutation controls PASS.
- Actual Desktop: own initially empty review/target, single CARGO_BUILD_JOBS=1; npm ci/build both packages; Rust1.99/MSVC/Tauri/SQLx locked cargo test one real native adapter test, zero ignored; cargo build storage_probe; canonical13cases/98assertions PASS. No implementation target reused.
- Actual Android: separate fresh IMStorageReview AVD, API37.0 Google Play 16KB image revision4, memory2048MB; fresh independent candidate Gradle8.9/JDK17 build62 tasks executed SUCCESS27s; official wrapper was not independently used, fallback executable explicitly recorded. APK installs SUCCESS.
- Android first execution FAIL code14 SQLiteCantOpenDatabaseException: directory /data/user/0/im.platform.client/databases absent, database im-5f62ff84-8fbe-4d99-9ba8-798fb4f56025.sqlite, 2026-10-01T17:39:00 emulator log. First boot sys.boot_completed had been1; CE state at failure unavailable.
- After explicit boot_completed1/CE=true, SAME unchanged APK real instrumentation13cases/97assertions PASS/INSTRUMENTATION_CODE -1.
- Further fresh-data diagnostic pm clear on ONLY owned task app failed with Android system NotificationManager NullPointerException and subsequent INSTRUMENTATION_ABORTED System has crashed. API37 SystemUI earlier also DEAD_OBJECT. This is an observed environment reliability/first-run acceptance limitation, not an established persistent product defect. Do not discard first FAIL or promote retry PASS to clean first-run acceptance. New Fix/Review should verify stable actual minimum API fresh install/clear and explicit environment readiness. No further API37 retry loop.
- Initial owned5590 AVD was offline with recommended-port warning; strictly verified own process IDs14312/11944 stopped; fresh5582 booted. At exit own5582 parent50952 and verified QEMU child stopped. No user/implementation AVD or sharedADB server stopped. AVD/tool outputs retained outside public evidence archive.

## Scope, authority, ownership and minimality

Actual TS Repository/models/schema/migration/intents remain shared TypeScript; Tauri invoke carries generic SQL statements/bindings/row assertions. Rust generic SQLx connection/query/transaction begins once and explicitly commits or rolls back; no client Repository/schema business authority or independent execute pseudo-transactions. Product query connection physically read-only. Kotlin has actual SDK transactions and equivalent fixtures. Identity/content guards precede merge; ACK/realtime/Sync preserve durable identity and terminal SENT. Gap prefix advance, low-frequency cursor isolation, crossed input convergence, uniqueness, migration failure rollback, account/reopen and fault rollback exercised. No network orchestration/Web/plugin/Java scope added.
All changed paths match Task allowed_paths.6032 baseline tracked objects unchanged, including existing contracts/frozen/old evidence.191 dependency zip members match manifest hashes; canonical golden and independent v1.sql Android copies byte-identical. This audit does not independently rescan original744unknown files; Coordinator owns their preservation audit. Necessary two32px icons correspond actual tauri-build2.7.1 Windows fallback and tauri-codegen2.7.1 Linux CachedIcon requirements; exact paths clarified before writes. No architecture expansion. No direct sensitive dependencies beyond accepted canonical6.1/ADR0005 stack. Bounded native test transport and minimal Compose host serve present acceptance, no speculative ORM/strategy layer.
CI actual Desktop/Mobile/shared commands replace applicable skeleton checks; Java/Web skeleton retained, full/deleted source/tool/test classifier selection retained. Hosted candidate CI has not run; CI_ACCEPTANCE_PENDING. Task remains review and S2 Gate OPEN.
Historical executable Groovy GString original FAIL and WAIVED_BY_HUMAN unchanged; not reopened or relabeled PASS.

## Evidence hash clarification

All22 committed gzip files decompress exactly to original immutable persisted Recorder blobs. The local-command-history stdout/stderr hashes describe captured subprocess bytes; Recorder decodes with UTF8 replacement/redaction before persisting blobs. C-790638b6-f9e9-42ae-81e6-5273a8292b19.stderr and C-f29009bd-da24-409d-b2d5-a13e63b1a61a.stdout differ from captured subprocess hashes. audit.json contains both hashes and byte equivalence. Add a separate blob manifest/clarification; preserve existing event streams/history hashes, never rewrite to fake agreement. No private ADB keys/AVD user directories occur in dependency archive.

## Instrumentation and next action

Exact full7080byte assignment registered P-SQLITE-REVIEW-20261002 SHA771152154c3322a2a0f835058d5f114f498485bbef11012a71db4f39d9d60eed; R-SQLITE-REVIEW-20261002 prospective_resume, preRecorder trace incomplete. Initial reads/web checks, external helper setup/direct audit/diagnostics outside run-command are disclosed. Invalid warning event type rejection and incorrect initial raw-byte-vs-blob assertion are disclosed, then corrected; no streams rewritten. checks.json plus command-ledger.json contain real command/exit/duration; raw output retained in Recorder blobs. pm-clear multi-command diagnostic exit0 does NOT mean Android PASS; output abort explicitly FAIL.
Release: reviewer releases all repository write capability (never used), no ongoing build/emulator process. Coordinator delegates NEW Fix then NEW independent Review and applicable exactHEAD hosted CI. Latest Human boundary: close SQLite only, create/merge authorized PR, safely sync original preserving unknown work, record progress and stop before SEND/SYNC/WEB.
