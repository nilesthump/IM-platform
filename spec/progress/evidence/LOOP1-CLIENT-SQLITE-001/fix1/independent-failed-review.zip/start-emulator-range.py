from pathlib import Path
import os,subprocess,time,socket,sys
owned=Path("H:/.codex/evidence/s2-sqlite-20261001/review")
env=os.environ.copy(); env["JAVA_HOME"]="H:/.jdks/jdk17"; env["ANDROID_HOME"]="H:/Android"; env["ANDROID_SDK_ROOT"]="H:/Android"
env["ANDROID_AVD_HOME"]=str(owned/"avd-home"); env["ANDROID_USER_HOME"]=str(owned/"android-user")
Path(env["ANDROID_AVD_HOME"]).mkdir(exist_ok=True); Path(env["ANDROID_USER_HOME"]).mkdir(exist_ok=True)
name="IMStorageReview"; avd=owned/"avd-home"/(name+".avd")
if not avd.exists():
 tool="H:/Android/cmdline-tools/latest/bin/avdmanager.bat"
 result=subprocess.run([tool,"create","avd","-n",name,"-k","system-images;android-37.0;google_apis_playstore_ps16k;x86_64","-p",str(avd)],input="no\n",text=True,env=env)
 if result.returncode: raise SystemExit(result.returncode)
for port in (5582,5583):
 s=socket.socket()
 try: s.bind(("127.0.0.1",port))
 except OSError: raise SystemExit("Reserved task emulator port occupied; no existing emulator touched")
 finally: s.close()
log=(owned/"emulator-range-retry.log").open("w",encoding="utf-8")
process=subprocess.Popen(["H:/Android/emulator/emulator.exe","-avd",name,"-port","5582","-no-window","-memory","2048","-wipe-data","-no-audio","-no-boot-anim","-no-snapshot","-gpu","swiftshader_indirect"],env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
(owned/"emulator-pid.txt").write_text(str(process.pid))
adb="H:/Android/platform-tools/adb.exe"; serial="emulator-5582"
print("Started only isolated hidden task emulator with 2048MB RAM",serial,"pid",process.pid,flush=True)
for i in range(120):
 if process.poll() is not None: raise SystemExit("Task emulator exited; inspect owned emulator.log")
 result=subprocess.run([adb,"-s",serial,"shell","getprop","sys.boot_completed"],capture_output=True,text=True,timeout=10,env=env)
 if result.returncode==0 and result.stdout.strip()=="1":
  print("PASS: actual isolated Android emulator booted",serial,flush=True); raise SystemExit(0)
 time.sleep(3)
raise SystemExit("Android emulator boot timed out; real runtime remains unaccepted")
