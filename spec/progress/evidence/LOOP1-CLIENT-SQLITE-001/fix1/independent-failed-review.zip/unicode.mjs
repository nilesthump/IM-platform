import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { readFileSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { Repository } from "file:///H:/isv-sqlite/clients/shared/protocol-sdk/dist/storage/repository.js";
import { v1, v2 } from "file:///H:/isv-sqlite/clients/shared/protocol-sdk/dist/storage/schema.js";
const probe=resolve(process.argv[2]);
const root=mkdtempSync(join(tmpdir(),"im-desktop-storage-"));
const account="10000000-0000-4000-8000-000000000001";
const other="10000000-0000-4000-8000-000000000002";
const c="30000000-0000-4000-8000-000000000001";
const c2="30000000-0000-4000-8000-000000000002";
const r="40000000-0000-4000-8000-000000000001";
const id="50000000-0000-4000-8000-000000000001";
const hex=s=>Buffer.from(s,"utf8").toString("hex");
const bind=s=>s===null?"~":hex(s);
let assertions=0;
function equal(actual,expected) { assert.deepEqual(actual,expected); assertions++; }
function database(accountId) {
  function call(input) {
    const result=spawnSync(probe,[root,accountId],{input,encoding:"utf8",maxBuffer:8*1024*1024});
    if(result.error) throw result.error;
    if(result.status!==0) throw new Error(result.stderr.trim()||"Native adapter failed");
    return result.stdout;
  }
  return {
    async transaction(steps) { call(steps.map(([sql,args,changes])=>["T",changes??"-",hex(sql),...args.map(bind)].join("\t")).join("\n")+"\n"); },
    async query(sql,args) {
      const output=call(["Q",hex(sql),...args.map(bind)].join("\t")+"\n").trimEnd();
      return output?output.split(/\r?\n/).map(line=>line.split("\t").map(v=>v==="~"?null:Buffer.from(v,"hex").toString("utf8"))):[];
    },
  };
}

const repo=new Repository(database(account));await repo.initialize();const text=String.fromCodePoint(0x1f600).repeat(4096);const m={conversationId:c,requestId:r,senderId:account,content:{kind:"TEXT",text}};let result;try{await repo.localSend(m);result="ACCEPTED"}catch(e){result=e.message};console.log(JSON.stringify({codepoints:[...text].length,utf16Units:text.length,result,durableRows:(await repo.messages(c)).length,engine:"independently built actual SQLx"}));
