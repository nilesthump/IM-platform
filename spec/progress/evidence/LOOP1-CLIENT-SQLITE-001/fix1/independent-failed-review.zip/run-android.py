from pathlib import Path
import os,subprocess,sys
owned=Path("H:/.codex/evidence/s2-sqlite-20261001/review")
env=os.environ.copy(); env["ANDROID_USER_HOME"]=str(owned/"android-user"); env["ANDROID_AVD_HOME"]=str(owned/"avd-home")
adb="H:/Android/platform-tools/adb.exe"
result=subprocess.run([adb,"-s","emulator-5582","shell","getprop","sys.boot_completed"],env=env,capture_output=True,text=True,timeout=30)
print("Explicit isolated adb exit",result.returncode,"boot",result.stdout.strip(),flush=True)
if result.stderr: print(result.stderr)
if result.returncode or result.stdout.strip()!="1": raise SystemExit(1)
env["JAVA_HOME"]="H:/.jdks/jdk17"; env["ANDROID_HOME"]="H:/Android"; env["ANDROID_SDK_ROOT"]="H:/Android"; env["GRADLE_USER_HOME"]="H:/gradle"; env["IM_CLIENT_ADB"]=adb
env["IM_CLIENT_GRADLE"]="H:/gradle/wrapper/dists/gradle-8.9-bin/78qddjpeqn5v6yec3xb8kv9ca/gradle-8.9/bin/gradle.bat"
raise SystemExit(subprocess.call([sys.executable,"-B","H:/isv-sqlite/tools/verify_client_sqlite.py","--scope","mobile","--serial","emulator-5582"],env=env))
