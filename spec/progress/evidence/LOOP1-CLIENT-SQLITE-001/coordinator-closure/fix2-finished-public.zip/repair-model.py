from pathlib import Path
p=Path('H:/ica/clients/shared/protocol-sdk/src/storage/models.ts');s=p.read_text(encoding='utf-8');chunk='// Safe numeric inputs remain convenient; larger SQLite integers use exact bigint.\nexport type Sequence = number | bigint;\n';assert s.count(chunk)==2;i=s.rindex(chunk);s=s[:i]+s[i:].replace(chunk,'',1);p.write_text(s,encoding='utf-8',newline='\n')
