$taskEmulatorPid = [int](Get-Content -LiteralPath 'H:/.codex/evidence/s2-sqlite-20261001/fix2/emulator-pid.txt')
$taskEmulatorProcess = Get-CimInstance Win32_Process -Filter ('ProcessId=' + $taskEmulatorPid)
if (-not $taskEmulatorProcess -or $taskEmulatorProcess.CommandLine -notmatch 'IMStorageFix2Minimum34') { throw 'Ownership not proven; no process touched' }
$taskEmulatorProcess | Select-Object ProcessId,Name,CommandLine
& 'H:/Android/platform-tools/adb.exe' -s emulator-5588 emu kill
if ($LASTEXITCODE -ne 0) { throw 'Owned emulator did not acknowledge stop' }

