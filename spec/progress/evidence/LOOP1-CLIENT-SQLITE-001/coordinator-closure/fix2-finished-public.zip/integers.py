from pathlib import Path
r=Path('H:/ica')
p=r/'clients/shared/protocol-sdk/src/storage/models.ts';s=p.read_text(encoding='utf-8');s=s.replace('export type State', '// Safe numeric inputs remain convenient; larger SQLite integers use exact bigint.\nexport type Sequence = number | bigint;\nexport type State').replace('seq: number;', 'seq: Sequence;').replace('revision: number;', 'revision: Sequence;');p.write_text(s,encoding='utf-8',newline='\n')
p=r/'clients/shared/protocol-sdk/src/storage/repository.ts';s=p.read_text(encoding='utf-8').replace('ServerMessage, Statement, UserPage','ServerMessage, Sequence, Statement, UserPage');s=s.replace('function seq(n: number): string {\n  if (!Number.isSafeInteger(n) || n < 1) throw new Error("Invalid sequence");\n  return String(n);\n}', '''function seq(n: Sequence): string {
  // Numbers outside the safe range may already have rounded before this call.
  if (typeof n === "number" && !Number.isSafeInteger(n)) throw new Error("Use bigint for exact sequence");
  const value = BigInt(n);
  if (value < 1n || value > 9223372036854775807n) throw new Error("Sequence outside SQLite integer storage");
  return value.toString();
}''');s=s.replace('UNION ALL SELECT n+1 FROM prefix WHERE EXISTS(', 'UNION ALL SELECT n+1 FROM prefix WHERE n<9223372036854775807 AND EXISTS(').replace('Promise<number> {\n    const rows', 'Promise<bigint> {\n    const rows').replace('return Number(rows[0]?.[0] ?? 0);', 'return BigInt(rows[0]?.[0] ?? "0");');p.write_text(s,encoding='utf-8',newline='\n')
p=r/'clients/mobile/app/src/main/kotlin/im/platform/client/storage/Repository.kt';s=p.read_text(encoding='utf-8').replace('UNION ALL SELECT n+1 FROM prefix WHERE EXISTS(', 'UNION ALL SELECT n+1 FROM prefix WHERE n<9223372036854775807 AND EXISTS(');p.write_text(s,encoding='utf-8',newline='\n')
p=r/'tests/clients/sqlite/desktop.mjs';s=p.read_text(encoding='utf-8');s=s.replace('equal(await repo.contiguous(conversation),expected.contiguous)', 'equal(await repo.contiguous(conversation),BigInt(expected.contiguous))').replace('??c),test.expect.contiguous)', '??c),BigInt(test.expect.contiguous))');import re;s=re.sub(r'(equal\(await \w+\.contiguous\(\w+\),)([12])(\))',r'\g<1>\2n\3',s)
i=s.index('console.log(JSON.stringify({result:');s=s[:i]+'''const largeAccount="10000000-0000-4000-8000-000000000004";
const large=new Repository(database(largeAccount)); await large.initialize();
const boundary=9007199254740992n, max=9223372036854775807n;
// Imported historical gap-free prefix; do not allocate quadrillions of fixture rows.
await large.db.transaction([["INSERT INTO conversations VALUES(?,?)",[c,(boundary-1n).toString()],1],["INSERT INTO conversations VALUES(?,?)",[c2,(max-1n).toString()],1]]);
const high={...server,seq:boundary}, odd={...next,seq:boundary+1n};
await large.localSend(local); await large.syncMessages([odd]); equal(await large.contiguous(c),boundary-1n);
await large.committedAck(r,{status:"committed",...high}); equal(await large.contiguous(c),boundary+1n);
await large.realtime({...realtime,seq:boundary}); await large.syncMessages([high,odd]);
equal((await large.messages(c)).map(row=>row[5]),[boundary.toString(),(boundary+1n).toString()]);
const top={...crossed,seq:max}; await large.syncMessages([top,top]); equal(await large.contiguous(c2),max);
const largePage={...page,nextCursor:"large",events:[{...page.events[0],revision:max}]};
await large.userPage(largePage,"0");
await large.userPage({...largePage,nextCursor:"large2",events:[{...largePage.events[0],revision:max-1n}]},"large");
const state64=await large.db.query("SELECT CAST(revision AS TEXT) FROM user_state",[]); equal(state64,[[max.toString()]]);
const messages64=await large.messages(c), top64=await large.messages(c2);
for(const invalid of [0n,-1n,max+1n,Number(boundary)]) {
  await assert.rejects(large.syncMessages([{...odd,seq:invalid}])); assertions++;
  await assert.rejects(large.userPage({...largePage,nextCursor:"invalid",events:[{...largePage.events[0],revision:invalid}]},"large2")); assertions++;
}
equal(await large.messages(c),messages64); equal(await large.messages(c2),top64); equal(await large.cursor(),"large2");
equal(await large.db.query("SELECT CAST(revision AS TEXT) FROM user_state",[]),state64);
const largeRestart=new Repository(database(largeAccount)); await largeRestart.initialize();
equal(await largeRestart.contiguous(c),boundary+1n); equal(await largeRestart.contiguous(c2),max);
equal(await largeRestart.messages(c),messages64); equal(await largeRestart.messages(c2),top64);
equal(await largeRestart.db.query("SELECT CAST(revision AS TEXT) FROM user_state",[]),state64); equal(await largeRestart.cursor(),"large2");
'''+s[i:];p.write_text(s,encoding='utf-8',newline='\n')
p=r/'clients/mobile/app/src/androidTest/kotlin/im/platform/client/storage/StorageInstrumentation.kt';s=p.read_text(encoding='utf-8');i=s.index('    override fun onCreate');s=s[:i]+'''    private fun largeIntegers() {
        val account=UUID.randomUUID().toString()
        val c="30000000-0000-4000-8000-000000000001"; val c2="30000000-0000-4000-8000-000000000002"
        val r="40000000-0000-4000-8000-000000000001"; val id="50000000-0000-4000-8000-000000000001"
        val boundary=9007199254740992L; val max=Long.MAX_VALUE
        Repository(targetContext,account).use { it.initialize() }
        // Imported gap-free historical prefix, no enormous artificial row allocation.
        SQLiteDatabase.openDatabase(targetContext.getDatabasePath("im-$account.sqlite").path,null,SQLiteDatabase.OPEN_READWRITE).use { db ->
            db.beginTransaction()
            try {
                db.execSQL("INSERT INTO conversations VALUES(?,?)",arrayOf(c,boundary-1))
                db.execSQL("INSERT INTO conversations VALUES(?,?)",arrayOf(c2,max-1))
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        }
        var messages: List<List<String?>> = emptyList(); var top: List<List<String?>> = emptyList()
        val revision=listOf(listOf(max.toString()))
        Repository(targetContext,account).use { repo ->
            val high=ServerMessage(c,r,account,"durable",id,boundary,"2026-09-28T00:00:01Z")
            val odd=high.copy(requestId="40000000-0000-4000-8000-000000000002",messageId="50000000-0000-4000-8000-000000000002",seq=boundary+1)
            repo.localSend(LocalMessage(c,r,account,"durable")); repo.syncMessages(listOf(odd)); equal(repo.contiguous(c),boundary-1)
            repo.committedAck(r,Committed(c,id,boundary,high.createdAt)); equal(repo.contiguous(c),boundary+1)
            repo.realtime(high.copy(requestId=null)); repo.syncMessages(listOf(high,odd))
            equal(repo.messages(c).map { it[5] },listOf(boundary.toString(),(boundary+1).toString()))
            val highest=high.copy(conversationId=c2,messageId="50000000-0000-4000-8000-000000000003",seq=max)
            repo.syncMessages(listOf(highest,highest)); equal(repo.contiguous(c2),max)
            val event=UserEvent("friend.changed",account,max)
            repo.userPage(listOf(event),"large","0"); repo.userPage(listOf(event.copy(revision=max-1)),"large2","large")
            equal(repo.query("SELECT CAST(revision AS TEXT) FROM user_state"),revision)
            messages=repo.messages(c); top=repo.messages(c2)
            // Kotlin Long cannot express MAX+1; no fabricated beyond-Long input test.
            for(invalid in listOf(0L,-1L,Long.MIN_VALUE)) {
                reject { repo.syncMessages(listOf(odd.copy(seq=invalid))) }
                reject { repo.userPage(listOf(event.copy(revision=invalid)),"invalid","large2") }
            }
            equal(repo.messages(c),messages); equal(repo.messages(c2),top); equal(repo.cursor(),"large2")
            equal(repo.query("SELECT CAST(revision AS TEXT) FROM user_state"),revision)
        }
        Repository(targetContext,account).use { repo ->
            repo.initialize(); equal(repo.contiguous(c),boundary+1); equal(repo.contiguous(c2),max)
            equal(repo.messages(c),messages); equal(repo.messages(c2),top); equal(repo.cursor(),"large2")
            equal(repo.query("SELECT CAST(revision AS TEXT) FROM user_state"),revision)
        }
        targetContext.deleteDatabase("im-$account.sqlite")
    }
'''+s[i:];s=s.replace('fixtures(); additional(); unicode()', 'fixtures(); additional(); unicode(); largeIntegers()');p.write_text(s,encoding='utf-8',newline='\n')
p=r/'clients/shared/protocol-sdk/README.md';s=p.read_text(encoding='utf-8');s+='\nSequence/revision inputs use safe `number` or exact built-in `bigint`; larger integers require `bigint` to avoid already-rounded JS values. SQLite adapter binds decimal strings and `contiguous()` returns `bigint`. Current signed64 SQLite capacity is checked locally; this does not add a public protocol maximum or implement a wire parser. Native Rust receives only string parameters, no BigInt serialization change.\n';p.write_text(s,encoding='utf-8',newline='\n')
print('Minimal exact current signed64 storage model/bind/getter, max-prefix guard, and both real runtime fixtures updated')
