from pathlib import Path
import hashlib,json
own=Path('H:/.codex/evidence/s2-sqlite-20261001/fix2')
(own/'release.md').write_text('''Fresh Fix2 released all H:/ica write/build capability. Exact final9a86d3b641ca60b526c65abcc7a9aeee0b48d082 clean0; source matches locally verified6e62a30087ab316b784daf50dbde10eb4a0b4a03. Final clean RecoveryAcceptance23/status0 PASS7.051s. Newsourceclean controls PASS, actualSQLx13/141/nativeunit1; actual minimumAndroid34 SQLite3.39.2 firstinstall/pmclear13/137eachPASS. Ownemulator5588 PID42088 andprevious49080 ownershipproved/stopped; no active owned builds. Never pushed/createdPR/touched H:/IM-platform. Taskreview/S1PASS/S2OPEN. NextNEWfreshReview3+applicableexactHEADhosted; Coordinator handles authorizedPRmerge/safeoriginalsync/progress/STOP before next implementation.

Recorder R-SQLITE-FIX2-20261002 finishedPASS94events/validated, manifest7ca39db8f1b2d8239afbf9bffb6917101694dc1e2c1f7d89ac13beb4e1d778d6. Structural RecorderPASS/localFixPASS not TaskPASS. Initial/later uncovered passive startup/read/helper/browser facts incomplete prospective_resume disclosed. Repository completed-command history is a snapshot before evidence export/finalcommits; full finishedexternalstream retains those operations including final unsupportedverifierparameterFAIL/supportedsuccess. Public release/manifest export afterfinish outsideRecorder, explicitpostfinishexportonly; finishedstream untouched. Publicmanifest excludes privateAVD/ADB/userdata/logcache artifacts.
''',encoding='utf-8',newline='\n')
rows=[]
for p in sorted(own.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(own)
 if rel.parts[0]=='research' or (len(rel.parts)==1 and (p.suffix in ['.py','.ps1'] or p.name in ['assignment.txt','release.md','clean-checks.json','integer-clean-checks.json'])):
  data=p.read_bytes();rows.append(dict(path=rel.as_posix(),size=len(data),sha256=hashlib.sha256(data).hexdigest()))
p=own/'public-byte-manifest.json';p.write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(dict(public_files=len(rows),manifest_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),candidate='9a86d3b641ca60b526c65abcc7a9aeee0b48d082',writer_released=True)))
