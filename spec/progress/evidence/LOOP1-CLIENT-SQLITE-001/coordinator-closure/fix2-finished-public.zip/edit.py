from pathlib import Path
import os,subprocess,sys,json,hashlib,zipfile
own=Path('H:/.codex/evidence/s2-sqlite-20261001/fix2');r=Path('H:/ica');base=own.parent
p=r/'clients/shared/protocol-sdk/src/storage/repository.ts';s=p.read_text();assert s.count('page.nextCursor.length > 256')==1;p.write_text(s.replace('page.nextCursor.length > 256','[...page.nextCursor].length > 256'),encoding='utf-8',newline='\n')
p=r/'clients/mobile/app/src/main/kotlin/im/platform/client/storage/Repository.kt';s=p.read_text();assert s.count('nextCursor.length<=256')==1;p.write_text(s.replace('nextCursor.length<=256','nextCursor.codePointCount(0, nextCursor.length)<=256'),encoding='utf-8',newline='\n')
p=r/'.github/workflows/ci.yml';s=p.read_text();assert s.count('      - uses: android-actions/setup-android@v3\n')==1;p.write_text(s.replace('      - uses: android-actions/setup-android@v3\n','      - uses: android-actions/setup-android@v3\n        with:\n          packages: platform-tools\n'),encoding='utf-8',newline='\n')
p=r/'tests/clients/sqlite/desktop.mjs';s=p.read_text();needle='console.log(JSON.stringify({result:';i=s.index(needle);s=s[:i]+'''const cursor256="\\u{1f600}".repeat(256);
const page={syncVersion:"1.0",type:"sync.user.page",events:[{kind:"friend.changed",subjectId:other,revision:1}],nextCursor:cursor256,hasMore:false};
await unicode.userPage(page,"0");
equal(await unicode.cursor(),cursor256);
const userState=await unicode.db.query("SELECT kind,subject_id,CAST(revision AS TEXT) FROM user_state",[]);
equal(userState,[["friend.changed",other,"1"]]);
await assert.rejects(unicode.userPage({...page,nextCursor:cursor256+"\\u{1f600}",events:[{...page.events[0],revision:2}]},cursor256)); assertions++;
await assert.rejects(unicode.userPage({...page,nextCursor:"stale",events:[{...page.events[0],revision:2}]},"0")); assertions++;
equal(await unicode.cursor(),cursor256);
equal(await unicode.db.query("SELECT kind,subject_id,CAST(revision AS TEXT) FROM user_state",[]),userState);
equal(await unicode.messages(c),durableUnicode); equal(await unicode.contiguous(c),1);
const cursorRestart=new Repository(database("10000000-0000-4000-8000-000000000003")); await cursorRestart.initialize();
equal(await cursorRestart.cursor(),cursor256);
equal(await cursorRestart.db.query("SELECT kind,subject_id,CAST(revision AS TEXT) FROM user_state",[]),userState);
equal(await cursorRestart.messages(c),durableUnicode); equal(await cursorRestart.contiguous(c),1);
'''+s[i:];p.write_text(s,encoding='utf-8',newline='\n')
p=r/'clients/mobile/app/src/androidTest/kotlin/im/platform/client/storage/StorageInstrumentation.kt';s=p.read_text();s=s.replace('var durable: List<List<String?>> = emptyList()','var durable: List<List<String?>> = emptyList()\n        val cursor256="\\uD83D\\uDE00".repeat(256)\n        val events=listOf(UserEvent("friend.changed",account,1))\n        var userState: List<List<String?>> = emptyList()');s=s.replace('equal(repo.messages(c),durable); equal(repo.contiguous(c),1L); equal(repo.cursor(),"0")','''equal(repo.messages(c),durable); equal(repo.contiguous(c),1L); equal(repo.cursor(),"0")
            repo.userPage(events,cursor256,"0"); equal(repo.cursor(),cursor256)
            userState=repo.query("SELECT kind,subject_id,CAST(revision AS TEXT) FROM user_state")
            equal(userState,listOf(listOf("friend.changed",account,"1")))
            reject { repo.userPage(listOf(events[0].copy(revision=2)),cursor256+"\\uD83D\\uDE00",cursor256) }
            reject { repo.userPage(listOf(events[0].copy(revision=2)),"stale","0") }
            equal(repo.cursor(),cursor256); equal(repo.query("SELECT kind,subject_id,CAST(revision AS TEXT) FROM user_state"),userState)
            equal(repo.messages(c),durable); equal(repo.contiguous(c),1L)''');s=s.replace('repo.initialize(); equal(repo.messages(c),durable) }','''repo.initialize(); equal(repo.messages(c),durable)
            equal(repo.cursor(),cursor256); equal(repo.query("SELECT kind,subject_id,CAST(revision AS TEXT) FROM user_state"),userState)
            equal(repo.contiguous(c),1L)
        }''');p.write_text(s,encoding='utf-8',newline='\n')
# Helpers only in owned external location, no product-native change.
s=(base/'review2/build-tool.py').read_text().replace('H:/isv2-sqlite','H:/ica').replace('s2-sqlite-20261001/review2','s2-sqlite-20261001/fix2');(own/'build-tool.py').write_text(s,encoding='utf-8',newline='\n')
s=(base/'review2/android-tool.py').read_text().replace('H:/isv2-sqlite','H:/ica').replace('s2-sqlite-20261001/review2','s2-sqlite-20261001/fix2').replace('5586','5588');(own/'android-tool.py').write_text(s,encoding='utf-8',newline='\n')
s=(base/'review2/start-emulator.py').read_text().replace('s2-sqlite-20261001/review2','s2-sqlite-20261001/fix2').replace('IMStorageReview2Minimum34','IMStorageFix2Minimum34').replace('5586','5588').replace('5587','5589');(own/'start-emulator.py').write_text(s,encoding='utf-8',newline='\n')
s=(base/'review2/stop-emulator.ps1').read_text().replace('s2-sqlite-20261001/review2','s2-sqlite-20261001/fix2').replace('IMStorageReview2Minimum34','IMStorageFix2Minimum34').replace('5586','5588');(own/'stop-emulator.ps1').write_text(s,encoding='utf-8',newline='\n')
for sub in ['avd-home','android-user']:(own/sub).mkdir(exist_ok=True)
print('Scoped source, actual tests, CI package fix and external helpers prepared')
