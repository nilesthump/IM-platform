from pathlib import Path
import json,hashlib,gzip,subprocess
r=Path('H:/ica');own=Path('H:/.codex/evidence/s2-sqlite-20261001/fix2');d=r/'spec/progress/evidence/LOOP1-CLIENT-SQLITE-001/fix2';run=own/'research/runs/R-SQLITE-FIX2-20261002';product=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();checks=json.loads((own/'integer-clean-checks.json').read_text());assert all(x['exit_code']==0 for x in checks)
for f in ['integer-clean-checks.json']+[f'integer-clean-check-{i}.{k}' for i in range(9) for k in ['stdout','stderr']]:
 data=(own/f).read_bytes()
 if f.endswith('.json'):(d/f).write_bytes(data)
 else:(d/(f+'.gz')).write_bytes(gzip.compress(data,mtime=0))
checksText='\n## Final integer source clean committed verification\n\nExact product '+product+' / absent-path detachedH:/if2i-sqlite clean0. Recovery Acceptance23specs10.125s, sourceall0(.422s), frozen53(6.062s), architecture53(5.938s), CI31(3.062s4Windowsprivilegeskips), WSS/SyncPlugin/diffcheck/status0 allPASS. Newchecks justified by changed models/Repository/tests, not repeated unchanged pass. Exact integer-clean-checks.json/rawgz. ActualSQLx13/141/unit1 and minimumAPI34firstinstall+pmclear13/137each PASS. Locallyverified product; NEWfreshReview3/applicableexactHEADLinuxhostedcleanwrapper beforedone.\n'
for name in ['checks.md','fix-report.md']:
 p=d/name;p.write_text(p.read_text(encoding='utf-8')+checksText,encoding='utf-8',newline='\n')
p=r/'spec/progress/current.md';s=p.read_text(encoding='utf-8');s=s.replace('Recovery Acceptance23specs9.328s','Recovery Acceptance23specs10.125s');s=s.replace('Fix2 locally verified clean producta8c0cd0c183dae6145f60641b8273adb9f09df3a;', 'Fix2 prior cursorproducta8c0cd0/89 evidence retained; final locally verified integer product'+product+';');s=s.replace('Source-only snapshot is local development only.', 'Clean committed source verification passed locally; independent actual exactHEAD acceptance remains pending.');s=s.replace('source-only snapshot is local development only.', 'clean committed source verification passed locally; independent actual exactHEAD acceptance remains pending.');p.write_text(s,encoding='utf-8',newline='\n')
p=r/'spec/tasks/review/LOOP1-CLIENT-SQLITE-001.md';s=p.read_text(encoding='utf-8');s+='\nFinalFix2 integer product '+product+' clean committed RecoveryAcceptance23specs10.125s/allsource0/frozen53/architecture53/CI31(4Windowsprivilegeskips)/WSS/SyncPlugin/diff/status0 PASS locally; exact fix2/integer-clean-checks.json/rawgz. Final evidence-only SHA returned by gitHEAD, sourceequalproduct verified before writer release. NEWfreshReview3/actualexactHEADhostedbeforeTaskdone; HumanSTOPafterSQLitePRmerge/safeoriginalsync/progress still applies.\n';p.write_text(s,encoding='utf-8',newline='\n')
events=[json.loads(x) for x in (run/'events.jsonl').read_text().splitlines()];rows=[]
for e in events:
 if e['event_type']=='command_started':rows.append(dict(command_id=e['data']['command_id'],argv=e['data']['argv'],started_at=e['timestamp']))
 if e['event_type']=='command_finished':
  row=next(v for v in rows if v['command_id']==e['data']['command_id']);row.update(e['data']);row['finished_at']=e['timestamp']
  for typ in ['stdout','stderr']:
   data=(run/e['data'][typ+'_blob']).read_bytes();f=e['data']['command_id']+'.'+typ+'.txt.gz';(d/f).write_bytes(gzip.compress(data,mtime=0));row[typ+'_persisted_sha256']=hashlib.sha256(data).hexdigest();row[typ+'_gzip_sha256']=hashlib.sha256((d/f).read_bytes()).hexdigest()
rows=[x for x in rows if 'finished_at' in x];(d/'local-command-history.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');print('Final completed-command snapshot',len(rows),'source',product)
