from pathlib import Path
import json,hashlib,zipfile
own=Path('H:/.codex/evidence/s2-sqlite-20261001/fix2');r=Path('H:/ica');base=own.parent
p=r/'tests/clients/sqlite/desktop.mjs';s=p.read_text();s=s.replace('type:"sync.user.page",events:[{kind:', 'type:"sync.user.page",requestId:r,events:[{eventId:id,cursor:cursor256,kind:');p.write_text(s,encoding='utf-8',newline='\n')
dest=r/'spec/progress/evidence/LOOP1-CLIENT-SQLITE-001/fix2';dest.mkdir(exist_ok=True)
manifest=json.loads((base/'review2/public-byte-manifest.json').read_text());entries=[]
with zipfile.ZipFile(dest/'independent-failed-review2.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for row in manifest:
  data=(base/'review2'/row['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];z.writestr(row['path'],data);entries.append(row)
 data=(base/'review2/public-byte-manifest.json').read_bytes();z.writestr('public-byte-manifest.json',data);entries.append(dict(path='public-byte-manifest.json',size=len(data),sha256=hashlib.sha256(data).hexdigest()))
(dest/'independent-failed-review2-manifest.json').write_text(json.dumps(entries,indent=2)+'\n',encoding='utf-8',newline='\n')
ci=['36905605691.json','36905605691-summary.json','36905605691-logs.txt.gz','36905605691-log-manifest.json','36905605691-ingestion.json','36905605691-mobile-job-api.log'];rows=[]
for f in ci:
 data=(base/'ci'/f).read_bytes();(dest/f).write_bytes(data);rows.append(dict(path=f,size=len(data),sha256=hashlib.sha256(data).hexdigest()))
(dest/'failed-ci-byte-manifest.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Complete canonical cursor page fields; preserved',len(entries),'Review2 public members and',len(rows),'failed hosted CI artifacts')
