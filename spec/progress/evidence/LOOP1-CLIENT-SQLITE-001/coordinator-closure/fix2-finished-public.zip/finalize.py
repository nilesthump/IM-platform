from pathlib import Path
import json,hashlib,gzip,subprocess
r=Path('H:/ica');own=Path('H:/.codex/evidence/s2-sqlite-20261001/fix2');d=r/'spec/progress/evidence/LOOP1-CLIENT-SQLITE-001/fix2';run=own/'research/runs/R-SQLITE-FIX2-20261002';product=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
check=json.loads((own/'clean-checks.json').read_text());assert all(x['exit_code']==0 for x in check)
for f in ['clean-checks.json']+[f'clean-check-{i}.{k}' for i in range(9) for k in ['stdout','stderr']]:
 data=(own/f).read_bytes()
 if f.endswith('.json'):(d/f).write_bytes(data)
 else:(d/(f+'.gz')).write_bytes(gzip.compress(data,mtime=0))
(d/'checks.md').write_text('''# Clean committed local Fix2 checks

Source candidate '''+product+''' in newly absent-path detached H:/if2-sqlite, clean0. Recorded via Fix2 Recorder external checks.py. Recovery Acceptance23specs9.328s PASS; allsource0violations .438s; frozen53PASS6.297s; architecture53PASS6s; CI31PASS2.828s with4Windows symlink privilege skips retained; existing WSS8positive10negative18schema26mutation and SyncPlugin79/16mutation PASS; diffcheck/status0. Exact argv/elapsed/exits clean-checks.json and persisted raw gzip logs. Clean source rerun resolves known live ignored-cache source-check failure without checker change. Current source locally verified, not independent Task/S2 acceptance. Native lock/source zero diff from6dc; cold hosted build/minimum34 clean official wrapper and real Linux skip-free checks still required.
''',encoding='utf-8',newline='\n')
p=d/'fix-report.md';s=p.read_text(encoding='utf-8');s+='\nClean committed checks PASS as documented in checks.md. Additional external metadata helper initially used Windows GBK default to read UTF8 Task and failed; no Task write then occurred. Explicit UTF8 retry succeeds and failure remains recorded. Positively owned emulatorPID49080/name proved and stopped; no active own runtime/build. Intermediate product '+product+'; final evidence-only source correspondence verified separately.\n';p.write_text(s,encoding='utf-8',newline='\n')
p=r/'spec/progress/current.md';s=p.read_text(encoding='utf-8');s=s.replace('Corrected locally verified product78ee723a4130d237d824b7d9c313dd77297fcbe8;', 'Prior corrected product78ee723 preserved; Fix2 locally verified clean product'+product+';');s=s.replace('Source snapshot all0/architecture53/frozen53 PASS;', 'Clean committed Recovery Acceptance23specs9.328s/sourceall0/architecture53/frozen53 PASS;');s=s.replace('NEW fresh Fix Agent owns only scoped source/tests/currentTask/new evidence until clean final commit/release; Coordinator read-only.','Fix2 owns scoped final evidence until clean release; afterward Coordinator owns closure metadata, fresh independent Reviewer read-only.');p.write_text(s,encoding='utf-8',newline='\n')
p=r/'spec/tasks/review/LOOP1-CLIENT-SQLITE-001.md';s=p.read_text(encoding='utf-8');s+='\nFix2 clean committed '+product+' Recovery Acceptance23specs/sourceall0/frozen53/architecture53/CI31(4Windows privilege skips)/WSS/SyncPlugin/diffcheck/status0 PASS. Exact checks.md/clean-checks.json. Candidate remains review; fresh independent Review3 plus exactHEAD hosted actual checks required. Owned emulator stopped; no egress; final evidence-only candidate returned separately.\n';p.write_text(s,encoding='utf-8',newline='\n')
events=[json.loads(x) for x in (run/'events.jsonl').read_text().splitlines()];rows=[]
for e in events:
 if e['event_type']=='command_started':rows.append(dict(command_id=e['data']['command_id'],argv=e['data']['argv'],started_at=e['timestamp']))
 if e['event_type']=='command_finished':
  row=next(v for v in rows if v['command_id']==e['data']['command_id']);row.update(e['data']);row['finished_at']=e['timestamp']
  for typ in ['stdout','stderr']:
   data=(run/e['data'][typ+'_blob']).read_bytes();f=e['data']['command_id']+'.'+typ+'.txt.gz';(d/f).write_bytes(gzip.compress(data,mtime=0));row[typ+'_persisted_sha256']=hashlib.sha256(data).hexdigest();row[typ+'_gzip_sha256']=hashlib.sha256((d/f).read_bytes()).hexdigest()
(d/'local-command-history.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');print('Final local evidence/metadata prepared; product',product)
