from pathlib import Path
import subprocess,time,json,gzip,hashlib,sys
py=sys.executable
pwsh="C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe"
cwd="H:/if4-sqlite";out=Path("H:/.codex/evidence/s2-sqlite-20261001/fix4");rows=[]
commands=[[pwsh,"-NoProfile","-File","tools/verify-loop1-ctrl-002.ps1","-Mode","Acceptance"],[py,"-B","ci/check_architecture.py","--scope","all","--json"],[pwsh,"-NoProfile","-File","tools/verify-frozen-architecture.ps1"],[py,"-B","-m","unittest","discover","-s","tests/architecture","-v"],[py,"-B","-m","unittest","discover","-s","tests/ci","-v"],[py,"-B","contracts/websocket/verify.py"],[py,"-B","contracts/plugin-api/verify.py"],["git","-c","core.whitespace=cr-at-eol","diff","--check","cdbcbc51..HEAD"],["git","diff","--exit-code","9a86d3b","HEAD","--","clients","tests/clients","tools/verify_client_sqlite.py","tools/verify-client-sqlite.ps1"],["git","-c","core.excludesFile=.git/info/exclude","status","--porcelain=v1"]]
commands=[commands[i] for i in [0,7,8,9]]
for i,argv in enumerate(commands):
 start=time.monotonic();p=subprocess.run(argv,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE);row={"argv":argv,"cwd":cwd,"exit_code":p.returncode,"elapsed_seconds":round(time.monotonic()-start,3)}
 for kind,b in [("stdout",p.stdout),("stderr",p.stderr)]:
  n=f"final-{i}.{kind}.gz";compressed=gzip.compress(b,mtime=0);(out/n).write_bytes(compressed)
  row[kind]={"path":n,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"gzip_sha256":hashlib.sha256(compressed).hexdigest()}
 rows.append(row);print(i,p.returncode,row["elapsed_seconds"],argv[-1],flush=True)
(out/"final-checks.json").write_text(json.dumps(rows,indent=2)+"\n",encoding="utf-8")
sys.exit(0 if all(x["exit_code"]==0 for x in rows) and not rows[-1]["stdout"]["bytes"] else 1)
