from pathlib import Path
import subprocess,time,json,gzip,hashlib,sys
out=Path('H:/.codex/evidence/s2-sqlite-20261001/review5')
base=json.loads(Path('spec/progress/evidence/LOOP1-CLIENT-SQLITE-001/fix4/clean-checks.json').read_text())
rows=[]
for i,item in enumerate(base[:7]):
 a=item['argv']; t=time.monotonic(); p=subprocess.run(a,capture_output=True); row={'argv':a,'cwd':str(Path.cwd()),'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-t,3)}
 for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  name=f'clean-{i}.{label}.gz'; comp=gzip.compress(data,mtime=0); (out/('retry-'+name)).write_bytes(comp); row[label]={'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'gzip_sha256':hashlib.sha256(comp).hexdigest()}
 rows.append(row); print(i,p.returncode,row['elapsed_seconds'],flush=True)
(out/'retry-clean-checks.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
assert all(x['exit_code']==0 for x in rows)
