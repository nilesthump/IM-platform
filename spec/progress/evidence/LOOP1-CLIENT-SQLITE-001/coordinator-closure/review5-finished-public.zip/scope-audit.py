from pathlib import Path
import subprocess,json,hashlib,re,zipfile,gzip
root=Path('H:/isv5-sqlite'); out=Path('H:/.codex/evidence/s2-sqlite-20261001/review5')
def git(*a):return subprocess.check_output(['git',*a],cwd=root).decode('utf-8')
assert git('rev-parse','HEAD').strip()=='5998b5bebc9c407b74f4adf7fe70c1b9865d85a6'
assert not git('status','--porcelain=v1').strip()
assert hashlib.sha256((root/'spec/architecture/frozen-architecture.md').read_bytes()).hexdigest()=='aa2398020beeda5f7f9456aac346da57bd8b75212192123c943c35dfdc80f84c'
assert hashlib.sha256((root/'scalable-distributed-im-architecture.pdf').read_bytes()).hexdigest()=='546915f639f30cd294f11390da3ade2ce6a85b620bf55727c2a90ca6017d7510'
task=(root/'spec/tasks/review/LOOP1-CLIENT-SQLITE-001.md').read_text(encoding='utf-8')
allowed=re.findall(r'\x60([^\x60]+)\x60',task.split('# Allowed Paths')[1].split('# Acceptance')[0])
import fnmatch
changed=git('diff','--name-only','a28752967ddd471cd281aece7ea9b343521356e8..HEAD').splitlines()
bad=[p for p in changed if not any(fnmatch.fnmatchcase(p,a) for a in allowed)]
assert not bad,bad
assert subprocess.run(['git','diff','--exit-code','9a86d3b641ca60b526c65abcc7a9aeee0b48d082','HEAD','--','clients','tests/clients','tools/verify_client_sqlite.py','tools/verify-client-sqlite.ps1'],cwd=root).returncode==0
archive_rows=[];secret_hits=[]
patterns=[re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),re.compile(rb'gh[pousr]_[A-Za-z0-9]{30,}'),re.compile(rb'AKIA[0-9A-Z]{16}')]
for p in changed:
 b=(root/p).read_bytes()
 assert not any(x in p.lower() for x in ['original-preservation','local-only','node_modules/','.env','toolchains/'])
 if p.endswith('.zip'):
  with zipfile.ZipFile(root/p) as z:
   for n in z.namelist():
    assert not n.startswith('/') and '..' not in Path(n).parts
    assert not any(x in n.lower() for x in ['original-preservation','local-only','.keystore','private.key'])
    data=z.read(n)
    if any(x.search(data) for x in patterns):secret_hits.append(p+'::'+n)
   archive_rows.append({'path':p,'members':len(z.namelist()),'sha256':hashlib.sha256(b).hexdigest()})
 elif p.endswith('.gz'):
  data=gzip.decompress(b)
  if any(x.search(data) for x in patterns):secret_hits.append(p)
 elif any(x.search(b) for x in patterns):secret_hits.append(p)
result={'sha':git('rev-parse','HEAD').strip(),'range':'a287529..5998b5b','changed_paths':changed,'out_of_scope':bad,'archives':archive_rows,'secret_pattern_hits':secret_hits,'product_identical_9a':True,'clean':True}
(out/'scope-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'changed_count':len(changed),'archives':len(archive_rows),'secret_pattern_hits':secret_hits,'scope':'PASS','product_identical_9a':True}))
assert not secret_hits
