import hashlib,json,pathlib,subprocess,zipfile,time
R=pathlib.Path('H:/ica'); E=pathlib.Path('H:/.codex/evidence/client-architecture-resume-20261001/closure-review'); C=pathlib.Path('H:/.codex/evidence/client-architecture-resume-20261001/ci')
base='e7c80c726d4799ba3ddab026266be638c9e6b252'; head='b1d3e91ef4f73c23ef4894f986e6b0d2ba3252e1'; rollback='3f352a8e465c0c4b093cca8e5f404ea587550b6e'
def git(*args): return subprocess.check_output(['git','-c','core.excludesFile=.git/info/exclude','-C',str(R),*args]).decode('utf8')
def tree(ref): return {s.split('\t',1)[1]:s.split('\t',1)[0] for s in git('ls-tree','-r',ref).splitlines()}
def sha(x):return hashlib.sha256(x).hexdigest()
t0=time.perf_counter(); a=tree(base); b=tree(head); old=tree(rollback)
changed=[p for p in set(a)|set(b) if a.get(p)!=b.get(p)]
allowed=['spec/architecture/README.md','spec/architecture/baseline.md','spec/architecture/decisions/ADR-0005-client-technology-clarification.md','spec/progress/current.md','spec/tasks/review/LOOP1-CLIENT-ARCH-CLARIFICATION-001.md','spec/tasks/done/LOOP1-CLIENT-ARCH-CLARIFICATION-001.md']
assert all(p in allowed or p.startswith('spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001/') or (p.startswith('spec/progress/checkpoints/') and 'client-architecture' in p) for p in changed),changed
protected={p:v for p,v in a.items() if p not in changed}; assert all(b.get(p)==v for p,v in protected.items())
prod={p:v for p,v in old.items() if p.startswith(('backend/','contracts/','clients/','plugins/','deploy/')) or p=='scalable-distributed-im-architecture.pdf'}; assert all(b.get(p)==v for p,v in prod.items())
D=R/'spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001/2026-10-01-coordinator-resume'; manifest=json.loads((D/'archive-manifest.json').read_text())
with zipfile.ZipFile(D/'independent-review-and-ci.zip') as z:
    names=set(z.namelist()); assert names==set(x['path'] for x in manifest),(names,len(manifest))
    for x in manifest:
        data=z.read(x['path']); assert len(data)==x['size'] and sha(data)==x['sha256'],x['path']
    report=[p for p in names if p.endswith('/review-report.md')]; result=[p for p in names if p.endswith('/review-result.json')]
    assert len(report)==len(result)==1
    assert z.read(report[0])==(D/'review-report.md').read_bytes(); assert z.read(result[0])==(D/'review-result.json').read_bytes()
    prior=json.loads(z.read(result[0])); assert prior['exact_sha']==base and prior['result']=='PASS'
    for h in prior['hosted']:
        candidates=[p for p in names if p.endswith('/'+h['run']+'.json')]; assert len(candidates)==1
        raw=z.read(candidates[0]); assert sha(raw)==h['source_sha256']; q=json.loads(raw)
        assert q['headSha']==base and q['status']=='completed' and q['conclusion']=='success'
        jobs={j['name']:j for j in q['jobs']}; assert set(jobs)==set(h['selected_jobs'])|{j['name'] for j in q['jobs'] if j['conclusion']=='skipped'}
        for name in h['selected_jobs']: assert jobs[name]['conclusion']=='success' and all(s['conclusion']=='success' for s in jobs[name]['steps'])
    hosted=[p for p in names if p.endswith('push-classify-log.zip')]; assert len(hosted)==1
    import io
    with zipfile.ZipFile(io.BytesIO(z.read(hosted[0]))) as l:
        txt='\n'.join(l.read(p).decode('utf8') for p in l.namelist()); assert 'Ran 30 tests' in txt and 'skipped=' not in txt
q=subprocess.run(['git','-C',str(R),'-c','core.whitespace=cr-at-eol','diff','--check',base,head],capture_output=True,text=True); assert q.returncode==0,q.stdout
canon=sha((R/'spec/architecture/frozen-architecture.md').read_bytes()); pdf=sha((R/'scalable-distributed-im-architecture.pdf').read_bytes()); assert canon=='aa2398020beeda5f7f9456aac346da57bd8b75212192123c943c35dfdc80f84c'; assert pdf=='546915f639f30cd294f11390da3ade2ce6a85b620bf55727c2a90ca6017d7510'
ci=[]
for run,selected in [('36883049629',{'classify','architecture','source_go','source_java','gate'}),('36883056601',{'classify','architecture','source_go','source_java','gate','go','java','shared','web','mobile','desktop','compatibility','deploy'})]:
    raw=(C/(run+'.json')).read_bytes();q=json.loads(raw); jobs={j['name']:j for j in q['jobs']}
    complete=q['headSha']==head and q['status']=='completed' and q['conclusion']=='success' and all(name in jobs and jobs[name]['conclusion']=='success' and all(s['conclusion']=='success' for s in jobs[name]['steps']) for name in selected)
    ci.append({'run':run,'headSha':q['headSha'],'complete_pass':complete,'sha256':sha(raw),'selected':sorted(selected),'job_conclusions':{k:v['conclusion'] for k,v in jobs.items()}})
    (E/(run+'.json')).write_bytes(raw)
assert ci[0]['complete_pass']
status=git('status','--porcelain'); assert not status,status
result={'semantic_result':'PASS','head':head,'range':base+'..'+head,'branch':git('branch','--show-current').strip(),'clean':True,'changed_paths':sorted(changed),'protected_baseline_objects_unchanged':len(protected),'rollback_product_objects_unchanged':len(prod),'archive_members_verified':len(manifest),'prior_review_report_result_byte_identical':True,'prior_exact_head_ci_verified':True,'current_ci':ci,'frozen_sha256':canon,'pdf_sha256':pdf,'cr_aware_diff_check':0,'elapsed_seconds':time.perf_counter()-t0}
(E/'audit-result.json').write_text(json.dumps(result,indent=2),encoding='utf8'); print(json.dumps({k:v for k,v in result.items() if k!='changed_paths'},indent=2))