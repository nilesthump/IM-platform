import sys,json,importlib.util,tempfile,shutil,pathlib,subprocess,os,time
root=pathlib.Path('H:/icx'); ev=pathlib.Path('H:/.codex/evidence/plugin-quoted-method-independent-review-20261001')
spec=importlib.util.spec_from_file_location('checker',root/'ci/check_architecture.py'); checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
forms={'gstring-expression':'''def note = "${pluginManager.apply('java')}"
println "REVIEW_JAVA_APPLIED=" + plugins.hasPlugin('java')
''','gstring-closure':'''def note = "${-> pluginManager.apply('java')}"
println note
println "REVIEW_JAVA_APPLIED=" + plugins.hasPlugin('java')
'''}
results=[]
for name,source in forms.items():
 p=ev/'runtime'/name;p.mkdir(parents=True,exist_ok=True);(p/'build.gradle').write_text(source,encoding='utf-8');(p/'settings.gradle').write_text("rootProject.name='review-probe'\n",encoding='utf-8')
 with tempfile.TemporaryDirectory(dir=ev) as temp:
  t=pathlib.Path(temp); shutil.copytree(root/'spec/architecture',t/'spec/architecture'); (t/'clients/mobile').mkdir(parents=True);(t/'clients/mobile/build.gradle').write_text(source,encoding='utf-8'); errors=checker.check_clients(t)
 env=os.environ.copy();env['JAVA_HOME']='H:/jdk-25.0.2';env['GRADLE_USER_HOME']=str(ev/'gradle-user-home');env['PATH']=env['JAVA_HOME']+'/bin;'+env['PATH'];start=time.monotonic()
 command=['C:/Users/21441/.gradle/wrapper/dists/gradle-9.1.0-all/bmafxlsgu9ht0l6ebxq31nf0s/gradle-9.1.0/bin/gradle.bat','--no-daemon','--offline','--console=plain','help']
 run=subprocess.run(command,cwd=p,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE); (p/'stdout.raw').write_bytes(run.stdout);(p/'stderr.raw').write_bytes(run.stderr)
 result=dict(name=name,source=source,checker_errors=errors,command=command,exit=run.returncode,seconds=time.monotonic()-start,stdout=run.stdout.decode('utf-8',errors='replace'),stderr=run.stderr.decode('utf-8',errors='replace'));results.append(result);print(json.dumps(result))
(ev/'gstring-runtime-proof.json').write_text(json.dumps(results,indent=2),encoding='utf-8')