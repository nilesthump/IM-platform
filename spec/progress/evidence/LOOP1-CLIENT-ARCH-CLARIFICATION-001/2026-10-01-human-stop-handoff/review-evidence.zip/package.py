from pathlib import Path
import zipfile,hashlib,json,subprocess
p=Path('H:/.codex/evidence/plugin-quoted-method-independent-review-20261001');items=[]
for f in p.rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(p)
 if any(x in rel.parts for x in ['gradle-user-home','.gradle','__pycache__']):continue
 if rel.as_posix() in ['review-evidence.zip','postfinish.json']:continue
 items.append(f)
with zipfile.ZipFile(p/'review-evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for f in items:z.write(f,f.relative_to(p).as_posix())
report=dict(result='FAIL',run_id='R-PLUGIN-QUOTED-INDEPENDENT-20261001',recorder_finished_result='FAIL',recorder_validation='PASS',event_count=31,manifest_hash='2fee94fbd5e0e3673806955c94d934554bfc46cd44d0e3d7f13c8bf2aabaff6c',archive_sha256=hashlib.sha256((p/'review-evidence.zip').read_bytes()).hexdigest(),archive_members=len(items),postfinish_boundary='Packaging and hashes are ancillary after immutable Recorder finish; no new prospective command claims.',candidate_status=subprocess.check_output(['git','-C','H:/icx','status','--porcelain']).decode(),released=True)
(p/'postfinish.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))