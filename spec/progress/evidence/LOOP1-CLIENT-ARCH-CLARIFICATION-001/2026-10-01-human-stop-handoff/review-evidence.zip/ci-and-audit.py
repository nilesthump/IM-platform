import subprocess,json,pathlib,zipfile,re,hashlib,time
root=pathlib.Path('H:/icx');ev=pathlib.Path('H:/.codex/evidence/plugin-quoted-method-independent-review-20261001')
def git(*args): return subprocess.check_output(['git','-C',str(root),*args])
def api(endpoint):
 r=subprocess.run(['gh','api',endpoint],capture_output=True); assert r.returncode==0,r.stderr; return r.stdout
summary=[]
for runid in [36875541572,36875532891]:
 runraw=api(f'repos/nilesthump/IM-platform/actions/runs/{runid}');jobraw=api(f'repos/nilesthump/IM-platform/actions/runs/{runid}/jobs?per_page=100');(ev/f'ci-{runid}-run.json').write_bytes(runraw);(ev/f'ci-{runid}-jobs.json').write_bytes(jobraw); run=json.loads(runraw);jobs=json.loads(jobraw)['jobs']
 log=subprocess.run(['gh','api',f'repos/nilesthump/IM-platform/actions/runs/{runid}/logs'],capture_output=True); assert log.returncode==0,log.stderr;(ev/f'ci-{runid}-logs.zip').write_bytes(log.stdout)
 with zipfile.ZipFile(ev/f'ci-{runid}-logs.zip') as z:
  logs={n:z.read(n).decode('utf-8',errors='replace') for n in z.namelist() if n.endswith('.txt')}; classlog='\n'.join(v for n,v in logs.items() if 'classify/' in n);archlog='\n'.join(v for n,v in logs.items() if 'architecture/' in n)
  refs=sorted(set(re.findall(r'[0-9a-f]{40}',classlog+archlog)));Linux=next((v for n,v in logs.items() if 'classify/' in n and 'Test path matrix' in n),'')
  selection=next((v for n,v in logs.items() if 'classify/' in n and 'Classify full diff' in n),'');(ev/f'ci-{runid}-classification.txt').write_text(selection,encoding='utf-8')
  entry=dict(id=runid,head_sha=run['head_sha'],event=run['event'],status=run['status'],conclusion=run['conclusion'],jobs=[dict(name=j['name'],head_sha=j['head_sha'],conclusion=j['conclusion'],steps=[dict(name=s['name'],conclusion=s['conclusion']) for s in j['steps']]) for j in jobs],checkout_refs=refs,linux_ci_controls=dict(ran30='Ran 30 tests' in Linux,ok=bool(re.search(r'\bOK\s*(?:\r?\n|$)',Linux)),skipped='skipped=' in Linux,real_link_test='test_symlinks_cannot_hide_behind_allowed_names_or_profile_root' in Linux))
  summary.append(entry)
 print(json.dumps(entry))
(ev/'actual-ci-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
# Fail review regardless of CI conclusions. Efficient immutable git-object comparison.
base='3f352a8e465c0c4b093cca8e5f404ea587550b6e';prev='54ab4a7f0422c96b84c5dbf0afe1aac071e891b7';head=git('rev-parse','HEAD').decode().strip()
def tree(ref): return {p.decode():obj.decode() for item in git('ls-tree','-r','-z',ref).split(b'\0') if item for meta,p in [item.split(b'\t',1)] for obj in [meta.split()[2]]}
old,new=tree(prev),tree(head); protected=[p for p in old if p.startswith(('research/','contracts/','backend/','clients/','spec/domain/','spec/invariants/','spec/acceptance/','spec/architecture/decisions/','spec/progress/evidence/')) or p=='scalable-distributed-im-architecture.pdf']; changed=[p for p in protected if old[p]!=new.get(p)]
whitespace={}
for name,args in [('focused',[prev,'HEAD']),('full',[base,'HEAD']),('full_except_raw',[base,'HEAD','--','.',':(exclude)spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001/human-approved-request.txt'])]:
 r=subprocess.run(['git','-C',str(root),'-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--check',*args],capture_output=True); whitespace[name]=dict(exit=r.returncode,output=r.stdout.decode())
audit=dict(head=head,clean=not git('status','--porcelain').strip(),protected_objects=len(protected),changed_protected=changed,changed_paths=git('diff','--name-only',base,'HEAD').decode().splitlines(),whitespace=whitespace,old_new_product_tree_same=all(tree(base).get(p)==new.get(p) for p in tree(base) if p.startswith(('backend/','clients/','contracts/','deploy/'))))
(ev/'bounded-audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in audit.items() if k not in ['changed_paths','whitespace']}));print('WHITESPACE',[(k,v['exit']) for k,v in whitespace.items()])