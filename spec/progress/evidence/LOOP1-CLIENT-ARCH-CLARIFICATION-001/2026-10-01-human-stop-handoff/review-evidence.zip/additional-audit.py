from pathlib import Path
import json,hashlib,zipfile,subprocess
root=Path('H:/icx');ev=Path('H:/.codex/evidence/plugin-quoted-method-independent-review-20261001');fix=root/'spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001/plugin-quoted-method-guard-fix'
original=json.loads(Path('H:/.codex/evidence/client-architecture-20261001/original-files-before.json').read_text())
for name,value in original.items():
 p=Path('H:/IM-platform')/name;assert p.stat().st_size==value['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==value['sha256'],name
copied=json.loads((fix/'copied-evidence-hashes.json').read_text()); count=0
for item in copied:
 with zipfile.ZipFile(fix/item.get('archive','independent-review-proofs.zip')) as z:data=z.read(item['member'])
 assert hashlib.sha256(data).hexdigest()==item['sha256'],item
 source=subprocess.check_output(['git','-C',str(root),'show','54ab4a7f0422c96b84c5dbf0afe1aac071e891b7:spec/progress/current.md']) if item['source'].startswith('git:') else Path(item['source']).read_bytes()
 assert hashlib.sha256(source).hexdigest()==item['sha256'],item
 count+=1
# Read checkout's actual synthetic merge commit information from GitHub.
sha='f6873561b48a8bdbd204c1c2f22b8d315514cbdb';raw=subprocess.check_output(['gh','api',f'repos/nilesthump/IM-platform/git/commits/{sha}']);(ev/'pr-synthetic-merge.json').write_bytes(raw);merge=json.loads(raw);headtree=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD^{tree}']).decode().strip()
report=dict(original_unknown_files=len(original),independent_copy_source_member_hashes=count,synthetic_sha=sha,synthetic_tree=merge['tree']['sha'],candidate_tree=headtree,parents=[p['sha'] for p in merge['parents']],same_tree=merge['tree']['sha']==headtree)
assert report['same_tree'];assert '4b5d6b8efa480462e5d4180e131ded9b692480ee' in report['parents'];assert '3f352a8e465c0c4b093cca8e5f404ea587550b6e' in report['parents']
(ev/'additional-audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
for runid in [36875541572,36875532891]:
 with zipfile.ZipFile(ev/f'ci-{runid}-logs.zip') as z:
  for n in z.namelist():
   if n.endswith('.txt') and ('Classify full diff' in n or ('architecture/' in n and 'Run actions/checkout' in n)):
    txt=z.read(n).decode('utf-8',errors='replace');print(runid,n);print(txt[-6500:])