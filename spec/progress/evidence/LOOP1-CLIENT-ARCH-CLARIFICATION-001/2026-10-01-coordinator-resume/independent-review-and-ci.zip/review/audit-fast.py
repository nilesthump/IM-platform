import hashlib,json,subprocess,pathlib,re,fnmatch
R=pathlib.Path('H:/ica'); O=pathlib.Path('H:/.codex/evidence/client-architecture-resume-20261001/review')
def git(*a):return subprocess.check_output(['git','-c','core.excludesFile=.git/info/exclude',*a],cwd=R)
base='3f352a8e465c0c4b093cca8e5f404ea587550b6e'; prior='4b5d6b8efa480462e5d4180e131ded9b692480ee'
head=git('rev-parse','HEAD').decode().strip();assert head=='e7c80c726d4799ba3ddab026266be638c9e6b252'
status=git('status','--porcelain=v1','--untracked-files=all').decode();assert not status
changed=git('diff','--name-only',base,'HEAD').decode().splitlines()
patterns=['spec/architecture/frozen-architecture.md','spec/architecture/baseline.md','spec/architecture/README.md','spec/architecture/decisions/ADR-0005-client-technology-clarification.md','AGENTS.md','spec/handoff/agent-context.md','spec/tasks/TASK_TEMPLATE.md','spec/governance/technology-selection.md','spec/governance/execution-boundaries.md','spec/governance/independent-review.md','ci/check_architecture.py','ci/classify.py','ci/architecture-checks.md','.github/workflows/ci.yml','tools/verify_frozen_architecture.py','tests/architecture/*','tests/ci/*','spec/tasks/*/LOOP1-CLIENT-ARCH-CLARIFICATION-001.md','spec/progress/current.md','spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001/*','spec/progress/checkpoints/*client-architecture*.md','research/prompts/*','research/runs/*']
violations=[p for p in changed if not any(fnmatch.fnmatchcase(p,x) for x in patterns)];assert not violations,violations
protected={}
for area in ['contracts','backend','clients','plugins','scalable-distributed-im-architecture.pdf']:
    a=git('ls-tree','-r',base,'--',area);b=git('ls-tree','-r','HEAD','--',area);assert a==b,area
    protected[area]={'identical_git_tree':True,'entries':len(a.splitlines()),'tree_record_sha256':hashlib.sha256(a).hexdigest()}
new_tree={line.split(chr(9),1)[1]:line for line in git('ls-tree','-r','HEAD').decode().splitlines()}
old=git('ls-tree','-r',prior).decode().splitlines(); protected_count=0
for line in old:
    meta,p=line.split('\t',1)
    if p.startswith(('spec/progress/evidence/','research/','spec/architecture/decisions/')) or p in ['spec/architecture/frozen-architecture.md','spec/architecture/baseline.md','spec/architecture/README.md']:
        assert new_tree.get(p)==line,(p,'historical blob changed');protected_count+=1
lineend={}
for p in ['spec/progress/current.md','spec/tasks/review/LOOP1-CLIENT-ARCH-CLARIFICATION-001.md']:
    a=git('show','00797514:'+p);b=git('show','HEAD:'+p)
    lineend[p]={'before_crlf':a.count(b'\r\n'),'before_lf':a.count(b'\n'),'after_crlf':b.count(b'\r\n'),'after_lf':b.count(b'\n')}
    if '/tasks/' in p:
        prefix=a.decode().replace('\r\n','\n').split('## Human GString waiver')[0]
        now=b.decode().replace('\r\n','\n').split('## Human GString waiver')[0]
        prefix=prefix.replace('owner: Coordinator (stopped by Human; independent Review FAIL)','owner: Coordinator (Human GString waiver; pending administrative closure)')
        lineend[p]['pre_waiver_historical_text_preserved']=prefix==now
checks={}
for label,args in [('full',['diff','--check',base,'HEAD']),('cr_aware_except_original_human',['-c','core.whitespace=cr-at-eol','diff','--check',base,'HEAD','--','.',':(exclude)spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001/human-approved-request.txt']),('admin',['-c','core.whitespace=cr-at-eol','diff','--check',prior,'HEAD'])]:
    c=subprocess.run(['git',*args],cwd=R,capture_output=True,text=True);checks[label]={'exit_code':c.returncode,'output':c.stdout+c.stderr}
assert checks['cr_aware_except_original_human']['exit_code']==0;assert checks['admin']['exit_code']==0
j={'head':head,'branch':git('branch','--show-current').decode().strip(),'clean_status':status,'allowed_paths_checked':len(changed),'scope_violations':violations,'protected_product':protected,'unchanged_historical_blobs_since_previous_review':protected_count,'line_endings':lineend,'whitespace':checks}
(O/'preservation-audit.json').write_text(json.dumps(j,indent=2),encoding='utf-8');print(json.dumps(j,indent=2))