from pathlib import Path
p=Path('H:/.codex/evidence/client-architecture-resume-20261001/review/finalize-evidence.py')
s=p.read_text()
s=s.replace("payload={", "payload={'result':'PASS',")
s=s.replace('Instrumentation limitations:', 'Instrumentation limitations: First review_finished event failed schema due to absent observed result (exit2); shell edit quoting retry failed SyntaxError and missing file (exit2). All retained; corrected event explicitly result PASS.')
p.with_name('finalize-evidence-corrected.py').write_text(s,encoding='utf-8')