from pathlib import Path
import subprocess,json,time,sys,hashlib,zipfile,re,fnmatch,importlib.util
root=Path('H:/icq');out=Path('H:/.codex/evidence/plugin-application-independent-review-20261001');py=sys.executable
history=[]
def run(args,name,cwd=root):
 t=time.monotonic();x=subprocess.run(args,cwd=cwd,capture_output=True);(out/(name+'.stdout.raw')).write_bytes(x.stdout);(out/(name+'.stderr.raw')).write_bytes(x.stderr);history.append({'argv':args,'exit':x.returncode,'elapsed':time.monotonic()-t,'stdout_sha256':hashlib.sha256(x.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(x.stderr).hexdigest()});print(name,x.returncode,round(history[-1]['elapsed'],3));return x
run(['pwsh','-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode','Acceptance'],'recovery')
run([py,'-B','ci/check_architecture.py','--scope','all','--json'],'sourceall')
run([py,'-B','-m','unittest','discover','-s','tests/ci','-v'],'ci-tests')
(out/'command-history.json').write_text(json.dumps(history,indent=2)+'\n')
# Independent immutable object audit: every unchanged-path object from prior Fix base.
def git(args):return subprocess.check_output(['git','-c','core.excludesFile=.git/info/exclude']+args,cwd=root).decode('utf8')
def tree(rev):return dict((line.split('\t',1)[1],line.split('\t',1)[0]) for line in git(['ls-tree','-r',rev]).splitlines())
base='3f352a8e465c0c4b093cca8e5f404ea587550b6e';focus='dbb3c99f8f201ebb0d512c78aa7853f9a91f225d';head=git(['rev-parse','HEAD']).strip();changed=git(['diff','--name-only',base,head]).splitlines();focused=git(['diff','--name-only',focus,head]).splitlines();old=tree(focus);new=tree(head)
immutable=[p for p in old if p not in focused];bad=[p for p in immutable if old[p]!=new.get(p)]
protected=git(['diff','--name-only',base,head,'--','contracts','backend','clients','plugins','scalable-distributed-im-architecture.pdf']).splitlines()
unknown=json.loads(Path('H:/.codex/evidence/client-architecture-20261001/original-files-before.json').read_text());unknownbad=[]
for f,v in unknown.items():
 p=Path('H:/IM-platform')/f
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=v['sha256']:unknownbad.append(f)
copies=[]
for folder in ['plugin-application-guard-fix','plugin-literal-guard-fix']:
 for item in json.loads((root/'spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001'/folder/'copied-evidence-hashes.json').read_text()):
  p=root/item['target'];source=Path(item['source']);expected=item['sha256'];copies.append({'target':item['target'],'target_match':p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==expected,'source_match':source.is_file() and hashlib.sha256(source.read_bytes()).hexdigest()==expected})
whitespace={}
raw='spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001/human-approved-request.txt'
for name,args in [('focused',[focus,head]),('full',[base,head]),('full-except-raw',[base,head,'--','.',':(exclude)'+raw])]:
 x=subprocess.run(['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--check']+args,cwd=root,capture_output=True);whitespace[name]={'exit':x.returncode,'stdout':x.stdout.decode(),'stderr':x.stderr.decode()}
(out/'preservation-audit.json').write_text(json.dumps({'head':head,'status':git(['status','--porcelain=v1','--untracked-files=all']),'branch':git(['branch','--show-current']),'changed':changed,'focused':focused,'immutable_objects_checked':len(immutable),'immutable_mismatches':bad,'protected_changes':protected,'original_unknown_checked':len(unknown),'original_unknown_mismatches':unknownbad,'copy_hashes':copies,'whitespace':whitespace},indent=2)+'\n');print('audit',len(immutable),len(unknown),len(copies),'bad',bad,unknownbad,protected)
