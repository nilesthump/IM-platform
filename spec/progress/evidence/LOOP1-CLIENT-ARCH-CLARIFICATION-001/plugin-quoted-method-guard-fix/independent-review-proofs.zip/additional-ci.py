from pathlib import Path
import subprocess,json,re,hashlib,importlib.util
root=Path('H:/icq');out=Path('H:/.codex/evidence/plugin-application-independent-review-20261001');gh='C:/Program Files/GitHub CLI/gh.exe';repo='nilesthump/IM-platform'
summary=json.loads((out/'actual-ci-summary.json').read_text());pr=(out/'actual-ci-36869935325.stdout.raw').read_text(encoding='utf8');push=(out/'actual-ci-36869928218.stdout.raw').read_text(encoding='utf8');head='54ab4a7f0422c96b84c5dbf0afe1aac071e891b7'
merge=set(re.findall(r'\t[0-9TZ:.\-]+ ([0-9a-f]{40})\s*$',pr,re.M));merge.discard(head)
print('checkout_merge',merge)
linked=[]
for sha in merge:
 x=subprocess.run([gh,'api',f'repos/{repo}/git/commits/{sha}'],capture_output=True);assert x.returncode==0;commit=json.loads(x.stdout);(out/f'actual-merge-{sha}.json').write_bytes(x.stdout)
 tree=subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=root).decode().strip();linked.append({'sha':sha,'parents':[x['sha'] for x in commit['parents']],'tree':commit['tree']['sha'],'candidate_tree':tree,'same_tree':commit['tree']['sha']==tree,'head_parent':head in [x['sha'] for x in commit['parents']]})
checks={}
for rid,text in [('36869935325',pr),('36869928218',push)]:
 testlines=[l for l in text.splitlines() if l.startswith(('architecture\t','classify\t')) and re.search(r'\b(?:Ran|OK|skipped)|test_.*symlink|test_.*link',l)]
 failed=[l for l in text.splitlines() if l.startswith('deploy\t') and any(s in l for s in ['AuthenticateAsClient','authentication failed','##[error]','FAILED','FAIL:'])]
 steps=summary[rid]['jobs'];checks[rid]={'test_lines':testlines,'failed_deploy_lines':failed,'nonsuccess_steps':[{'job':j['name'],'step':s} for j in steps for s in j['steps'] if s['conclusion']!='success']}
 print(rid,'failed_lines',failed,'non_success',checks[rid]['nonsuccess_steps'])
s=importlib.util.spec_from_file_location('classify',root/'ci/classify.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);audit=json.loads((out/'preservation-audit.json').read_text());matrix=m.classify(audit['changed'])
(out/'additional-ci-audit.json').write_text(json.dumps({'merge_linkage':linked,'checks':checks,'full_changed_path_matrix':matrix,'required_jobs':list(m.JOBS),'push_attempt_observed':1,'push_retry_coordinator_pending':True},indent=2)+'\n');print('linkage',linked,'matrix',matrix)
assert all(x['same_tree'] and x['head_parent'] for x in linked)
# Task authority input and current actual source/governance inspection snapshots, external only.
paths=['spec/architecture/frozen-architecture.md','AGENTS.md','spec/tasks/TASK_TEMPLATE.md','ci/architecture-checks.md']
paths += [str(p.relative_to(root)) for p in (root/'spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001').glob('human-*.txt')]
paths += ['spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001/approval-and-recovery.md']
read={p:{'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest(),'bytes':len((root/p).read_bytes())} for p in paths};(out/'authority-read-hashes.json').write_text(json.dumps(read,indent=2)+'\n')
print('authority_input_snapshot',read)
