from pathlib import Path
import subprocess,json,re,time,hashlib
out=Path('H:/.codex/evidence/plugin-application-independent-review-20261001');gh='C:/Program Files/GitHub CLI/gh.exe';repo='nilesthump/IM-platform';head='54ab4a7f0422c96b84c5dbf0afe1aac071e891b7'
def api(path):
 x=subprocess.run([gh,'api',path],capture_output=True);assert x.returncode==0,x.stderr;return json.loads(x.stdout)
summary={}
for rid in [36869935325,36869928218]:
 run=api(f'repos/{repo}/actions/runs/{rid}');jobs=api(f'repos/{repo}/actions/runs/{rid}/jobs?per_page=100');(out/f'actual-ci-{rid}-run.json').write_text(json.dumps(run,indent=2)+'\n');(out/f'actual-ci-{rid}-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
 x=subprocess.run([gh,'run','view',str(rid),'--repo',repo,'--log'],capture_output=True);(out/f'actual-ci-{rid}.stdout.raw').write_bytes(x.stdout);(out/f'actual-ci-{rid}.stderr.raw').write_bytes(x.stderr);text=x.stdout.decode('utf8',errors='replace')
 # Public actual log lines establish checkout commit and real tests, not aggregate inference.
 lines=[l for l in text.splitlines() if any(s in l for s in ["git log -1 --format",'checkout_status_entries=','test_symlink','test_real_symlink','Ran 30 tests','Ran 51 tests','OK (skipped','SELECTED_JSON','selected_jobs','BASE_SHA:','HEAD_SHA:','Checking out the ref','[command]/usr/bin/git checkout',' "architecture": true'])]
 shas=re.findall(r'([0-9a-f]{40})',text);checkout_lines=[]
 for job in jobs['jobs']:
  jl=[l for l in text.splitlines() if l.startswith(job['name']+'\t')]
  for i,l in enumerate(jl):
   if 'git log -1 --format' in l and i+1<len(jl):checkout_lines.append({'job':job['name'],'log':l,'commit_line':jl[i+1]})
 summary[str(rid)]={'head_sha':run['head_sha'],'status':run['status'],'conclusion':run['conclusion'],'event':run['event'],'job_count':len(jobs['jobs']),'jobs':[{ 'name':j['name'],'conclusion':j['conclusion'],'steps':[{'name':s['name'],'conclusion':s['conclusion']} for s in j['steps']] } for j in jobs['jobs']],'log_exit':x.returncode,'raw_sha256':hashlib.sha256(x.stdout).hexdigest(),'relevant_lines':lines,'checkout_lines':checkout_lines}
 assert run['head_sha']==head
 print(rid,run['conclusion'],len(jobs['jobs']),{j['name']:j['conclusion'] for j in jobs['jobs']})
(out/'actual-ci-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({r:{'checkout':v['checkout_lines'],'relevant':v['relevant_lines']} for r,v in summary.items()},indent=2))
