from pathlib import Path
import importlib.util,json,shutil,subprocess,time,hashlib
root=Path('H:/icq'); out=Path('H:/.codex/evidence/plugin-application-independent-review-20261001')
s=importlib.util.spec_from_file_location('check',root/'ci/check_architecture.py'); check=importlib.util.module_from_spec(s);s.loader.exec_module(check)
probe=out/'probe';probe.mkdir(exist_ok=True)
for f in ['spec/architecture/baseline.md','spec/architecture/frozen-architecture.md','spec/architecture/decisions/ADR-0005-client-technology-clarification.md']:
 p=probe/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/f,p)
cases={'variable-apply':'def selected="java"\napply plugin: selected','alias-get':'plugins { alias(libs.plugins.unapproved.get()) }','literal-transform':'plugins { id("com.android.application".replace("com.android.application","java")) }','shortcut':'plugins { java }','typed':'apply<JavaPlugin>()','container-command':"plugins.apply 'java'",'manager-command':"pluginManager.apply 'java'",'closure':"apply { plugin 'java' }",'method-reference':"def selected = pluginManager.&apply\nselected('java')",'quoted-container':"plugins.'apply'('java')",'quoted-manager':'pluginManager."apply"("java")','approved-id':'plugins { id("com.android.application") version "8.9" apply false }','approved-kotlin':'plugins { kotlin("android") }\nkotlin { jvmToolchain(17) }','approved-groovy':"plugins { id 'com.android.library' version '8.9' apply false }",'approved-apply':"apply plugin: 'org.jetbrains.kotlin.android'",'quoted-note':'def note = "pluginManager.apply"'}
p=probe/'clients/mobile/build.gradle';p.parent.mkdir(parents=True,exist_ok=True);results={}
for name,source in cases.items():
 p.write_text(source,encoding='utf8');results[name]={'source':source,'errors':check.check_clients(probe)}
 print(name,results[name]['errors'])
(out/'independent-probes.json').write_text(json.dumps(results,indent=2)+'\n')
runtime={}
for name in ['quoted-container','quoted-manager']:
 d=out/name;d.mkdir(exist_ok=True);(d/'settings.gradle').write_text("rootProject.name='independent-proof'\n");(d/'build.gradle').write_text(cases[name]+"\ntasks.register('proof') { doLast { println('UNAPPROVED_JAVA_PLUGIN_APPLIED=' + plugins.hasPlugin('java')) } }\n")
 argv=['pwsh','-NoProfile','-Command',"$env:JAVA_HOME='H:/jdk-25.0.2'; $env:GRADLE_USER_HOME='"+str(out/'gradle-cache')+"'; & 'C:/Users/21441/.gradle/wrapper/dists/gradle-9.1.0-all/bmafxlsgu9ht0l6ebxq31nf0s/gradle-9.1.0/bin/gradle.bat' --no-daemon --offline -p '"+str(d)+"' proof; exit $LASTEXITCODE"]
 start=time.monotonic(); x=subprocess.run(argv,capture_output=True);elapsed=time.monotonic()-start
 (out/(name+'.stdout.raw')).write_bytes(x.stdout);(out/(name+'.stderr.raw')).write_bytes(x.stderr)
 runtime[name]={'source':cases[name],'argv':argv,'exit':x.returncode,'elapsed':elapsed,'applied':b'UNAPPROVED_JAVA_PLUGIN_APPLIED=true' in x.stdout,'stdout_sha256':hashlib.sha256(x.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(x.stderr).hexdigest()}; print(name,runtime[name])
(out/'runtime-proofs.json').write_text(json.dumps(runtime,indent=2)+'\n')
