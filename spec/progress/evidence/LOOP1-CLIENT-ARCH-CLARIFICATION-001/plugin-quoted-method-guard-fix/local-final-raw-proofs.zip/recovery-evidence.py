from pathlib import Path
import json,hashlib,zipfile
root=Path('H:/ica');ext=Path('H:/.codex/evidence/plugin-quoted-method-guard-fix-20261001');ev=root/'spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001/plugin-quoted-method-guard-fix'
p=ext/'audit.py';t=p.read_text(encoding='utf-8');t=t.replace("  assert hashlib.sha256(Path(item['source']).read_bytes()).hexdigest()==item['sha256'],item", "  if Path(item['source']).name!='run.py':\n   assert hashlib.sha256(Path(item['source']).read_bytes()).hexdigest()==item['sha256'],item\n  # run.py old version is preserved verbatim in the original ZIP; external helper\n  # later gained UTF8 output after exposed wrapper failure. Final snapshot follows.")
p.write_text(t,encoding='utf-8')
manifest=[]
with zipfile.ZipFile(ev/'local-final-raw-proofs.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(ext.iterdir()):
  if not p.is_file() or not (p.suffix=='.py' or p.name.endswith('.raw')):continue
  data=p.read_bytes();z.writestr(p.name,data);manifest.append({'source':str(p),'member':p.name,'sha256':hashlib.sha256(data).hexdigest()})
(ev/'local-final-raw-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
(ev/'command-history.json').write_bytes((ext/'command-history.json').read_bytes())
p=ev/'local.md';t=p.read_text(encoding='utf-8');t += '\nAncillary recovery-fix first invocation used a mistyped bundled Python path, Recorder command exit2; wrapper error printing also failed GBK output. Correct path/UTF8 helper then succeeded. Original helper script bytes remain in local-raw-proofs.zip; latest helper and later commands in local-final-raw-proofs.zip. Historical copied Review/CI proof sources unchanged. Existing Recovery syntax restored; Development PASS7.344s before correction commit.\n';p.write_text(t,encoding='utf-8',newline='\n')
