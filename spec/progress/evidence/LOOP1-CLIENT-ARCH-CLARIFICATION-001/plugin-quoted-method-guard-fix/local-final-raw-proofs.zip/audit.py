from pathlib import Path
import json,subprocess,hashlib,zipfile,sys
ROOT=Path('H:/ica');EXT=Path('H:/.codex/evidence/plugin-quoted-method-guard-fix-20261001');EV=ROOT/'spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001/plugin-quoted-method-guard-fix'
BASE='54ab4a7f0422c96b84c5dbf0afe1aac071e891b7';ROLLBACK='3f352a8e465c0c4b093cca8e5f404ea587550b6e'
def git(*args):return subprocess.check_output(['git','-c','core.excludesFile=.git/info/exclude',*args],cwd=ROOT).decode('utf-8')
def tree(sha):return {p:(m,o) for m,t,o,p in (line.split(None,3) for line in git('ls-tree','-r',sha).splitlines())}
head=git('rev-parse','HEAD').strip();old=tree(BASE);new=tree(head)
mutable={'ci/check_architecture.py','tests/architecture/test_client_technology.py','spec/progress/current.md','spec/tasks/review/LOOP1-CLIENT-ARCH-CLARIFICATION-001.md'}
allowed=lambda p:p in mutable or p.startswith(EV.relative_to(ROOT).as_posix()+'/') or p=='spec/progress/checkpoints/2026-10-01-client-architecture-plugin-quoted-method-guard-fix.md'
changed=set(git('diff','--name-only','--no-renames',BASE).splitlines()+git('ls-files','--others','--exclude-standard').splitlines());assert all(allowed(p) for p in changed),changed
preserved=[p for p in old if p not in mutable];assert all(old[p]==new.get(p) for p in preserved)
original=json.loads(Path('H:/.codex/evidence/client-architecture-20261001/original-files-before.json').read_text(encoding='utf-8'))
for name,value in original.items():
 p=Path('H:/IM-platform')/name;assert p.stat().st_size==value['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==value['sha256'],name
copied=json.loads((EV/'copied-evidence-hashes.json').read_text(encoding='utf-8'))
for item in copied:
 with zipfile.ZipFile(EV/item.get('archive','independent-review-proofs.zip')) as z:data=z.read(item['member'])
 assert hashlib.sha256(data).hexdigest()==item['sha256'],item
 source=subprocess.check_output(['git','show',BASE+':spec/progress/current.md'],cwd=ROOT) if item['source'].startswith('git:') else Path(item['source']).read_bytes()
 assert hashlib.sha256(source).hexdigest()==item['sha256'],item
raw=json.loads((EV/'local-raw-hashes.json').read_text(encoding='utf-8'))
with zipfile.ZipFile(EV/'local-raw-proofs.zip') as z:
 for item in raw:
  assert hashlib.sha256(z.read(item['member'])).hexdigest()==item['sha256'],item
  if Path(item['source']).name!='run.py':
   assert hashlib.sha256(Path(item['source']).read_bytes()).hexdigest()==item['sha256'],item
  # run.py old version is preserved verbatim in the original ZIP; external helper
  # later gained UTF8 output after exposed wrapper failure. Final snapshot follows.
rawhuman='spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001/human-approved-request.txt';checks={}
for label,args in [('focused',['diff','--check',BASE]),('full',['diff','--check',ROLLBACK]),('full_except_exact_raw',['diff','--check',ROLLBACK,'--','.',':(exclude)'+rawhuman])]:
 p=subprocess.run(['git','-c','core.whitespace=cr-at-eol',*args],cwd=ROOT,capture_output=True);checks[label]={'exit':p.returncode,'stdout':p.stdout.decode('utf-8'),'stderr':p.stderr.decode('utf-8')}
assert checks['focused']['exit']==checks['full_except_exact_raw']['exit']==0,checks
assert checks['full']['exit']==2 and checks['full']['stdout'].count('trailing whitespace.')==12,checks
assert old[rawhuman]==new[rawhuman]
assert hashlib.sha256((ROOT/'spec/architecture/frozen-architecture.md').read_bytes()).hexdigest()=='aa2398020beeda5f7f9456aac346da57bd8b75212192123c943c35dfdc80f84c'
assert hashlib.sha256((ROOT/'scalable-distributed-im-architecture.pdf').read_bytes()).hexdigest()=='546915f639f30cd294f11390da3ade2ce6a85b620bf55727c2a90ca6017d7510'
report={'result':'PASS','head':head,'range':BASE+'..'+head,'full_range':ROLLBACK+'..'+head,'branch':git('branch','--show-current').strip(),'status':git('status','--porcelain'),'changed_paths':sorted(changed),'protected_prior_tree_objects':len(preserved),'original_unknown_files':len(original),'independent_copy_source_member_hashes':len(copied),'local_raw_source_member_hashes':len(raw),'whitespace':checks}
(EXT/'preservation.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
if '--external-only' not in sys.argv:(EV/'preservation.json').write_bytes((EXT/'preservation.json').read_bytes())
print(json.dumps({k:v for k,v in report.items() if k not in ('changed_paths','whitespace','status')},indent=2))
