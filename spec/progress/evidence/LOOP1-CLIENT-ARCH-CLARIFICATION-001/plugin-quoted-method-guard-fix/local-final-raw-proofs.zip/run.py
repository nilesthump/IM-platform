from pathlib import Path
import json, subprocess, sys, time, hashlib
sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path('H:/ica')
EXT = Path('H:/.codex/evidence/plugin-quoted-method-guard-fix-20261001')
PY = 'C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
REC = [PY, '-B', str(ROOT/'tools/research/recorder.py')]
OPTIONS = ['--repo', str(ROOT), '--research-root', str(EXT/'research'), '--run-id', 'R-PLUGIN-QUOTED-METHOD-FIX-20261001']
def run(label, argv):
    history=EXT/'command-history.json'
    previous=json.loads(history.read_text()) if history.exists() else []
    count=sum(x['label']==label or x['label'].startswith(label+'-attempt') for x in previous)
    if count: label += '-attempt'+str(count+1)
    start=time.monotonic()
    p=subprocess.run(REC+['run-command']+OPTIONS+['--']+argv, cwd=ROOT, capture_output=True)
    (EXT/(label+'.stdout.raw')).write_bytes(p.stdout)
    (EXT/(label+'.stderr.raw')).write_bytes(p.stderr)
    history=EXT/'command-history.json'
    rows=json.loads(history.read_text()) if history.exists() else []
    rows.append({'label':label,'argv':argv,'exit':p.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()})
    history.write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(rows[-1]),flush=True)
    if p.returncode: print(p.stdout.decode('utf-8',errors='replace')[-3500:]+p.stderr.decode('utf-8',errors='replace')[-3500:])
    return p.returncode
key=sys.argv[1]
if key=='baseline':
    sys.exit(run('baseline-recovery',['pwsh','-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode','Development']))
elif key in ('red','green'):
    sys.exit(run(key,[PY,'-B','-m','unittest','discover','-s','tests/architecture','-p','test_client_technology.py','-v']))
elif key=='verify':
    results=[run('frozen',['pwsh','-NoProfile','-File','tools/verify-frozen-architecture.ps1']),run('sourceall',[PY,'-B','ci/check_architecture.py','--scope','all','--json']),run('architecture',[PY,'-B','-m','unittest','discover','-s','tests/architecture','-v']),run('ci',[PY,'-B','-m','unittest','discover','-s','tests/ci','-v']),run('development',['pwsh','-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode','Development'])]
    sys.exit(any(results))
elif key=='acceptance':
    sys.exit(run('acceptance',['pwsh','-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode','Acceptance']))
else:
    sys.exit(run(key,sys.argv[2:]))
