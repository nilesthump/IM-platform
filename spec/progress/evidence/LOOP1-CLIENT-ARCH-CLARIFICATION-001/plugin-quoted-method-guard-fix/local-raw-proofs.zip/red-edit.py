from pathlib import Path
import subprocess,json,hashlib,zipfile
ROOT=Path('H:/ica'); EXT=Path('H:/.codex/evidence/plugin-quoted-method-guard-fix-20261001')
EV=ROOT/'spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001/plugin-quoted-method-guard-fix'
EV.mkdir(parents=True,exist_ok=True)
source=Path('H:/.codex/evidence/plugin-application-independent-review-20261001')
files=[p for p in source.iterdir() if p.is_file()]+[p for folder in ['quoted-container','quoted-manager','research'] for p in (source/folder).rglob('*') if p.is_file() and '.gradle' not in p.relative_to(source).parts]
manifest=[]
with zipfile.ZipFile(EV/'independent-review-proofs.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(files):
        member=p.relative_to(source).as_posix(); data=p.read_bytes(); archive.writestr(member,data)
        manifest.append({'source':str(p),'member':member,'sha256':hashlib.sha256(data).hexdigest()})
    p=ROOT/'spec/progress/current.md'; data=p.read_bytes();archive.writestr('prior-current.md',data)
    manifest.append({'source':'git:54ab4a7:spec/progress/current.md','member':'prior-current.md','sha256':hashlib.sha256(data).hexdigest()})
(EV/'copied-evidence-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Preserved',len(manifest),'byte-exact source/member hashes')
p=ROOT/'tests/architecture/test_client_technology.py';data=p.read_bytes(); newline=b'\r\n' if b'\r\n' in data else b'\n'; text=data.decode('utf-8').replace('\r\n','\n')
new='''    def test_android_quoted_member_dispatch_fails_closed(self):
        # Review proved literal quoted dispatch applies builtin Java in Gradle.
        # Quoted/dynamic members are outside the supported direct declaration DSL.
        forms = (
            "plugins.'apply'('java')",
            'pluginManager."apply"("java")',
            "def selected = pluginManager.&'apply'\\nselected('java')",
            "def selected = 'apply'\\nplugins.\\\"${selected}\\\"('java')",
            "pluginManager?.'apply'('java')",
            "def selected = pluginManager\\nselected.'apply'('java')",
            "plugins.'apply'('com.android.application')",
            "dependencies.'add'('implementation', selected)",
        )
        for source in forms:
            with self.subTest(source=source):
                self.put('clients/mobile/build.gradle', source)
                errors = checker.check_clients(self.root)
                self.assertTrue(any('plugin' in error for error in errors), errors)

    def test_android_quoted_dispatch_text_remains_data(self):
        forms = (
            'def note = "plugins.\\\'apply\\\'(\\\'java\\\')"',
            "def note = 'pluginManager.\\\"apply\\\"(\\\"java\\\")'",
            "// plugins.'apply'('java')\\napply plugin: 'com.android.application'",
            "/* pluginManager.\\\"apply\\\"(\\\"java\\\") */\\nplugins { id 'com.android.library' }",
            'def note = ' + '"' * 3 + "plugins.'apply'('java')\\npluginManager.&'apply'" + '"' * 3,
            "def note = " + "'" * 3 + 'pluginManager."apply"("java")\\nplugins."${selected}"' + "'" * 3,
            "def note = \\\"text.\\\"\\n'data'",
        )
        for source in forms:
            with self.subTest(source=source):
                self.put('clients/mobile/build.gradle', source)
                self.assertEqual([], checker.check_clients(self.root))

'''
marker='    def test_android_supported_apply_and_quoted_contexts_remain_approved(self):\n'
assert marker in text
p.write_bytes(text.replace(marker,new+marker).replace('\n',newline.decode()).encode('utf-8'))
