from pathlib import Path
p=Path('H:/ica/ci/check_architecture.py');t=p.read_text(encoding='utf-8')
marker="            def mask_build_literal(match):\n"
assert marker in t
addition="            # Slashy literals have an unambiguous expression-start/member prefix;\n            # dollar-slashy literals have their own delimiter. Keep division as code.\n            quoted += r'|\\$/[\\s\\S]*?/\\$|(?P<slashy_prefix>(?:^|[=(\\[,:.]|\\.\\s*&)\\s*)/(?:\\\\.|[^/\\\\])*/'\n"
t=t.replace(marker,addition+marker)
t=t.replace("                if re.search(r'\\.\\s*&?\\s*$', build_code[:match.start()]):", "                prefix = match.group('slashy_prefix') or ''\n                if re.search(r'\\.\\s*&?\\s*$', prefix or build_code[:match.start()]):")
t=t.replace("                return ' '\n            build_code = re.sub(quoted, mask_build_literal, build_code)","                return prefix + ' '\n            build_code = re.sub(quoted, mask_build_literal, build_code, flags=re.MULTILINE)")
p.write_text(t,encoding='utf-8',newline='\n')
r=Path('H:/.codex/evidence/plugin-quoted-method-guard-fix-20261001')
(r/'runtime-repeat-proofs.json').write_bytes((r/'runtime-proofs.json').read_bytes())
for folder in ['quoted-container','quoted-manager','quoted-reference','dynamic-quoted','quoted-safe-call','quoted-alias']:
    for suffix in ['stdout.raw','stderr.raw']:
        src=r/(folder+'.'+suffix);(r/('runtime-repeat-'+folder+'.'+suffix)).write_bytes(src.read_bytes())
print('Original six per-probe runtime metadata/raw outputs were inadvertently overwritten by the rerun. Initial Recorder aggregate and command timing retained; original per-probe bytes unavailable. Repeated proof outputs preserved under runtime-repeat names, distinct from initial attempt.')
