from pathlib import Path
import json,zipfile,hashlib,subprocess
ROOT=Path('H:/ica');EXT=Path('H:/.codex/evidence/plugin-quoted-method-guard-fix-20261001');EV=ROOT/'spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001/plugin-quoted-method-guard-fix'
manifest=json.loads((EV/'copied-evidence-hashes.json').read_text(encoding='utf-8'))
retry=Path('H:/.codex/evidence/client-architecture-20261001/push54ab-retry2')
with zipfile.ZipFile(EV/'push54ab-retry2-proofs.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(retry.rglob('*')):
        if not p.is_file():continue
        data=p.read_bytes();member=p.relative_to(retry).as_posix();z.writestr(member,data)
        manifest.append({'source':str(p),'archive':'push54ab-retry2-proofs.zip','member':member,'sha256':hashlib.sha256(data).hexdigest()})
(EV/'copied-evidence-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for name in ['runtime-repeat-proofs.json','runtime-slashy-proofs.json','command-history.json','prompt-source-hashes.json']:(EV/name).write_bytes((EXT/name).read_bytes())
raw=[]
with zipfile.ZipFile(EV/'local-raw-proofs.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    files=[p for p in EXT.iterdir() if p.is_file() and (p.suffix=='.py' or p.name.endswith('.raw') or p.suffix=='.txt')]
    files += [EXT/n/f for n in ['quoted-container','quoted-manager','quoted-reference','dynamic-quoted','quoted-safe-call','quoted-alias','dynamic-slashy','dynamic-dollar-slashy'] for f in ['build.gradle','settings.gradle']]
    for p in sorted(files):
        data=p.read_bytes();member=p.relative_to(EXT).as_posix();z.writestr(member,data)
        raw.append({'source':str(p),'member':member,'sha256':hashlib.sha256(data).hexdigest()})
(EV/'local-raw-hashes.json').write_text(json.dumps(raw,indent=2)+'\n',encoding='utf-8')
(EV/'local.md').write_text('''# Quoted Gradle selector bounded repair; local evidence

Fresh Fix /root/plugin_quoted_method_guard_fix owns the correction from clean54ab4a7f0422c96b84c5dbf0afe1aac071e891b7. Task remains unique review; S1 PASS/S2 OPEN; no product/authority/publiccontract/dependency changes, no services, no push/merge/selfacceptance. Coordinator owns adb tooling daemon. Last known good rollback3f352a8e465c0c4b093cca8e5f404ea587550b6e.

Independent54ab FAIL proved literal quoted plugins/application dispatch passes the guard while actual offline Gradle9.1/Java25 applies Java. Existing lexical masking now identifies unsupported quoted member/pointer/interpolated selectors before discarding data strings; slashy and dollar-slashy forms have actual additional proofs. No receiver/plugin-name blacklist, AST framework or dependency. Slashy literals use bounded unambiguous expression-start/member prefixes; division stays executable code. Direct approved id/kotlin/catalog/version/applyfalse/configuration and all prior negative controls remain supported. Nine quoted-note/comment positives stay data. Unsupported quoted dependency member declarations fail closed under the existing direct-declaration requirement.

Final controls on immutable prior54ab: RED10 failures; initial RED8 included a dependency fixture whose string token already triggered another guard, so that fixture was corrected to the actual unresolved quoted call and rechecked. Initial callback extension produced4 expected slashy negative/positive failures, then repaired. GREEN19 client tests. Frozen53/no skips, architecture53/no skips, sourceall0 violations, CI30 with4 existing exposed Windows WinError1314 real-symlink privilege skips, Recovery Development PASS. Exact command arrays/exits/timings/hashes in command-history.json; raw logs/scripts/proof sources are byte-identical ZIP members with local-raw-hashes.json. Clean committed Recovery Acceptance and preservation discovery follows subsequent commits; local evidence never accepts the Task or Gate.

Eight actual runtime forms apply Java, all exit0 under cached Gradle9.1/Java25 --offline --no-daemon with external GRADLE_USER_HOME. Six literal/pointer/dynamic/safecall/alias proofs in runtime-repeat-proofs.json are NEW repeated attempts; two slashy proofs in runtime-slashy-proofs.json. The first six per-probe metadata and raw output bytes were inadvertently overwritten when an ancillary script reused output names and then repeated the initial runtime script. Their original per-probe bytes/hashes/timings are unavailable; no reconstruction claim. Initial command-level timing and aggregate stdout remain immutable in Recorder; complete rerun proofs have distinct runtime-repeat raw-member names. Early duplicate GREEN output filenames similarly retain exact original output in immutable Recorder blobs. Later command attempts use distinct filenames. No independent historical evidence or Recorder events/blobs were rewritten.

Initial pre-Recorder read-only Recovery exit1/6.689s had48 temporary-directory permission errors; authorized escalated baseline PASS8.375s. Restricted PowerShell UTF8 type setup failed; Python implicit GBK minimality read failed; explicit UTF8 reads succeeded. Ancillary missing finalize.py read failed; no dependent state changed. Ancillary script creation/reads may be outside command recorder; prospective_resume explicitly marks incomplete startup. Full assignment+initial dispatch+activation bytes are registered, source hashes distinguish raw from Recorder normalized text. Research PASS is not product acceptance.

Prior independent FAIL, runtime, full report, hosted logs, and finished FAIL23 Recorder are byte-preserved in independent-review-proofs.zip with source/member hashes. Prior current.md bytes are preserved in that ZIP before condensing current recovery state. PR36869935325 all13 success, push36869928218 attempt1 Java TLS smoke/deploy+gate FAIL and subsequent attempt2 effective13 success are preserved as separate facts. Retry proof-validated.json and original proof.json remain unchanged in push54ab-retry2-proofs.zip; ancillary retry validation errors are historical exposed facts. Old exact54ab CI does not accept this repair; NEW independent Review and actual new exact-head CI mandatory. Hosted Linux must execute real-symlink controls without skips.

Prior canonical/PDF/ADRs/Human attachments including12 intentional rawHuman Markdown hardbreaks/approved history/Recorder and original744 unknown files must remain immutable. Full diff-check FAIL12 remains disclosed; focused and fullrange excluding ONLY that exact unchanged attachment use CR-aware checks. Scope/protected Git objects/raw source/member/original file audit follows preservation.json. Sole writer releases only after clean final commit/finished validated Recorder/archive/external postfinish checks.
''',encoding='utf-8',newline='\n')
current='''# Current Execution State

Current Loop: Loop 1
Current Stage: S2
Current Gate: S2
Gate Status: OPEN
Current Batch: client-architecture-clarification-before-S2
Current Task: LOOP1-CLIENT-ARCH-CLARIFICATION-001
Current Task State: review
Execution Status: QUOTED_GRADLE_SELECTOR_FIX_NEW_REVIEW_PENDING_PRODUCT_NOT_STARTED

## Completed Work

Human-approved v1.1 candidate retains Android Kotlin/Jetpack Compose Mobile, React/TypeScript Web, Tauri/React/TypeScript Desktop + SQLx(SQLite), equivalent Mobile contracts/fixtures and universal selection governance. Rollback main3f352a8 restores accepted pre-PR7 tree; withdrawn PR7/approval/history remain immutable. S1 PASS/S2 OPEN; product coding waits for this prerequisite acceptance.

Fresh Fix repairs runtime-confirmed quoted Gradle member/pointer/interpolated selectors in existing checker and adds bounded RED/GREEN controls. No product/schema/public contract/dependency/authority changes. Earlier recovery history is preserved byte-for-byte in plugin-quoted-method-guard-fix/independent-review-proofs.zip (prior-current.md), with prior evidence directories unchanged.

## Verification and Evidence

Frozen/architecture53 no skips, sourceall0 violations, CI30 with4 exposed existing Windows real-symlink privilege skips, Recovery Development PASS. Clean committed Acceptance/preservation/Recorder/archive discovery follows durable spec/progress/evidence/LOOP1-CLIENT-ARCH-CLARIFICATION-001/plugin-quoted-method-guard-fix/local.md, command-history.json, preservation.json and recorder-summary.md. RED10 on prior54ab; GREEN19 client tests; actual isolated offline Gradle8 runtime forms apply Java and now reject. Local/Recorder PASS is not acceptance.

## Blockers and Risks

Independent54ab Review FAIL despite PRall13 SUCCESS and pushretry2 effective13 SUCCESS; original pushattempt1 TLS smoke/gateFAIL preserved. NEW independent Review and actual final exact-head CI required. Linux must execute real-link controls without skips. Initial sandbox/encoding/test-seam/slashy failures and ancillary runtime metadata/raw output filename loss are exposed in local.md; new reruns are distinct evidence. Prior historical authority/approval/PDF/Recorder/rawHuman12 hardbreaks and original744 unknown files preserved.

## Next Exact Action

Finish clean candidate/Recorder/archive and release sole writer; NEW fresh independent Review finalHEAD/full3f..HEAD + clean Recovery Acceptance + actual applicable new exact-head hosted CI. No done/product activation before acceptance; S2 OPEN.

## Last Known Good Commit

Rollback main3f352a8e465c0c4b093cca8e5f404ea587550b6e; accepted pre-PR7 a0f0f13759ffb2a861b08c4820a1504b76d5c08a tree restored.

## Latest Checkpoint

spec/progress/checkpoints/2026-10-01-client-architecture-plugin-quoted-method-guard-fix.md.

## Uncommitted Changes / Ownership

Fresh Fix /root/plugin_quoted_method_guard_fix owns only bounded checker/tests/current/task/new evidence/checkpoint until clean final archivecommit/external checks and explicit release. Original H:/IM-platform unknown744 files unchanged; Coordinator approval/recovery/full prompt copies unchanged. No product services; Coordinator owns adb tooling daemon.

## Architecture / Selection

Canonical v1.1 aa239802 and PDF546915 remain unchanged. Additional sensitive choices require architecture process; task paths/tests do not authorize them. No unresolved new selection.
'''
(ROOT/'spec/progress/current.md').write_text(current,encoding='utf-8',newline='\n')
checkpoint=ROOT/'spec/progress/checkpoints/2026-10-01-client-architecture-plugin-quoted-method-guard-fix.md'
checkpoint.write_text('''# Quoted Gradle selector correction recovery point

Current Task LOOP1-CLIENT-ARCH-CLARIFICATION-001 remainsreview; S1 PASS/S2 OPEN. Last known good rollback3f352a8e465c0c4b093cca8e5f404ea587550b6e. Parent candidate54ab4a7f0422c96b84c5dbf0afe1aac071e891b7 failed NEW independent Review. Repair commit is the commit introducing this checkpoint; final archive-only HEAD follows Recorder summary.

No contract/schema/migration/fixture/product dependency transition; canonical v1.1 aa239802 and PDF546915 unchanged. Bounded existing lexical guard rejects quoted selectors; runtime/RED10/GREEN19/Frozen53/sourceall0/CI30 with4 explicit Windows privilege skips/Recovery Development local PASS. Clean committed Acceptance and protected object/original744/raw source/member/whitespace audit recorded in plugin-quoted-method-guard-fix/preservation.json and command-history.json. Initial errors and unavailable first-runtime per-probe bytes are exposed in local.md. Prior current.md history bytes are archived unchanged; prior evidence/Recorder/authority preserved.

Fresh Fix sole writer releases after clean final archivecommit/checks; NEW fresh independent Review/full3f..finalHEAD + actual new exact-head hosted CI needed. No selfacceptance/done/product/services; Coordinator adb ownership. Recorder/archive/postfinish boundary in plugin-quoted-method-guard-fix/recorder-summary.md.
''',encoding='utf-8',newline='\n')
(EV/'recorder-summary.md').write_text('''# Quoted selector Fix Recorder discovery

R-PLUGIN-QUOTED-METHOD-FIX-20261001, parentR-CLIENT-ARCH-20261001, relatedR-PLUGIN-APPLICATION-REVIEW-20261001; full byte-concatenated assignment/dispatch/activation prompt. Capture prospective_resume/incomplete initial read-only startup; ancillary boundaries/initial failures/runtime filename-loss limitations disclosed in local.md. External trace is H:/.codex/evidence/plugin-quoted-method-guard-fix-20261001/research.

Run remains active until clean committed Acceptance and scope/preservation are complete. Finish/validation results and immutable archive are added afterward; archive-only finalcommit/externalchecks lie outside finished trace and cannot imply Task acceptance. NEW independent Review/finalexactheadCI mandatory; S2 OPEN.
''',encoding='utf-8',newline='\n')
p=ROOT/'spec/tasks/review/LOOP1-CLIENT-ARCH-CLARIFICATION-001.md';t=p.read_text(encoding='utf-8')
t += '''
## Independent Review FAIL and quoted selector correction (2026-10-01)

Fresh independent54ab Review FAIL: quoted member apply dispatch evades literal masking, actual Gradle9.1/Java25 applies Java. Fresh sole writer /root/plugin_quoted_method_guard_fix repairs existing bounded lexical pass for quoted member/pointer/interpolated selectors including runtime-confirmed slashy variants; no receiver/plugin blacklist/generalAST/new dependencies/authority/product edits. FinalRED10/GREEN19, actual8 runtime forms, Frozen53/no skips/sourceall0/architecture53/CI30 with4 exposed Windows1314 skips/Recovery Development localPASS. Required clean committed Acceptance, protected Git objects/original744/raw-copy-member/hash/CR-aware whitespace and finished Recorder/archive discovery in plugin-quoted-method-guard-fix/local.md, command-history.json, preservation.json, recorder-summary.md; checkpoint2026-10-01-client-architecture-plugin-quoted-method-guard-fix.md.

Prior independent FAIL/actualCI/runtime/finished Recorder preserved byte-for-byte, including PR13 success, pushattempt1TLSFAIL and retry2effective13 success. Earlier current.md history preserved exactZIP bytes. Initial sandbox/encoding/seam/slashy/ancillary failures exposed; first six generated per-probe runtime metadata/raw bytes inadvertently overwritten and unavailable, immutable Recorder aggregate retained; NEW runtime-repeat evidence is distinct, never reconstructed history. All prior authority/approval/Humanraw12 hardbreaks/PDF/ADRs/history/Recorder and original744 unknownfiles unchanged. Task remains unique review/S1PASS/S2OPEN; lastgoodrollback3f352a8. Fix owns bounded edits until clean finalarchivecommit/external checks then explicit release. Next NEW independent Review finalHEAD/full3f..HEAD + cleanAcceptance + actual newexactheadCI before done/product. No services/selfacceptance/push/merge; Coordinator adb ownership.
'''
p.write_text(t,encoding='utf-8',newline='\n')
print('Evidence/current/task/checkpoint written; history source/member hashes preserved')
