from pathlib import Path
import subprocess,sys,types,unittest
root=Path('H:/ica');sys.path.insert(0,str(root/'tests/architecture'))
import test_client_technology as tests
old=types.ModuleType('prior_checker');old.__file__=str(root/'ci/check_architecture.py')
exec(compile(subprocess.check_output(['git','show','54ab4a7:ci/check_architecture.py'],cwd=root),old.__file__,'exec'),old.__dict__)
tests.checker=old
suite=unittest.TestSuite(tests.ClientTechnologyControls(name) for name in ('test_android_quoted_member_dispatch_fails_closed','test_android_quoted_dispatch_text_remains_data'))
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(not result.wasSuccessful())
