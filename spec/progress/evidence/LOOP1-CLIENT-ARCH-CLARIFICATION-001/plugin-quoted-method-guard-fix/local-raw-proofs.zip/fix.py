from pathlib import Path
root=Path('H:/ica')
p=root/'tests/architecture/test_client_technology.py'; text=p.read_text(encoding='utf-8'); assert "dependencies.'add'('implementation', selected)" in text;text=text.replace("dependencies.'add'('implementation', selected)","dependencies.'add'(configuration, selected)"); p.write_text(text,encoding='utf-8',newline='\n')
p=root/'ci/check_architecture.py';text=p.read_text(encoding='utf-8');marker="            build_code = re.sub(quoted, ' ', build_code)\n";assert text.count(marker)==1
replacement='''            def mask_build_literal(match):
                # Groovy quoted members are executable selectors, including method
                # pointers and interpolation. Ordinary entire strings remain data.
                # Unsupported member notation must not evade plugin/dependency checks.
                if re.search(r'(?:\\.\\s*&?|::)\\s*$', build_code[:match.start()]):
                    errors.append(f'CLIENT {relative}: unresolved/dynamic Android quoted plugin/dependency/build selector')
                return ' '
            build_code = re.sub(quoted, mask_build_literal, build_code)
'''
p.write_text(text.replace(marker,replacement),encoding='utf-8',newline='\n')
