from pathlib import Path
import subprocess,json,hashlib,time
EXT=Path('H:/.codex/evidence/plugin-quoted-method-guard-fix-20261001')
forms={
'dynamic-slashy': 'def selected = \"apply\"\nplugins./${selected}/(\"java\")',
'dynamic-dollar-slashy': 'def selected = \"apply\"\npluginManager.$/${selected}/$(\"java\")',
}
results={}
for name, source in forms.items():
    folder=EXT/name;folder.mkdir(exist_ok=True)
    (folder/'settings.gradle').write_text("rootProject.name='quoted-dispatch-proof'\n",encoding='utf-8')
    (folder/'build.gradle').write_text(source+"\ntasks.register('proof') { doLast { println('UNAPPROVED_JAVA_PLUGIN_APPLIED=' + project.plugins.hasPlugin('java')) } }\n",encoding='utf-8')
    script="$env:JAVA_HOME='H:/jdk-25.0.2'; $env:GRADLE_USER_HOME='"+str(EXT/'gradle-cache')+"'; & 'C:/Users/21441/.gradle/wrapper/dists/gradle-9.1.0-all/bmafxlsgu9ht0l6ebxq31nf0s/gradle-9.1.0/bin/gradle.bat' --no-daemon --offline -p '"+str(folder)+"' proof; exit $LASTEXITCODE"
    argv=['pwsh','-NoProfile','-Command',script]
    start=time.monotonic();p=subprocess.run(argv,capture_output=True);elapsed=time.monotonic()-start
    (EXT/(name+'.stdout.raw')).write_bytes(p.stdout);(EXT/(name+'.stderr.raw')).write_bytes(p.stderr)
    results[name]={'source':source,'argv':argv,'exit':p.returncode,'elapsed_seconds':elapsed,'applied':b'UNAPPROVED_JAVA_PLUGIN_APPLIED=true' in p.stdout,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}
    print(name,results[name]['exit'],results[name]['applied'],flush=True)
(EXT/'runtime-slashy-proofs.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
assert all(x['exit']==0 and x['applied'] for x in results.values()),results
