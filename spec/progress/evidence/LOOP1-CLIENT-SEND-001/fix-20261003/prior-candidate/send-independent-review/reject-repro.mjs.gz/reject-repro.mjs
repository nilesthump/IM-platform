import {spawnSync} from 'node:child_process';
import {mkdtempSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {Repository} from 'file:///H:/.codex/worktrees/client-mvp-planning/IM-platform/clients/shared/protocol-sdk/dist/storage/repository.js';
import {SendApplication} from 'file:///H:/.codex/worktrees/client-mvp-planning/IM-platform/clients/desktop/dist/desktop/src/application/send.js';
const root=mkdtempSync(join(tmpdir(),'send-independent-review-')), user='10000000-0000-4000-8000-000000000003', sid='20000000-0000-4000-8000-000000000003', c1='30000000-0000-4000-8000-000000000003',c2='30000000-0000-4000-8000-000000000004',rid='40000000-0000-4000-8000-000000000003';
const hex=s=>Buffer.from(s).toString('hex');
function call(input){const r=spawnSync('H:/.codex/toolchains/client-sqlite/target-final/debug/storage_probe.exe',[root,user],{input,encoding:'utf8'});if(r.status)throw new Error(r.stderr);return r.stdout;}
const db={async transaction(steps){call(steps.map(([sql,args,n])=>['T',n??'-',hex(sql),...args.map(v=>v===null?'~':hex(v))].join('\t')).join('\n')+'\n')},async query(sql,args){const s=call(['Q',hex(sql),...args.map(hex)].join('\t')+'\n').trimEnd();return s?s.split(/\r?\n/).map(l=>l.split('\t').map(v=>v==='~'?null:Buffer.from(v,'hex').toString())):[]}};
const repo=new Repository(db);await repo.initialize();
// Both identities are independently valid, persisted own sends, not ID mutation.
for(const c of [c1,c2]){await repo.localSend({conversationId:c,requestId:rid,senderId:user,content:{kind:'TEXT',text:c}});await repo.markFailed(c,rid)}
let socket;const frames=[];const app=new SendApplication(repo,{userId:user,sessionId:sid,sessionEpoch:1n,accessToken:'fixture-review'},()=>socket={onopen:null,onmessage:null,onclose:null,onerror:null,send(raw){frames.push(JSON.parse(raw))},close(){}},10000);
app.connect('wss://localhost/');socket.onopen(new Event('open'));const bind=frames[0];
const deliver=(type,id,p)=>socket.onmessage(new MessageEvent('message',{data:JSON.stringify({protocolVersion:'1.0',type,requestId:id,payload:p})}));
deliver('auth.ack',bind.requestId,{status:'bound',userId:user,sessionId:sid,clientType:'DESKTOP',sessionEpoch:1});await app.idle();
await app.retry(c1,rid);await app.retry(c2,rid);
console.log('before rejection',JSON.stringify({c1:(await repo.messages(c1))[0][3],c2:(await repo.messages(c2))[0][3],transmitted:frames.filter(f=>f.type==='message.send').map(f=>f.payload.conversationId)}));
deliver('message.ack',rid,{status:'rejected',error:{code:'AUTHORIZATION_DENIED',message:'Denied'}});await app.idle();
console.log('after one unscoped rejection',JSON.stringify({c1:(await repo.messages(c1))[0][3],c2:(await repo.messages(c2))[0][3]}));app.close();await app.idle();
