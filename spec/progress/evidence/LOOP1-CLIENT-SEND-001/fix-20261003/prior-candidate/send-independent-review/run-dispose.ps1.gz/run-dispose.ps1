$ErrorActionPreference='Stop'
$meta='H:/IM-platform/.git/worktrees/IM-platform4/send-independent-review'
$env:JAVA_HOME='H:/.jdks/jdk17'
& H:/Android/build-tools/35.0.0/d8.bat --output ($meta+'/dex') --lib H:/Android/platforms/android-35/android.jar ($meta+'/java-classes/im/review/DisposeReview.class')
if($LASTEXITCODE){exit $LASTEXITCODE}
& H:/Android/build-tools/35.0.0/aapt2.exe link -o ($meta+'/dispose-unsigned.apk') --manifest ($meta+'/AndroidManifest.xml') -I H:/Android/platforms/android-35/android.jar
if($LASTEXITCODE){exit $LASTEXITCODE}
& H:/.jdks/jdk17/bin/jar.exe uf ($meta+'/dispose-unsigned.apk') -C ($meta+'/dex') classes.dex
if($LASTEXITCODE){exit $LASTEXITCODE}
& H:/Android/build-tools/35.0.0/zipalign.exe -f 4 ($meta+'/dispose-unsigned.apk') ($meta+'/dispose.apk')
if($LASTEXITCODE){exit $LASTEXITCODE}
& H:/Android/build-tools/35.0.0/apksigner.bat sign --ks H:/IM-platform/.git/worktrees/IM-platform4/send-runtime/android-user/debug.keystore --ks-pass pass:android ($meta+'/dispose.apk')
if($LASTEXITCODE){exit $LASTEXITCODE}
& H:/platform-tools/adb.exe -s emulator-5590 install -r ($meta+'/dispose.apk')
if($LASTEXITCODE){exit $LASTEXITCODE}
& H:/platform-tools/adb.exe -s emulator-5590 shell am instrument -w im.review.dispose/im.review.DisposeReview
exit $LASTEXITCODE
