package im.review;
import android.app.Instrumentation; import android.app.Activity; import android.os.Bundle; import java.lang.reflect.*; import java.math.BigInteger; import java.util.UUID;
public class DisposeReview extends Instrumentation {
 public void onCreate(Bundle args){super.onCreate(args);start();}
 public void onStart(){Bundle out=new Bundle();try{
  ClassLoader loader=getTargetContext().getClassLoader();
  Class<?> repoClass=loader.loadClass("im.platform.client.storage.Repository"),sessionClass=loader.loadClass("im.platform.client.send.SendSession"),vmClass=loader.loadClass("im.platform.client.send.SendViewModel"),continuationClass=loader.loadClass("kotlin.coroutines.Continuation");
  Object continuation=Proxy.newProxyInstance(loader,new Class[]{continuationClass},(proxy,method,args)->method.getName().equals("getContext")?loader.loadClass("kotlin.coroutines.EmptyCoroutineContext").getField("INSTANCE").get(null):null);
  String account=UUID.randomUUID().toString(), conversation=UUID.randomUUID().toString();
  Object repo=repoClass.getConstructor(android.content.Context.class,String.class).newInstance(getTargetContext(),account);
  repoClass.getMethod("initialize",boolean.class).invoke(repo,false);
  Object session=sessionClass.getConstructor(String.class,String.class,BigInteger.class,String.class).newInstance(account,UUID.randomUUID().toString(),BigInteger.ONE,"fixture-review");
  Constructor<?> ctor=null;for(Constructor<?> c:vmClass.getConstructors())if(c.getParameterCount()==8)ctor=c;
  Object vm=ctor.newInstance(repo,session,null,0L,null,false,60,null);
  vmClass.getMethod("openConversation",String.class,continuationClass).invoke(vm,conversation,continuation);
  vmClass.getMethod("send",String.class,String.class,continuationClass).invoke(vm,conversation,"closed storage retirement",continuation);
  repoClass.getMethod("close").invoke(repo);
  boolean threw=false;try{vmClass.getMethod("dispose",continuationClass).invoke(vm,continuation);}catch(InvocationTargetException expected){threw=true;out.putString("dispose_exception",expected.getCause().getClass().getSimpleName());}
  Field retired=vmClass.getDeclaredField("retired");retired.setAccessible(true);boolean isRetired=retired.getBoolean(vm);
  Object flow=vmClass.getMethod("getState").invoke(vm);Object state=loader.loadClass("kotlinx.coroutines.flow.StateFlow").getMethod("getValue").invoke(flow);
  int messages=((java.util.List<?>)state.getClass().getMethod("getMessages").invoke(state)).size();
  out.putBoolean("dispose_threw",threw);out.putBoolean("retired",isRetired);out.putInt("old_account_messages_after_dispose",messages);
  out.putString("observed",threw&&!isRetired&&messages==1?"DEFECT_REPRODUCED":"NOT_REPRODUCED");
  Method clear=vmClass.getDeclaredMethod("onCleared");clear.setAccessible(true);clear.invoke(vm);getTargetContext().deleteDatabase("im-"+account+".sqlite");finish(Activity.RESULT_OK,out);
 }catch(Throwable error){out.putString("failure",error.toString());finish(Activity.RESULT_CANCELED,out);}}
}
